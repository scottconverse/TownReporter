import { createFileRoute, Link } from "@tanstack/react-router";
import { SourceZipButton } from "@/components/source-zip";
import { PAPER } from "@/lib/paper";

export const Route = createFileRoute("/get-the-code")({
  component: GetTheCode,
});

function GetTheCode() {
  return (
    <main className="grid min-h-dvh place-items-center bg-paper px-6 text-ink">
      <div className="w-full max-w-md space-y-5">
        <p className="text-[11px] tracking-[0.18em] text-rust uppercase">
          {PAPER.name}
        </p>
        <h1 className="font-display text-3xl font-semibold">Source archive</h1>
        <p className="text-ink-2">
          This preview cannot attach files to chat. Click the black button. If
          nothing saves, the archive is blocked inside this frame — that is a
          Grok preview limit, not a missing file.
        </p>
        <SourceZipButton className="inline-flex min-h-11 items-center bg-ink px-5 text-sm text-paper hover:bg-ink-2">
          Save TownReporter.zip
        </SourceZipButton>
        <p>
          <Link to="/" className="text-sm text-muted hover:text-ink">
            Back to the paper
          </Link>
        </p>
      </div>
    </main>
  );
}
