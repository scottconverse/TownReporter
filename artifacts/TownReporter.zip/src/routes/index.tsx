import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PaperShell, TopicChip } from "@/components/paper-chrome";
import { StoryBody } from "@/components/story-body";
import { SourceZipButton } from "@/components/source-zip";
import {
  listPublishedArticles,
  listPublishedByTopic,
  searchPublished,
  subscribeNewsletter,
} from "@/lib/news/public";
import { PAPER, TOPICS, formatShortDate, parseUrlList } from "@/lib/paper";
import { useState } from "react";

type Search = { topic?: string; q?: string };

export const Route = createFileRoute("/")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    topic: typeof s.topic === "string" ? s.topic : undefined,
    q: typeof s.q === "string" ? s.q : undefined,
  }),
  loader: () => listPublishedArticles(),
  component: Home,
});

function Home() {
  const { topic, q } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [query, setQuery] = useState(q ?? "");
  const [email, setEmail] = useState("");
  const [subMsg, setSubMsg] = useState("");

  const initial = Route.useLoaderData();
  const { data: articles = initial, isPending } = useQuery({
    queryKey: ["paper", topic, q],
    queryFn: () => {
      if (q) return searchPublished({ data: q });
      if (topic) return listPublishedByTopic({ data: topic });
      return listPublishedArticles();
    },
    initialData: !topic && !q ? initial : undefined,
  });

  const featured = articles[0];
  const rest = articles.slice(1);

  return (
    <PaperShell>
      <div className="mb-8 border-2 border-ink bg-paper-2 p-4">
        <p className="font-display text-xl font-semibold">Get the code</p>
        <p className="mt-1 text-sm text-ink-2">
          Click the black button. Do not open a zip URL in this preview — that
          is the gray unhappy face.
        </p>
        <SourceZipButton className="mt-3 inline-flex min-h-11 items-center bg-ink px-5 text-sm text-paper hover:bg-ink-2">
          Save TownReporter.zip
        </SourceZipButton>
      </div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          <Link
            to="/"
            className={
              "border px-3 py-1 text-[11px] tracking-[0.14em] uppercase " +
              (!topic && !q
                ? "border-ink bg-ink text-paper"
                : "border-rule text-ink-2 hover:border-ink")
            }
          >
            all
          </Link>
          {TOPICS.filter((t) => t !== "about").map((t) => (
            <TopicChip key={t} topic={t} active={topic === t} />
          ))}
        </div>
        <form
          className="flex min-h-11 gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            void navigate({ search: { q: query || undefined, topic: undefined } });
          }}
        >
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search the archive"
            className="min-h-11 min-w-0 flex-1 border border-rule bg-paper px-3 text-sm outline-none focus:border-ink sm:w-56 sm:flex-none"
          />
          <button
            type="submit"
            className="min-h-11 border border-ink px-4 text-sm hover:bg-paper-2"
          >
            Search
          </button>
        </form>
      </div>

      {isPending && <p className="text-muted">Loading the edition…</p>}

      {!isPending && !featured && (
        <p className="border border-rule bg-paper-2 px-4 py-8 text-center text-ink-2">
          No stories in this slice yet. The editor is still working the desk.
        </p>
      )}

      {featured && (
        <article className="border-b border-ink pb-10">
          <p className="text-[11px] tracking-[0.16em] text-rust uppercase">
            {featured.topic} · {formatShortDate(featured.published_at)}
          </p>
          <h2 className="mt-2 font-display text-3xl font-semibold leading-tight sm:text-5xl">
            <Link to="/articles/$slug" params={{ slug: featured.slug }}>
              {featured.headline}
            </Link>
          </h2>
          <p className="mt-3 max-w-3xl text-lg italic text-ink-2">{featured.dek}</p>
          <div className="mt-6 max-w-2xl">
            <StoryBody body={featured.body.split("\n\n").slice(0, 2).join("\n\n")} />
            <Link
              to="/articles/$slug"
              params={{ slug: featured.slug }}
              className="mt-4 inline-block text-sm text-rust hover:text-rust-2"
            >
              Continue reading
            </Link>
          </div>
        </article>
      )}

      {rest.length > 0 && (
        <div className="mt-8 grid gap-8 sm:grid-cols-2">
          {rest.map((a) => (
            <article key={a.id} className="border-t border-rule pt-4">
              <p className="text-[11px] tracking-[0.16em] text-muted uppercase">
                {a.topic} · {formatShortDate(a.published_at)}
              </p>
              <h3 className="mt-1 font-display text-2xl font-semibold leading-snug">
                <Link to="/articles/$slug" params={{ slug: a.slug }}>
                  {a.headline}
                </Link>
              </h3>
              <p className="mt-2 text-ink-2">{a.dek}</p>
            </article>
          ))}
        </div>
      )}

      <section className="mt-14 border-t-2 border-ink pt-8">
        <h2 className="font-display text-2xl font-semibold">In your inbox</h2>
        <p className="mt-2 max-w-xl text-ink-2">
          New articles when they publish. No spam. We store the address to send
          the paper; we do not sell it.
        </p>
        <form
          className="mt-4 flex max-w-md flex-col gap-2 sm:flex-row"
          onSubmit={async (e) => {
            e.preventDefault();
            const res = await subscribeNewsletter({ data: email });
            if (!res.ok) setSubMsg(res.error);
            else if (res.confirmPath) setSubMsg(`Confirm: ${res.confirmPath} (preview — production would email this).`);
            else setSubMsg("You’re already on the list.");
          }}
        >
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="min-h-11 flex-1 border border-rule bg-paper px-3 text-sm outline-none focus:border-ink"
          />
          <button
            type="submit"
            className="min-h-11 bg-ink px-4 text-sm text-paper hover:bg-ink-2"
          >
            Subscribe
          </button>
        </form>
        {subMsg && <p className="mt-2 text-sm text-muted">{subMsg}</p>}
        <p className="mt-6 text-sm text-muted">
          {PAPER.name} complements the local paper. We cover the meetings and
          packets most people never sit through.
        </p>
      </section>
    </PaperShell>
  );
}
