import { Link } from "@tanstack/react-router";
import { PAPER } from "@/lib/paper";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { SourceZipButton } from "@/components/source-zip";

const LINKS = [
  { to: "/desk", label: "Overview" },
  { to: "/desk/sources", label: "Sources" },
  { to: "/desk/scan", label: "Scan" },
  { to: "/desk/queue", label: "Queue" },
  { to: "/desk/dark", label: "Dark desk" },
  { to: "/desk/memory", label: "Memory" },
] as const;

export function DeskShell({
  children,
  title,
  kicker,
  night = false,
}: {
  children: React.ReactNode;
  title: string;
  kicker?: string;
  night?: boolean;
}) {
  const { user, isPending } = useCurrentUserState();
  return (
    <div className={night ? "min-h-dvh bg-ink text-paper" : "min-h-dvh bg-desk text-desk-ink"}>
      <header className={night ? "border-b border-ink-2 bg-ink" : "border-b border-ink bg-paper"}>
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div>
            <Link to="/" className="font-display text-lg font-semibold">
              {PAPER.name}
            </Link>
            <p className={`text-[11px] tracking-[0.16em] uppercase ${night ? "text-paper-2" : "text-muted"}`}>
              {night ? "Dark desk — investigative engine" : "Editor-in-chief desk"}
            </p>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <SourceZipButton
              className={
                night
                  ? "bg-paper px-3 py-2 text-sm text-ink hover:bg-paper-2"
                  : "bg-ink px-3 py-2 text-sm text-paper hover:bg-ink-2"
              }
            >
              Source zip
            </SourceZipButton>
            <Link to="/" className={night ? "text-paper-2 hover:text-paper" : "text-muted hover:text-ink"}>
              View paper
            </Link>
            {isPending ? (
              <div className="h-8 w-8 animate-pulse rounded-full bg-paper-2" />
            ) : user ? (
              <UserButton />
            ) : null}
          </div>
        </div>
        <nav className="mx-auto flex max-w-6xl flex-wrap gap-1 px-4 pb-2 sm:px-6">
          {LINKS.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={night ? "px-3 py-2 text-sm text-paper-2 hover:text-rust" : "px-3 py-2 text-sm text-ink-2 hover:text-rust"}
              activeProps={{ className: "px-3 py-2 text-sm text-rust" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <p className="text-[11px] tracking-[0.16em] text-rust uppercase">
          {kicker ?? "Newsroom"}
        </p>
        <h1 className="mt-1 font-display text-3xl font-semibold">{title}</h1>
        <div className="mt-6">{children}</div>
      </main>
    </div>
  );
}

export function InkButton({
  children,
  onClick,
  disabled,
  tone = "solid",
  type = "button",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  tone?: "solid" | "ghost" | "danger" | "invert";
  type?: "button" | "submit";
}) {
  const cls =
    tone === "solid"
      ? "bg-ink text-paper hover:bg-ink-2"
      : tone === "danger"
        ? "border border-danger text-danger hover:bg-paper-2"
        : tone === "invert"
          ? "bg-paper text-ink hover:bg-paper-2"
          : "border border-ink text-ink hover:bg-paper-2";
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={
        "inline-flex min-h-11 items-center justify-center px-4 text-sm font-medium disabled:opacity-50 " +
        cls
      }
    >
      {children}
    </button>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-[11px] tracking-[0.14em] text-muted uppercase">
        {label}
      </span>
      {children}
    </label>
  );
}

export const inputClass =
  "min-h-11 w-full border border-rule bg-paper px-3 text-sm text-ink outline-none focus:border-ink";

export const areaClass =
  "w-full border border-rule bg-paper px-3 py-2 text-sm leading-6 text-ink outline-none focus:border-ink";
