import { useState } from "react";

const HREF = "/source-archive.bin";

export async function saveSourceZip(): Promise<"saved" | "failed"> {
  const res = await fetch(HREF);
  if (!res.ok) throw new Error("zip missing");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "TownReporter.zip";
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return "saved";
}

export function SourceZipButton({
  children,
  className,
}: {
  children: React.ReactNode;
  className: string;
}) {
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button
        type="button"
        className={className}
        onClick={() => {
          void saveSourceZip()
            .then(() => {
              setMsg("Save dialog should have opened. If it did not, this preview blocks downloads.");
            })
            .catch(() => {
              setMsg("Could not fetch the archive.");
            });
        }}
      >
        {children}
      </button>
      {msg && <span className="max-w-xs text-xs text-ink-2">{msg}</span>}
    </span>
  );
}
