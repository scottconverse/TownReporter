import { assertHttpUrl, fetchPublicHttp } from "./fetch-url.ts";

export type WebHit = { title: string; url: string; snippet: string };

export function parseDdgHtml(html: string): WebHit[] {
  const hits: WebHit[] = [];
  const seen = new Set<string>();
  const re =
    /uddg=([^&"]+)[^>]*>[\s\S]{0,40}?(?:class="result__a"[^>]*>)?([^<]{0,180})/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    let url = "";
    try {
      url = decodeURIComponent(m[1]!);
    } catch {
      continue;
    }
    const title = m[2]!.replace(/<[^>]+>/g, "").trim();
    if (!url.startsWith("http")) continue;
    if (seen.has(url)) continue;
    seen.add(url);
    hits.push({ title: title || url, url, snippet: "" });
    if (hits.length >= 8) break;
  }
  if (hits.length === 0) {
    const hrefs = html.matchAll(/href="(https?:\/\/[^"]+)"/gi);
    for (const h of hrefs) {
      const url = h[1]!;
      if (/duckduckgo\.com|javascript:/i.test(url)) continue;
      if (seen.has(url)) continue;
      seen.add(url);
      hits.push({ title: url, url, snippet: "" });
      if (hits.length >= 8) break;
    }
  }
  return hits.filter((h) => {
    try {
      assertHttpUrl(h.url);
      return true;
    } catch {
      return false;
    }
  });
}

export function parseWaybackCdx(raw: string): string[] {
  const out: string[] = [];
  try {
    const data = JSON.parse(raw) as unknown;
    if (!Array.isArray(data)) return out;
    for (const row of data.slice(1, 8)) {
      if (!Array.isArray(row) || row.length < 3) continue;
      const ts = String(row[1] ?? "");
      const original = String(row[2] ?? "");
      if (ts && original) out.push(`https://web.archive.org/web/${ts}/${original}`);
    }
  } catch {
    const lines = raw.split("\n").filter(Boolean);
    for (const line of lines.slice(0, 6)) {
      const parts = line.split(/\s+/);
      if (parts.length >= 3) out.push(`https://web.archive.org/web/${parts[1]}/${parts[2]}`);
    }
  }
  return out.filter((u) => {
    try {
      assertHttpUrl(u);
      return true;
    } catch {
      return false;
    }
  });
}

export async function webSearch(query: string): Promise<WebHit[]> {
  const q = query.trim().slice(0, 180);
  if (!q) return [];
  const url = new URL("https://html.duckduckgo.com/html/");
  url.searchParams.set("q", q);
  try {
    const res = await fetchPublicHttp(url);
    const html = await res.text();
    return parseDdgHtml(html);
  } catch {
    return [];
  }
}

export async function waybackCopies(target: string): Promise<string[]> {
  try {
    const api = new URL("https://web.archive.org/cdx/search/cdx");
    api.searchParams.set("url", target);
    api.searchParams.set("output", "json");
    api.searchParams.set("limit", "5");
    api.searchParams.set("filter", "statuscode:200");
    const res = await fetchPublicHttp(api);
    return parseWaybackCdx(await res.text());
  } catch {
    return [];
  }
}
