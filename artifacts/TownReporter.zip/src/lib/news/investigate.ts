import { getSql } from "@/lib/db";
import { grokChat, parseJsonBlock } from "./ai";
import { DARK_PLANNER } from "./dark-prompt";
import {
  classifyClaimKind,
  detectMissingCadence,
  diffExcerpt,
  extractReferences,
  heuristicPlan as heuristicFromText,
  queriesForRef,
  type ExtractedRef,
} from "./extract";
import { sha256 } from "./fetch-url";
import { ingestUrl } from "./ingest";
import { waybackCopies, webSearch, type WebHit } from "./search-web";
import { sanitizePublicUrls } from "./schema";

export const HOPS_PER_RUN = 5;
export const SEARCHES_PER_HOP = 3;
export const FETCHES_PER_HOP = 4;

export type HopPlan = {
  searches: string[];
  fetch_urls: string[];
  entities: { name: string; kind: string; why: string }[];
  relationships: { from: string; to: string; kind: string; evidence: string }[];
  hypotheses: { text: string; supporting: string; contradicting: string }[];
  claims: { text: string; kind: string; evidence: string; source_url?: string; confidence?: number }[];
  frontier: { label: string; kind: string; why: string; priority: number; queries?: string[] }[];
  anomalies: { kind: string; summary: string; url?: string }[];
  dead_ends: { hypothesis: string; reason: string }[];
  questions: string[];
  stop: boolean;
  summary: string;
};

export type SearchFn = (query: string) => Promise<WebHit[]>;
export type FetchFn = (url: string) => Promise<{
  ok: boolean;
  status: number;
  text: string;
  title: string;
  extras: string[];
}>;
export type PlannerFn = (pack: string) => Promise<HopPlan>;

const SCHEMA_SQL = `
alter table snapshots add column if not exists url text;
alter table snapshots add column if not exists fetch_status integer;
alter table leads add column if not exists investigation_id integer;
create table if not exists investigations (
  id serial primary key,
  user_id text not null,
  title text not null,
  status text not null default 'open',
  summary text not null default '',
  hops integer not null default 0,
  budget integer not null default 5,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists frontier_items (
  id serial primary key,
  user_id text not null,
  investigation_id integer not null,
  kind text not null,
  label text not null,
  why text not null default '',
  evidence text not null default '',
  priority integer not null default 5,
  queries_tried text not null default '[]',
  next_steps text not null default '',
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create table if not exists artifacts (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  url text not null,
  referrer_url text,
  query text,
  title text not null default '',
  content_type text not null default 'html',
  content_hash text not null,
  full_text text not null default '',
  classification text not null default 'discovered',
  fetch_status integer,
  created_at timestamptz not null default now()
);
create table if not exists entities (
  id serial primary key,
  user_id text not null,
  canonical text not null,
  name text not null,
  kind text not null,
  why text not null default '',
  unique (user_id, canonical)
);
create table if not exists relationships (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  from_name text not null,
  to_name text not null,
  kind text not null,
  evidence text not null default '',
  source_url text,
  created_at timestamptz not null default now()
);
create table if not exists claims (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  body text not null,
  kind text not null,
  evidence text not null default '',
  source_url text,
  confidence numeric,
  created_at timestamptz not null default now()
);
create table if not exists hypotheses (
  id serial primary key,
  user_id text not null,
  investigation_id integer not null,
  body text not null,
  supporting text not null default '',
  contradicting text not null default '',
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create table if not exists anomalies (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  kind text not null,
  summary text not null,
  url text,
  details text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists dead_ends (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  hypothesis text not null,
  why_interesting text not null default '',
  searches text not null default '',
  entities text not null default '',
  dismissed_because text not null default '',
  unresolved text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists search_log (
  id serial primary key,
  user_id text not null,
  investigation_id integer not null,
  hop integer not null,
  query text not null,
  results_json text not null default '[]',
  created_at timestamptz not null default now()
);
create table if not exists recurring_baselines (
  id serial primary key,
  user_id text not null,
  key text not null,
  kind text not null,
  cadence_days integer not null default 30,
  last_seen timestamptz,
  typical_title text not null default '',
  typical_url text not null default '',
  unique (user_id, key)
);
`;

export async function ensureInvestigateSchema() {
  const sql = await getSql();
  for (const stmt of SCHEMA_SQL.split(";").map((s) => s.trim()).filter(Boolean)) {
    try {
      await sql.query(stmt);
    } catch {
      /* already exists / older PGLite */
    }
  }
}

function canonical(name: string) {
  return name.trim().toLowerCase().replace(/\s+/g, " ").slice(0, 160);
}

export function emptyPlan(): HopPlan {
  return {
    searches: [],
    fetch_urls: [],
    entities: [],
    relationships: [],
    hypotheses: [],
    claims: [],
    frontier: [],
    anomalies: [],
    dead_ends: [],
    questions: [],
    stop: false,
    summary: "",
  };
}

export function heuristicPlan(text: string, tried: Set<string>): HopPlan {
  const h = heuristicFromText(text, tried, SEARCHES_PER_HOP, FETCHES_PER_HOP);
  const plan = emptyPlan();
  plan.searches = h.searches;
  plan.fetch_urls = sanitizePublicUrls(h.fetch_urls);
  plan.frontier = h.frontier;
  plan.summary = h.summary;
  return plan;
}

function parsePlan(raw: unknown): HopPlan {
  const plan = emptyPlan();
  if (!raw || typeof raw !== "object") return plan;
  const o = raw as Record<string, unknown>;
  plan.searches = Array.isArray(o.searches) ? o.searches.map(String).slice(0, 8) : [];
  plan.fetch_urls = sanitizePublicUrls(o.fetch_urls).slice(0, 10);
  plan.stop = Boolean(o.stop);
  plan.summary = String(o.summary ?? "").slice(0, 2000);
  plan.questions = Array.isArray(o.questions) ? o.questions.map(String).slice(0, 12) : [];
  const arr = <T>(key: string) => (Array.isArray(o[key]) ? (o[key] as T[]) : []);
  for (const e of arr<Record<string, unknown>>("entities")) {
    if (e?.name) plan.entities.push({ name: String(e.name), kind: String(e.kind ?? "unknown"), why: String(e.why ?? "") });
  }
  for (const r of arr<Record<string, unknown>>("relationships")) {
    if (r?.from && r?.to) {
      plan.relationships.push({
        from: String(r.from),
        to: String(r.to),
        kind: String(r.kind ?? "related"),
        evidence: String(r.evidence ?? ""),
      });
    }
  }
  for (const h of arr<Record<string, unknown>>("hypotheses")) {
    if (h?.text) {
      plan.hypotheses.push({
        text: String(h.text),
        supporting: String(h.supporting ?? ""),
        contradicting: String(h.contradicting ?? ""),
      });
    }
  }
  for (const c of arr<Record<string, unknown>>("claims")) {
    if (c?.text) {
      plan.claims.push({
        text: String(c.text),
        kind: classifyClaimKind(String(c.kind ?? "UNKNOWN")),
        evidence: String(c.evidence ?? ""),
        source_url: c.source_url ? String(c.source_url) : undefined,
        confidence: typeof c.confidence === "number" ? c.confidence : undefined,
      });
    }
  }
  for (const f of arr<Record<string, unknown>>("frontier")) {
    if (f?.label) {
      plan.frontier.push({
        label: String(f.label),
        kind: String(f.kind ?? "unknown"),
        why: String(f.why ?? ""),
        priority: Number(f.priority) || 5,
        queries: Array.isArray(f.queries) ? f.queries.map(String) : [],
      });
    }
  }
  for (const a of arr<Record<string, unknown>>("anomalies")) {
    if (a?.summary) {
      plan.anomalies.push({
        kind: String(a.kind ?? "anomaly"),
        summary: String(a.summary),
        url: a.url ? String(a.url) : undefined,
      });
    }
  }
  for (const d of arr<Record<string, unknown>>("dead_ends")) {
    if (d?.hypothesis) {
      plan.dead_ends.push({ hypothesis: String(d.hypothesis), reason: String(d.reason ?? "") });
    }
  }
  return plan;
}

export async function grokPlanner(pack: string): Promise<HopPlan> {
  const ai = await grokChat(DARK_PLANNER, pack.slice(0, 24000), 2200);
  if (!ai.ok) return heuristicPlan(pack, new Set());
  return parsePlan(parseJsonBlock<unknown>(ai.text));
}

async function defaultFetch(url: string): Promise<{
  ok: boolean;
  status: number;
  text: string;
  title: string;
  extras: string[];
}> {
  try {
    const bundle = await ingestUrl(url);
    return { ok: true, status: 200, text: bundle.text, title: bundle.titleHint, extras: bundle.extras };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "fetch failed";
    const status = /404|410/.test(msg) ? 404 : 0;
    return { ok: false, status, text: "", title: "", extras: [] };
  }
}

export async function seedInvestigation(
  userId: string,
  investigationId: number,
  paste: string,
  snapshotBits: { title: string; url: string; excerpt: string }[],
) {
  const sql = await getSql();
  if (paste.trim()) {
    const hash = await sha256(paste);
    await sql`
      insert into artifacts (
        user_id, investigation_id, url, title, content_hash, full_text, classification, fetch_status
      ) values (
        ${userId}, ${investigationId}, ${"editor://paste"}, ${"Editor paste"},
        ${hash}, ${paste.slice(0, 40000)}, ${"watch"}, ${200}
      )
    `;
  }
  for (const snap of snapshotBits.slice(0, 20)) {
    const hash = await sha256(snap.excerpt);
    await sql`
      insert into artifacts (
        user_id, investigation_id, url, title, content_hash, full_text, classification, fetch_status
      ) values (
        ${userId}, ${investigationId}, ${snap.url}, ${snap.title},
        ${hash}, ${snap.excerpt.slice(0, 40000)}, ${"watch"}, ${200}
      )
    `;
    const refs = extractReferences(`${snap.title}\n${snap.excerpt}`);
    await addFrontierFromRefs(userId, investigationId, refs, snap.url);
  }
  if (paste.trim()) {
    await addFrontierFromRefs(userId, investigationId, extractReferences(paste), "editor://paste");
  }
}

async function addFrontierFromRefs(
  userId: string,
  investigationId: number,
  refs: ExtractedRef[],
  evidence: string,
) {
  const sql = await getSql();
  for (const ref of refs.slice(0, 30)) {
    const existing = await sql<{ id: number }>`
      select id from frontier_items
      where investigation_id = ${investigationId} and user_id = ${userId}
        and label = ${ref.value} limit 1
    `;
    if (existing[0]) continue;
    await sql`
      insert into frontier_items (
        user_id, investigation_id, kind, label, why, evidence, priority, next_steps
      ) values (
        ${userId}, ${investigationId}, ${ref.kind}, ${ref.value},
        ${"Referenced in evidence"}, ${evidence.slice(0, 400)},
        ${ref.kind === "company" || ref.kind === "url" ? 9 : 6},
        ${queriesForRef(ref).join(" | ").slice(0, 500)}
      )
    `;
  }
}

export async function researchLoop(opts: {
  userId: string;
  investigationId: number;
  hops?: number;
  search?: SearchFn;
  fetch?: FetchFn;
  planner?: PlannerFn;
}): Promise<{ hops: number; artifacts: number; frontier: number; paused: boolean; summary: string }> {
  const sql = await getSql();
  const hopsBudget = opts.hops ?? HOPS_PER_RUN;
  const search = opts.search ?? webSearch;
  const fetchDoc = opts.fetch ?? defaultFetch;
  const planner = opts.planner;
  const tried = new Set<string>();
  const priorQueries = await sql<{ query: string }>`
    select query from search_log where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
  `;
  for (const q of priorQueries) tried.add(q.query);

  let hopsDone = 0;
  let lastSummary = "";

  for (let hop = 0; hop < hopsBudget; hop++) {
    const arts = await sql<{ url: string; title: string; full_text: string }>`
      select url, title, full_text from artifacts
      where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
      order by id desc limit 8
    `;
    const frontier = await sql<{ label: string; kind: string; why: string; priority: number; next_steps: string }>`
      select label, kind, why, priority, next_steps from frontier_items
      where investigation_id = ${opts.investigationId} and user_id = ${opts.userId} and status = 'open'
      order by priority desc, id asc limit 12
    `;
    const pack = [
      `INVESTIGATION ${opts.investigationId}. Hop ${hop + 1}. Longmont, Colorado.`,
      `FRONTIER:\n${frontier.map((f) => `${f.priority} ${f.kind}: ${f.label} — ${f.why} next:${f.next_steps}`).join("\n") || "(empty)"}`,
      `RECENT ARTIFACTS:\n${arts.map((a) => `### ${a.title}\n${a.url}\n${a.full_text.slice(0, 2200)}`).join("\n\n") || "(none)"}`,
      `QUERIES ALREADY TRIED:\n${[...tried].slice(-40).join("\n") || "(none)"}`,
      `Generate the NEXT searches and fetches. Follow names, companies, contracts, parcels. Search contradictions. Do not stop after one hop.`,
    ].join("\n\n");

    let plan: HopPlan;
    if (planner) plan = await planner(pack);
    else {
      const grok = await grokPlanner(pack);
      const heur = heuristicPlan(arts.map((a) => a.full_text).join("\n"), tried);
      plan = grok.searches.length || grok.fetch_urls.length ? grok : heur;
      if (!plan.searches.length && heur.searches.length) plan.searches = heur.searches;
      if (!plan.fetch_urls.length && heur.fetch_urls.length) plan.fetch_urls = heur.fetch_urls;
      plan.frontier = [...plan.frontier, ...heur.frontier];
    }

    lastSummary = plan.summary;
    const queries = plan.searches.filter((q) => q && !tried.has(q)).slice(0, SEARCHES_PER_HOP);
    const toFetch = new Set<string>(plan.fetch_urls);

    for (const q of queries) {
      tried.add(q);
      let hits: WebHit[] = [];
      try {
        hits = await search(q);
      } catch {
        hits = [];
      }
      await sql`
        insert into search_log (user_id, investigation_id, hop, query, results_json)
        values (${opts.userId}, ${opts.investigationId}, ${hop + 1}, ${q.slice(0, 300)}, ${JSON.stringify(hits).slice(0, 8000)})
      `;
      for (const hit of hits.slice(0, 4)) toFetch.add(hit.url);
    }

    const urls = sanitizePublicUrls([...toFetch]).slice(0, FETCHES_PER_HOP);
    for (const url of urls) {
      const prior = await sql<{ content_hash: string; full_text: string; fetch_status: number | null }>`
        select content_hash, full_text, fetch_status from artifacts
        where user_id = ${opts.userId} and url = ${url}
        order by id desc limit 1
      `;
      const got = await fetchDoc(url);
      if (!got.ok) {
        await sql`
          insert into artifacts (
            user_id, investigation_id, url, title, content_hash, full_text, classification, fetch_status
          ) values (
            ${opts.userId}, ${opts.investigationId}, ${url}, ${url},
            ${"missing"}, ${""}, ${"discovered"}, ${got.status || 0}
          )
        `;
        if (prior[0] && prior[0].fetch_status === 200) {
          await sql`
            insert into anomalies (user_id, investigation_id, kind, summary, url, details)
            values (
              ${opts.userId}, ${opts.investigationId}, ${"disappeared"},
              ${`Previously captured document is gone: ${url}`},
              ${url},
              ${`Prior hash ${prior[0].content_hash}. Status ${got.status}. Original retained.`}
            )
          `;
          try {
            const copies = await waybackCopies(url);
            for (const c of copies.slice(0, 2)) toFetch.add(c);
          } catch {
            /* archive optional */
          }
        }
        continue;
      }
      const hash = await sha256(got.text);
      if (prior[0]?.content_hash === hash) continue;
      if (prior[0] && prior[0].content_hash !== hash && prior[0].full_text) {
        const delta = diffExcerpt(prior[0].full_text, got.text);
        if (delta) {
          await sql`
            insert into anomalies (user_id, investigation_id, kind, summary, url, details)
            values (
              ${opts.userId}, ${opts.investigationId}, ${"changed"},
              ${`Document changed: ${url}`}, ${url}, ${delta.slice(0, 4000)}
            )
          `;
        }
      }
      await sql`
        insert into artifacts (
          user_id, investigation_id, url, title, content_hash, full_text,
          classification, fetch_status
        ) values (
          ${opts.userId}, ${opts.investigationId}, ${url}, ${got.title.slice(0, 200)},
          ${hash}, ${got.text.slice(0, 40000)}, ${"discovered"}, ${got.status}
        )
      `;
      for (const extra of got.extras.slice(0, 4)) toFetch.add(extra);
      await addFrontierFromRefs(
        opts.userId,
        opts.investigationId,
        extractReferences(got.text),
        url,
      );
    }

    await persistPlan(opts.userId, opts.investigationId, plan);

    hopsDone += 1;
    await sql`
      update investigations
      set hops = hops + 1, summary = ${lastSummary.slice(0, 2500)}, updated_at = now()
      where id = ${opts.investigationId} and user_id = ${opts.userId}
    `;

    const open = await sql<{ c: number }>`
      select count(*)::int as c from frontier_items
      where investigation_id = ${opts.investigationId} and user_id = ${opts.userId} and status = 'open'
    `;
    if (plan.stop && (open[0]?.c ?? 0) === 0) break;
  }

  const open = await sql<{ c: number }>`
    select count(*)::int as c from frontier_items
    where investigation_id = ${opts.investigationId} and user_id = ${opts.userId} and status = 'open'
  `;
  const artsN = await sql<{ c: number }>`
    select count(*)::int as c from artifacts
    where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
  `;
  const paused = (open[0]?.c ?? 0) > 0;
  await sql`
    update investigations
    set status = ${paused ? "paused" : "open"}, updated_at = now()
    where id = ${opts.investigationId} and user_id = ${opts.userId}
  `;
  return {
    hops: hopsDone,
    artifacts: artsN[0]?.c ?? 0,
    frontier: open[0]?.c ?? 0,
    paused,
    summary: lastSummary,
  };
}

async function persistPlan(userId: string, investigationId: number, plan: HopPlan) {
  const sql = await getSql();
  for (const e of plan.entities) {
    const c = canonical(e.name);
    if (!c) continue;
    await sql`
      insert into entities (user_id, canonical, name, kind, why)
      values (${userId}, ${c}, ${e.name.slice(0, 200)}, ${e.kind.slice(0, 40)}, ${e.why.slice(0, 800)})
      on conflict (user_id, canonical) do update set why = excluded.why
    `;
  }
  for (const r of plan.relationships) {
    await sql`
      insert into relationships (user_id, investigation_id, from_name, to_name, kind, evidence)
      values (
        ${userId}, ${investigationId}, ${r.from.slice(0, 200)}, ${r.to.slice(0, 200)},
        ${r.kind.slice(0, 80)}, ${r.evidence.slice(0, 2000)}
      )
    `;
  }
  for (const h of plan.hypotheses) {
    await sql`
      insert into hypotheses (user_id, investigation_id, body, supporting, contradicting)
      values (
        ${userId}, ${investigationId}, ${h.text.slice(0, 2000)},
        ${h.supporting.slice(0, 2000)}, ${h.contradicting.slice(0, 2000)}
      )
    `;
  }
  for (const c of plan.claims) {
    const conf = c.confidence;
    await sql`
      insert into claims (user_id, investigation_id, body, kind, evidence, source_url, confidence)
      values (
        ${userId}, ${investigationId}, ${c.text.slice(0, 2000)}, ${c.kind},
        ${c.evidence.slice(0, 2000)}, ${c.source_url ?? null}, ${conf ?? null}
      )
    `;
  }
  for (const f of plan.frontier) {
    const existing = await sql<{ id: number }>`
      select id from frontier_items
      where investigation_id = ${investigationId} and user_id = ${userId} and label = ${f.label.slice(0, 240)}
      limit 1
    `;
    if (existing[0]) continue;
    await sql`
      insert into frontier_items (
        user_id, investigation_id, kind, label, why, priority, next_steps
      ) values (
        ${userId}, ${investigationId}, ${f.kind.slice(0, 40)}, ${f.label.slice(0, 240)},
        ${f.why.slice(0, 800)}, ${Math.min(15, Math.max(1, f.priority))},
        ${(f.queries ?? []).join(" | ").slice(0, 500)}
      )
    `;
  }
  for (const a of plan.anomalies) {
    await sql`
      insert into anomalies (user_id, investigation_id, kind, summary, url, details)
      values (
        ${userId}, ${investigationId}, ${a.kind.slice(0, 40)}, ${a.summary.slice(0, 1000)},
        ${a.url ?? null}, ${""}
      )
    `;
  }
  for (const d of plan.dead_ends) {
    await sql`
      insert into dead_ends (user_id, investigation_id, hypothesis, dismissed_because)
      values (${userId}, ${investigationId}, ${d.hypothesis.slice(0, 1000)}, ${d.reason.slice(0, 2000)})
    `;
  }
}

export async function matchDeadEnds(userId: string, names: string[]) {
  const sql = await getSql();
  const rows = await sql<{ id: number; hypothesis: string; dismissed_because: string; entities: string }>`
    select id, hypothesis, dismissed_because, entities from dead_ends
    where user_id = ${userId} order by created_at desc limit 80
  `;
  const lower = names.map((n) => n.toLowerCase());
  return rows.filter((r) => {
    const blob = `${r.hypothesis} ${r.entities}`.toLowerCase();
    return lower.some((n) => n.length > 3 && blob.includes(n));
  });
}

export async function checkBaselines(userId: string, investigationId: number) {
  const sql = await getSql();
  const rows = await sql<{ key: string; typical_title: string; typical_url: string; cadence_days: number; last_seen: string | null }>`
    select key, typical_title, typical_url, cadence_days, last_seen::text as last_seen
    from recurring_baselines where user_id = ${userId}
  `;
  const events = rows
    .filter((r) => r.last_seen)
    .map((r) => ({
      key: r.key,
      at: new Date(r.last_seen!),
      title: r.typical_title,
      url: r.typical_url,
    }));
  const missing = detectMissingCadence(events, new Date(), 30, 7);
  for (const m of missing) {
    await sql`
      insert into anomalies (user_id, investigation_id, kind, summary, url, details)
      values (
        ${userId}, ${investigationId}, ${"missing-cadence"},
        ${`Expected recurring record is late: ${m.title || m.key} (${m.daysLate} days past cadence)`},
        ${m.url || null},
        ${`Last seen ${m.lastSeen.toISOString()}. Search for cancellation, rename, archive.`}
      )
    `;
    await sql`
      insert into frontier_items (user_id, investigation_id, kind, label, why, priority, next_steps)
      values (
        ${userId}, ${investigationId}, ${"missing-record"}, ${m.title || m.key},
        ${"Dog that didn't bark — expected cadence broken"}, ${12},
        ${`${m.title} ${m.url} cancellation OR rescheduled OR archive`}
      )
    `;
  }
  return missing.length;
}

export { detectMissingCadence };
