import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  discoverDocLinks,
  extractPdfText,
  mapLimit,
  parseRssItems,
  withRetry,
} from "./ingest.ts";

describe("extractPdfText", () => {
  it("pulls Tj strings from uncompressed civic packets", () => {
    const pdf = Buffer.from(
      "%PDF-1.4\nBT /F1 12 Tf (City Council voted 5-2 on the NextLight rate) Tj ET\n",
      "latin1",
    );
    assert.match(extractPdfText(pdf), /City Council voted 5-2 on the NextLight rate/);
  });
});

describe("discoverDocLinks", () => {
  it("follows public agenda/pdf links across origins and drops javascript", () => {
    const html = [
      '<a href="/government/agendas/packet.pdf">packet</a>',
      '<a href="https://civicclerk.example/agenda.pdf">vendor packet</a>',
      '<a href="javascript:alert(1)">no</a>',
      '<a href="/about">no</a>',
      '<a href="minutes.html">minutes</a>',
    ].join("");
    const found = discoverDocLinks(html, new URL("https://www.longmontcolorado.gov/gov"));
    assert.ok(found.includes("https://www.longmontcolorado.gov/government/agendas/packet.pdf"));
    assert.ok(found.includes("https://www.longmontcolorado.gov/minutes.html"));
    assert.ok(found.includes("https://civicclerk.example/agenda.pdf"));
    assert.equal(found.some((u) => u.startsWith("javascript:")), false);
  });
});

describe("parseRssItems", () => {
  it("reads rss item title, link, summary", () => {
    const xml = `<?xml version="1.0"?>
      <rss><channel>
        <item>
          <title>Budget hearing</title>
          <link>https://www.longmontcolorado.gov/b</link>
          <description>Council will take public comment.</description>
        </item>
      </channel></rss>`;
    const items = parseRssItems(xml);
    assert.equal(items.length, 1);
    assert.equal(items[0]!.title, "Budget hearing");
    assert.equal(items[0]!.link, "https://www.longmontcolorado.gov/b");
    assert.match(items[0]!.summary, /public comment/);
  });
});

describe("mapLimit", () => {
  it("runs with a concurrency cap and preserves order", async () => {
    let inflight = 0;
    let max = 0;
    const out = await mapLimit([1, 2, 3, 4, 5], 2, async (n) => {
      inflight += 1;
      max = Math.max(max, inflight);
      await new Promise((r) => setTimeout(r, 15));
      inflight -= 1;
      return n * 10;
    });
    assert.deepEqual(out, [10, 20, 30, 40, 50]);
    assert.ok(max <= 2);
  });
});

describe("withRetry", () => {
  it("does not retry SSRF / invalid URL", async () => {
    let n = 0;
    await assert.rejects(
      () =>
        withRetry(async () => {
          n += 1;
          throw new Error("That host is not fetchable");
        }),
      /not fetchable/,
    );
    assert.equal(n, 1);
  });

  it("retries a transient failure once", async () => {
    let n = 0;
    const v = await withRetry(async () => {
      n += 1;
      if (n === 1) throw new Error("fetch failed (503)");
      return "ok";
    });
    assert.equal(v, "ok");
    assert.equal(n, 2);
  });
});
