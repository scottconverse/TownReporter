import { createFileRoute, Outlet } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

function Opening() {
  return (
    <div className="grid min-h-dvh place-items-center bg-desk px-6 text-ink">
      <p className="font-display text-2xl">Opening the desk…</p>
    </div>
  );
}

export const Route = createFileRoute("/desk")({
  component: DeskGate,
  pendingComponent: Opening,
});

function DeskGate() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Opening />;
  if (!user) return <RedirectToSignIn />;
  return (
    <div className="min-h-dvh bg-desk text-desk-ink">
      <Outlet />
    </div>
  );
}
