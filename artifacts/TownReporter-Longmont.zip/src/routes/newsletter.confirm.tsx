import { createFileRoute, Link } from "@tanstack/react-router";
import { confirmNewsletter } from "@/lib/news/public";
import { PaperShell } from "@/components/paper-chrome";

export const Route = createFileRoute("/newsletter/confirm")({
  validateSearch: (s: Record<string, unknown>) => ({
    token: typeof s.token === "string" ? s.token : "",
  }),
  loaderDeps: ({ search }) => ({ token: search.token }),
  loader: async ({ deps }) => {
    if (!deps.token) return { ok: false as const };
    return confirmNewsletter({ data: deps.token });
  },
  component: ConfirmPage,
});

function ConfirmPage() {
  const res = Route.useLoaderData();
  return (
    <PaperShell>
      <h1 className="font-display text-3xl font-semibold">Newsletter</h1>
      <p className="mt-4 max-w-xl text-ink-2">
        {res.ok
          ? "You’re confirmed. We’ll send new editions to that address."
          : "That confirmation link is invalid or already used."}
      </p>
      <Link to="/" className="mt-6 inline-block text-rust">
        Back to the paper
      </Link>
    </PaperShell>
  );
}
