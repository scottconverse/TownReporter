import { useState } from "react";

const HREF = "/TownReporter.zip";

export async function saveSourceZip(): Promise<"saved" | "opened" | "failed"> {
  try {
    const res = await fetch(HREF);
    if (!res.ok) throw new Error("zip missing");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "TownReporter.zip";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return "saved";
  } catch {
    const opened = window.open(HREF, "_blank", "noopener,noreferrer");
    return opened ? "opened" : "failed";
  }
}

export function SourceZipButton({
  children,
  className,
}: {
  children: React.ReactNode;
  className: string;
}) {
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button
        type="button"
        className={className}
        onClick={() => {
          void saveSourceZip().then((r) => {
            if (r === "failed") {
              setMsg("Blocked here. Open the preview in a new tab, then go to /TownReporter.zip");
            } else if (r === "opened") {
              setMsg("Opened in a new tab — save from there.");
            } else {
              setMsg("If a save dialog didn’t appear, open the preview in a new tab and visit /TownReporter.zip");
            }
          });
        }}
      >
        {children}
      </button>
      {msg && <span className="max-w-xs text-xs text-ink-2">{msg}</span>}
    </span>
  );
}
