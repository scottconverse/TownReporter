import type { ErrorComponentProps } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { TriangleAlert } from "lucide-react";

export function AppErrorComponent({ error }: ErrorComponentProps) {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-paper px-6 text-center text-ink">
      <span className="text-rust" aria-hidden="true">
        <TriangleAlert className="size-10" strokeWidth={2} />
      </span>
      <h1 className="font-display text-2xl font-semibold">Something went wrong</h1>
      <p className="max-w-md text-sm break-words text-muted">
        {error.message || "An unexpected error occurred. Try reloading the page."}
      </p>
      <Link to="/" className="mt-2 text-sm text-rust hover:text-rust-2">
        Back to the paper
      </Link>
    </main>
  );
}

export function AppNotFound() {
  return (
    <main className="grid min-h-dvh place-items-center bg-paper px-6 text-ink">
      <div className="max-w-md text-center">
        <p className="text-[11px] tracking-[0.16em] text-rust uppercase">TownReporter</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">No page here</h1>
        <p className="mt-3 text-ink-2">
          That address is not in this edition. The paper is on the front page.
          The desk is behind sign-in.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link
            to="/"
            className="inline-flex min-h-11 items-center bg-ink px-4 text-sm text-paper hover:bg-ink-2"
          >
            Open the paper
          </Link>
          <Link
            to="/desk"
            className="inline-flex min-h-11 items-center border border-ink px-4 text-sm hover:bg-paper-2"
          >
            Editor desk
          </Link>
        </div>
      </div>
    </main>
  );
}

export function AppPending() {
  return (
    <div className="grid min-h-dvh place-items-center bg-paper px-6 text-ink">
      <p className="font-display text-2xl">Opening…</p>
    </div>
  );
}
