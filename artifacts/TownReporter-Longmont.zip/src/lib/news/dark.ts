import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { deskMiddleware } from "./desk-auth";
import { grokChat, parseJsonBlock } from "./ai";
import { DARK_SYSTEM } from "./dark-prompt";
import { assertRate, audit } from "./ops";
import type { ArticleRow, MemoryRow, SourceRow } from "./types";

export type DarkSignalRow = {
  id: number;
  run_id: number | null;
  name: string;
  posture: string;
  signal_type: string;
  strength: number;
  confidence: number;
  observation: string;
  pattern: string;
  linkage_map: string;
  alternatives: string;
  counter_narrative: string;
  what_would_kill: string;
  pathway: string;
  privacy_review: string;
  handoff: string;
  created_at: string;
};

export type DarkRunRow = {
  id: number;
  started_at: string;
  finished_at: string | null;
  summary: string | null;
  error: string | null;
};

export type DarkPromiseRow = {
  id: number;
  who_promised: string;
  what: string;
  when_due: string | null;
  source_cite: string | null;
  status: string;
  created_at: string;
};

const HANDOFFS = new Set([
  "DISCARD",
  "HOLD FOR PATTERN",
  "MONITOR",
  "FOR VERIFICATION",
]);

type DarkJson = {
  window?: string;
  inventory_gaps?: string[];
  editor_summary?: string;
  promises?: {
    who?: string;
    what?: string;
    when_due?: string;
    source_cite?: string;
    status?: string;
  }[];
  signals?: {
    name?: string;
    posture?: string;
    type?: string;
    strength?: number;
    confidence?: number;
    observation?: string;
    pattern?: string;
    linkage_map?: string;
    alternatives?: string;
    counter_narrative?: string;
    what_would_kill?: string;
    pathway?: string;
    privacy_review?: string;
    handoff?: string;
  }[];
};

async function ensureDarkSchema() {
  const sql = await getSql();
  await sql.query(`
    create table if not exists dark_runs (
      id serial primary key,
      user_id text not null,
      started_at timestamptz not null default now(),
      finished_at timestamptz,
      summary text,
      error text
    )
  `);
  await sql.query(
    `create index if not exists dark_runs_user_idx on dark_runs (user_id, started_at desc)`,
  );
  await sql.query(`
    create table if not exists dark_signals (
      id serial primary key,
      user_id text not null,
      run_id integer references dark_runs(id) on delete set null,
      name text not null,
      posture text not null,
      signal_type text not null,
      strength integer not null default 3,
      confidence numeric not null default 0.3,
      observation text not null default '',
      pattern text not null default '',
      linkage_map text not null default '',
      alternatives text not null default '',
      counter_narrative text not null default '',
      what_would_kill text not null default '',
      pathway text not null default '',
      privacy_review text not null default '',
      handoff text not null default 'HOLD FOR PATTERN',
      created_at timestamptz not null default now()
    )
  `);
  await sql.query(
    `create index if not exists dark_signals_user_idx on dark_signals (user_id, created_at desc)`,
  );
  await sql.query(`
    create table if not exists dark_promises (
      id serial primary key,
      user_id text not null,
      who_promised text not null,
      what text not null,
      when_due text,
      source_cite text,
      status text not null default 'open',
      created_at timestamptz not null default now()
    )
  `);
  await sql.query(
    `create index if not exists dark_promises_user_idx on dark_promises (user_id, created_at desc)`,
  );
}

export const listDarkSignals = createServerFn({ method: "GET" })
  .middleware([deskMiddleware])
  .handler(async ({ context }) => {
    await ensureDarkSchema();
    const sql = await getSql();
    return sql<DarkSignalRow>`
      select id, run_id, name, posture, signal_type, strength, confidence,
        observation, pattern, linkage_map, alternatives, counter_narrative,
        what_would_kill, pathway, privacy_review, handoff, created_at
      from dark_signals
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
  });

export const listDarkRuns = createServerFn({ method: "GET" })
  .middleware([deskMiddleware])
  .handler(async ({ context }) => {
    await ensureDarkSchema();
    const sql = await getSql();
    return sql<DarkRunRow>`
      select id, started_at, finished_at, summary, error
      from dark_runs
      where user_id = ${context.userId}
      order by started_at desc
      limit 12
    `;
  });

export const listDarkPromises = createServerFn({ method: "GET" })
  .middleware([deskMiddleware])
  .handler(async ({ context }) => {
    await ensureDarkSchema();
    const sql = await getSql();
    return sql<DarkPromiseRow>`
      select id, who_promised, what, when_due, source_cite, status, created_at
      from dark_promises
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
  });

export const runDarkDesk = createServerFn({ method: "POST" })
  .middleware([deskMiddleware])
  .validator((input: { paste: string }) => input)
  .handler(async ({ context, data }) => {
    await ensureDarkSchema();
    await assertRate(context.userId, "dark");
    const sql = await getSql();
    const runRows = await sql<{ id: number }>`
      insert into dark_runs (user_id) values (${context.userId}) returning id
    `;
    const runId = runRows[0]!.id;

    const sources = await sql<SourceRow>`
      select id, url, title, kind, tier, status, last_hash, last_fetched_at, last_error
      from sources where user_id = ${context.userId}
      order by id asc
    `;
    const snaps = await sql<{ title: string; url: string; excerpt: string }>`
      select s.title, s.url, snap.excerpt
      from snapshots snap
      join sources s on s.id = snap.source_id
      where snap.user_id = ${context.userId}
      order by snap.id desc
      limit 16
    `;
    const leads = await sql<{ headline: string; why: string; topic: string; status: string }>`
      select headline, why, topic, status
      from leads where user_id = ${context.userId}
      order by created_at desc limit 12
    `;
    const articles = await sql<Pick<ArticleRow, "headline" | "topic" | "published_at">>`
      select headline, topic, published_at from articles
      where user_id = ${context.userId} and status = 'published'
      order by published_at desc limit 10
    `;
    const memory = await sql<MemoryRow>`
      select entity, last_angle from beat_memory
      where user_id = ${context.userId} order by updated_at desc limit 16
    `;

    const paste = data.paste.trim().slice(0, 14000);
    const pack = [
      `CITY: Longmont, Colorado. One-shot Dark Desk. Do not invent meetings, votes, or dollars not in this packet.`,
      `WATCH LIST:\n${sources.map((s) => `${s.tier} ${s.status} ${s.title} ${s.url}`).join("\n") || "(empty)"}`,
      `SCAN SNAPSHOTS:\n${snaps.map((s) => `### ${s.title}\n${s.url}\n${s.excerpt.slice(0, 1800)}`).join("\n\n") || "(none — run a Scan first or paste minutes)"}`,
      `OPEN LEADS:\n${leads.map((l) => `${l.status} ${l.topic}: ${l.headline} — ${l.why}`).join("\n") || "(none)"}`,
      `PUBLISHED:\n${articles.map((a) => `${a.topic}: ${a.headline}`).join("\n") || "(none)"}`,
      `BEAT MEMORY:\n${memory.map((m) => `${m.entity}: ${m.last_angle}`).join("\n") || "(none)"}`,
      paste ? `EDITOR PASTE (treat as alleged text to interrogate, not as proof):\n${paste}` : "EDITOR PASTE: (none)",
    ].join("\n\n");

    const ai = await grokChat(DARK_SYSTEM, pack.slice(0, 28000), 3200);
    if (!ai.ok) {
      await sql`
        update dark_runs set finished_at = now(), error = ${ai.error}
        where id = ${runId} and user_id = ${context.userId}
      `;
      return { ok: false as const, error: ai.error };
    }

    const parsed = parseJsonBlock<DarkJson>(ai.text) ?? {};
    const summary = String(parsed.editor_summary ?? "").slice(0, 2000);
    const gaps = (parsed.inventory_gaps ?? []).join("; ").slice(0, 800);
    const header = [summary, gaps ? `Gaps: ${gaps}` : "", parsed.window ? `Window: ${parsed.window}` : ""]
      .filter(Boolean)
      .join("\n");

    let stored = 0;
    for (const sig of parsed.signals ?? []) {
      const name = String(sig.name ?? "").trim();
      if (!name) continue;
      const strength = Math.min(15, Math.max(3, Number(sig.strength) || 3));
      const confidence = Math.min(0.5, Math.max(0.1, Number(sig.confidence) || 0.3));
      let handoff = String(sig.handoff ?? "HOLD FOR PATTERN").toUpperCase();
      if (!HANDOFFS.has(handoff)) handoff = "HOLD FOR PATTERN";
      await sql`
        insert into dark_signals (
          user_id, run_id, name, posture, signal_type, strength, confidence,
          observation, pattern, linkage_map, alternatives, counter_narrative,
          what_would_kill, pathway, privacy_review, handoff
        ) values (
          ${context.userId}, ${runId}, ${name.slice(0, 200)},
          ${String(sig.posture ?? "").slice(0, 80)},
          ${String(sig.type ?? "").slice(0, 80)},
          ${strength}, ${confidence},
          ${String(sig.observation ?? "").slice(0, 4000)},
          ${String(sig.pattern ?? "").slice(0, 4000)},
          ${String(sig.linkage_map ?? "").slice(0, 4000)},
          ${String(sig.alternatives ?? "").slice(0, 4000)},
          ${String(sig.counter_narrative ?? "").slice(0, 4000)},
          ${String(sig.what_would_kill ?? "").slice(0, 2000)},
          ${String(sig.pathway ?? "").slice(0, 2000)},
          ${String(sig.privacy_review ?? "").slice(0, 500)},
          ${handoff}
        )
      `;
      stored += 1;
    }

    for (const p of parsed.promises ?? []) {
      const who = String(p.who ?? "").trim();
      const what = String(p.what ?? "").trim();
      if (!who || !what) continue;
      await sql`
        insert into dark_promises (user_id, who_promised, what, when_due, source_cite, status)
        values (
          ${context.userId}, ${who.slice(0, 200)}, ${what.slice(0, 800)},
          ${String(p.when_due ?? "").slice(0, 120) || null},
          ${String(p.source_cite ?? "").slice(0, 400) || null},
          ${String(p.status ?? "open").slice(0, 40)}
        )
      `;
    }

    await sql`
      update dark_runs
      set finished_at = now(), summary = ${header.slice(0, 2500)}
      where id = ${runId} and user_id = ${context.userId}
    `;

    await audit(context.userId, "dark", `run ${runId} signals ${stored}`);
    return { ok: true as const, runId, stored, summary: header };
  });

export const sendDarkSignalToQueue = createServerFn({ method: "POST" })
  .middleware([deskMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data: id }) => {
    await ensureDarkSchema();
    const sql = await getSql();
    const rows = await sql<DarkSignalRow>`
      select id, run_id, name, posture, signal_type, strength, confidence,
        observation, pattern, linkage_map, alternatives, counter_narrative,
        what_would_kill, pathway, privacy_review, handoff, created_at
      from dark_signals where id = ${id} and user_id = ${context.userId} limit 1
    `;
    const sig = rows[0];
    if (!sig) return { ok: false as const, error: "Signal not found" };
    const why = [
      "DARK DESK — not a story. Question only. Confidence capped. Requires Tier A grounding before any draft.",
      `Posture: ${sig.posture}. Type: ${sig.signal_type}. Strength ${sig.strength} / confidence ${sig.confidence}.`,
      sig.observation,
      `Pathway: ${sig.pathway}`,
      `Alternatives: ${sig.alternatives}`,
    ]
      .filter(Boolean)
      .join("\n\n")
      .slice(0, 4000);
    await sql`
      insert into leads (user_id, headline, why, topic, status, source_urls, evidence, newsworthiness)
      values (
        ${context.userId},
        ${`[Dark] ${sig.name}`.slice(0, 240)},
        ${why},
        'council',
        'held',
        '[]',
        ${sig.observation.slice(0, 4000)},
        ${Math.min(20, sig.strength)}
      )
    `;
    await audit(context.userId, "dark-handoff", String(id));
    return { ok: true as const };
  });
