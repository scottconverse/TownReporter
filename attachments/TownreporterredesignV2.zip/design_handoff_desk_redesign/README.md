# Handoff: TownReporter editor desk redesign

## Overview
A full redesign of the signed-in editor desk at `/desk` — Overview, Sources, Scan, Queue, Story workbench, Dark Desk, plus a new **Published** surface — and a refresh of the public paper (front page + article). The core change: the Overview becomes a dense single-screen **command center** (queue, Dark Desk piles, scan/source/publication wire, all visible at once); every other page is a drill-in. Design brief honored throughout: plain-English copy, reading-list-first Dark Desk, no engine jargon (see `docs/dark-desk-editor.md` in the repo — its rules still apply).

## About the design files
The files in this bundle are **design references created in HTML/React (Babel, single-page prototype)** — they show intended look and behavior, not production code to copy. Recreate them in the repo's existing environment: **TanStack Router + React 19 + Tailwind 4** (`src/routes/desk.*.tsx`, `src/components/desk-chrome.tsx`, tokens in `src/styles.css`). Keep the existing server functions (`src/lib/news/desk.ts`, `dark.ts`) and copy layer (`desk-copy.ts`); this is a UI restructure, not an engine change.

## Fidelity
**High-fidelity.** Colors, type, spacing, and copy are final intent. Recreate pixel-close using the repo's Tailwind theme; the prototype's CSS custom properties map 1:1 onto the existing `@theme` tokens (see Design tokens).

## Information architecture
- Nav (in this order): **Desk · Sources · Scan · Queue · Published — [separator] — Dark Desk**.
  - `Desk` replaces "Overview". `Published` is new. `Memory` is removed as a nav item — corrections + beat memory fold into the Published page.
  - Dark Desk is visually separated: right-aligned after a flex spacer, rendered as a solid ink chip (`bg-ink text-paper`), active state shown with an inset 3px rust underline.
- Masthead: brand (Fraunces 24/700) + sub-label; centered italic dateline; right side "View paper" link + **Light/Dark** segmented control. Below: a thick-thin double rule (3px solid + 1px solid, 1px gap — classic newspaper furniture), then the nav row, then a 1px ink rule.
- Page container: max-width 1420px, 28px side padding (desk); paper uses 1000px.

## Screens

### 1. Desk (command center) — replaces `desk.index.tsx`
- **Kicker** "Command center" + h1 "The desk" (Fraunces 30/600, -0.015em).
- **"Needs you" strip**: 1px rules top/bottom, 7px vertical padding. Label `NEEDS YOU` (10px caps, 0.18em tracking, rust-2). **Actionable items only** — drafts ready to publish → Queue; stopped investigations with unopened counts → opens that Dark Desk file; proposed sources → Sources; failing sources → Sources; scan status appears here ONLY when stale (>24h) or failed — routine "last scan" status lives in the wire. The strip hides entirely when empty. Items prefixed by a 5px rust diamond; 12.5px text, hover = rust + underline.
- **Three-column board** (grid `1.35fr .95fr .9fr`, columns separated by 1px `--rule` vertical borders, 20px horizontal padding per column):
  - **Col 1 — The queue.** Section head (see Components) with count and a quiet "Full queue" link. Rows: score box · headline (Fraunces 15.5/600, hover rust-2) · why-line (12.5px, ink-2) · meta line (11.5px muted: `topic · age · from the scanner/from Dark Desk/filed by you`) · status chip right-aligned. Row actions (Open / Hold / Kill) appear on row hover (opacity 0→1, 150ms). Sorted by score desc; killed rows at 50% opacity.
  - **Col 2 — Dark Desk panel.** The one dark surface on the light page: night tokens (bg `#211812`, type `#f6f1e7`), padding 16/18. "Investigates. Never prints." note. Three piles inline: **To look at** (kind label 9.5px caps rust-light + title + Start digging), **On the desk** (status line "Stopped — more to read"/"Ready to continue", title, `N records · N still to open`, Open file), **Set aside** (count + "see the pile" link). "Open the desk" button in the head.
  - **Col 3 — The wire.** Blocks separated by 1px rules: **Last scan** (date · fetched · leads · proposed + italic summary, Run scan button in head, animated busy rule while running); **Source health** (count on watch, failing sources in danger color, proposed sources with inline Accept/Drop); **On the paper** (last 3 published, "· corrected" marker); **Beat memory** (top 4: bold entity + muted angle).

### 2. Queue — `desk.queue.tsx`
- Kicker "Leads", h1 "The queue", lede copy: "Everything that might be news, scored and sorted. The scanner and Dark Desk file leads here; so do you. Nothing prints until you open a lead and publish it."
- **File a lead** collapses into a `<details>` ("File a lead yourself") — it no longer dominates the page. Fields: Headline, Why now, Topic (select), Source URL (optional); validation ≥8 chars on headline/why; on success navigate to the story workbench.
- **Filter row**: chips `all / new / drafted / held / killed` with counts; active chip solid ink.
- Lead rows identical to command-center rows but roomier (14px vertical padding). Held rows get a "Back" action; killed rows dimmed.

### 3. Story workbench — `desk.story.$leadId.tsx`
- "← Queue" crumb. **Two-column grid** `minmax(280px,.8fr) 1.6fr`, 36px gap:
  - **Left rail (context, read-only)**: kicker ("The lead" / "Working notes from Dark Desk"), lead headline (Fraunces 21/600), why, meta (topic · filed date · score · origin); Dark-origin notice box (bg paper-2): "This trail came from Dark Desk. Draft privately here; printing is a separate click and every claim still needs evidence."; then rule-separated blocks: **Sources on the lead** (URLs, 11.5px, break-all), **What we found**, **Still unanswered**, **Verify before print**. Block labels 10px caps 0.16em rust-2.
  - **Right (the work)**: action bar — `Draft with AI` (solid; "Redraft" when a draft exists), `Save edits` (ghost), `Publish to the paper` (solid, disabled until headline+body). Busy rule with "Reporting first — following the trail, then drafting." while drafting. After publish: success note "On the paper." linking to Published. Form: Headline, Dek, Topic, Body (16-row textarea), all label-over-field; `Form · recap` meta under the form. Fields disabled once published.

### 4. Sources — `desk.sources.tsx`
- Add-source row (URL 1.4fr / Name 1fr / button, aligned to field bottoms). Bulk paste inside a `<details>` ("Bulk paste a registry…").
- Three sections as **tables** (not card lists): Proposed / On watch / Rejected. Columns: Source (bold title + muted URL + optional "why proposed" note + danger-colored fetch error line), Tier, Kind, Last fetched, actions (Accept / Drop, hover-revealed). Table header: 10px caps under a 1px ink rule; rows separated by `--rule` hairlines; row hover tint 3% ink.

### 5. Scan — `desk.scan.tsx`
- Lede: "One pass over the watch list… It runs only when you click — this is the expensive button, not a loop."
- Run bar: solid `Run scan` + meta "`N` sources on watch · last ran `date`". Busy rule while running. Result box (1px ink border): "Done. 41 fetched · 2 leads filed · 1 source proposed" + italic summary + "Open the queue".
- History list: date (muted) / counts line (600) / italic summary, hairline-separated.

### 6. Published — NEW route `desk.published.tsx`
- Kicker "The record", h1 "Published", lede: "What is live on the paper, with its corrections. Corrections are public; unpublishing pulls a piece back to the queue as a draft."
- Piece rows (grid 1fr/auto): meta (topic · date · "scored N/20 at filing"), headline (Fraunces 19/600), italic dek, corrections inline (12.5px, 2px danger left border, `**Correction, date:** body`), optional inline correction form (textarea + Publish correction/Cancel). Right column, hover-revealed stack: Read on the paper / Post correction / Unpublish (danger).
- Below: **Beat memory** table (Entity / Last angle / Updated) with sub "What the drafting AI is told we already covered, so the paper doesn't repeat itself." (Absorbs `desk.memory.tsx`; corrections posting moves here from Memory.)

### 7. Dark Desk — `desk.dark.tsx`
Night surface always (both modes). Header: kicker "Investigative desk", h1 "Dark Desk", right-aligned lede: "Three piles. **To look at** is new. **On the desk** is started. **Set aside** is parked — nothing is deleted. It digs; it never prints."
- **Open file** (when a file is open, pinned above the piles): 1px paper border, bg `#2c221a`, padding 18/22. Head row: kicker OPEN FILE, title (Fraunces 26/600), status line (`Stopped — more to read · 34 records on file · 19 still to open · round 3 of 5 · last touched Aug 26`), and a static action row: **Keep digging** (solid, only when stillOpen>0) / Send to the queue / Set aside / Close file. Then italic "what started this" line; **Why it stopped** as a single bold-labeled sentence (plain English via `editorPauseReason`), never a section of its own when empty.
- Open-file body: **two-column grid 1.4fr/1fr**:
  - Left — **What to read (N)**: the reading list FIRST. Each record: kind line (9.5px caps: `PDF · City of Longmont · captured Aug 26`), title (Fraunces 14.5/600), 2-line excerpt, actions "Read captured copy" (inline expand) + muted URL. Show 4, then "Show all N records".
  - Right — **Still unopened (N)** (label + why + "Follow this lead" per item), then **What Dark Desk noticed**, **What we know** (hidden when empty), collapsed `<details>` for **Research trail** and **Dead ends**.
- **Three piles** below, 3 equal columns with hairline separators: To look at (full worth-a-look cards: kind, title, "Why it matters —", "What changed —", italic "First question:", source line, Start digging) · On the desk (file cards; selected card gets bg tint; Open file / Keep digging / Set aside) · Set aside (dimmed; Pull back / Read) + **Start from a tip** box (bordered, textarea + Start digging) + `<details>` **What Dark Desk did** run log.
- Keep-digging progress copy sequence: "Searching records…" → "Opening pages. They land on the file as they are read…"; stop copy: "Dark Desk read a batch, then stopped so it would not run all night. That is normal — not an error."

### 8. Public paper — `index.tsx` / `articles.$slug.tsx` (refresh)
- Top utility row (10px caps): "Independent civic reporting · Longmont" / date / Light-Dark control. Centered masthead: name Fraunces 52/600 (-0.02em), `LONGMONT, COLORADO` 11px 0.2em, italic tagline. Nav band between 2px ink rules; **Editor desk** as solid ink chip at right.
- Front: topic chips; deck paragraph; featured story (kicker, Fraunces 40 headline, italic 17px dek, first 2 grafs at 14.5/1.65 + "Continue reading →"), 1px ink rule, then a 2-col grid of the rest (22px headlines, "CORRECTED date" marker in danger caps when applicable). Newsletter strip above a 2px rule. Footer over 1px rule.
- Article: crumb, kicker, Fraunces 38 headline, italic 18 dek, 620px measure body 15/1.7, corrections block, **Sources for this story** rule-topped block — KEEP the existing provenance behavior (captured versions, compare-over-time via `ProvenanceBlock`), restyled to this type system; the prototype's bare URL list is a placeholder, not a spec — reprint line, "Also in the paper" over 2px rule.

## Interactions & behavior
- **Hover-revealed row actions** everywhere (opacity 0→1, 150ms ease) — keep them keyboard-reachable (`:focus-within` should also reveal).
- **Busy states**: a 2px rust rule animating `scaleX(.15→1)` from the left, 1.2s `cubic-bezier(.22,1,.36,1)` infinite, with an italic muted phase line under it. Respect `prefers-reduced-motion` (static full-width rule).
- Buttons: 150ms background/color transitions; solid = ink fill (hover ink-2), ghost = 1px ink border (hover 8% ink tint, active 16%), quiet = borderless rust-2 text (hover 12% rust tint), danger = ghost with danger text. All `white-space: nowrap`.
- Publish flow: save → publish → success note with links; published pieces prepend to the paper and to beat memory.
- Unpublish: piece leaves Published, its lead returns to the queue as `drafted` (create one if the lead is gone).
- **Light/Dark mode**: persisted user preference; dark mode applies the night token set to the whole desk AND the paper. Dark Desk is night in both modes. Persist in a profile/localStorage.
- Scroll to top on navigation; scan/dig buttons disabled while running.

## State management
Existing TanStack Query keys carry over (`sources`, `leads`, `scans`, `investigations`, `worth-a-look`, `paper`). New requirements: a `published` list query for the desk (headline, dek, topic, date, leadScore, corrections[], leadId); command center composes the existing queries — no new endpoint needed beyond published + corrections-per-article; persisted UI prefs: `mode` (light|dark), open Dark Desk file id (already sessionStorage).

## Design tokens (letterpress — final)
Light: paper `#f6f1e7`, paper-2 `#efe6d6`, ink `#1c1410`, ink-2 `#3a3129`, muted `#6b5e52`, rule `#cfc2ac` (slightly warmer than the current `#c9bba8`), rust `#9b2915`, rust-2 `#7a1f10`, danger `#8b1e12`.
Night (Dark Desk + dark mode): bg `#211812`, bg-2 `#2c221a`, type `#f6f1e7`, type-2 `#c8b9a6`, rule `#463828`, accent `#d2764f` (lightened rust — the raw `#9b2915` fails contrast on ink), danger/link `#e8b4a8` (blush).
Type: display **Fraunces** (500/600/700, optical sizing on), body **Source Serif 4** (400/600 + italic). Base 14px/1.5; lists 13px; meta 11.5px; kickers 10px caps 0.16–0.18em; h1 30, section heads 17, headlines 15.5 (list) / 19 (published) / 26 (open file).
Spacing: hairline-rule-driven, not card-driven — sections separated by 1px rules under their heads; rows 11–14px vertical padding. Radius: 0 everywhere (sharp letterpress edges). Score box: 26×26px, 1px border; ≥14 = solid rust/white, 10–13 = ink border, else muted.

## Decisions settled in build review
1. **Row actions on touch/narrow**: hover-reveal is a wide-desktop nicety only. Actions are always visible below 1080px and on any `hover:none`/`pointer:coarse` device, and revealed by `:focus-within` for keyboards. (Prototype now implements all three.)
2. **Empty desk / first-run**: Needs You hides when empty. Queue column shows "Queue is empty — run the first scan or file a lead" with both actions. Dark Desk panel: "Nothing new tonight" + Start-from-a-tip link. Wire: "No scans yet — the watch list is ready" + Run scan. Published: "Empty until you publish." Reuse the repo's existing EmptyState copy voice.
3. **Unpublish is phase 3** (see Staging). Ship Published as read + post-correction first.
4. **Dark mode is desk-only in v1.** The paper stays paper-light for readers; the prototype's paper toggle is exploration, not v1 scope.
5. **Story rail fields** ("What we found", "Still unanswered", "Verify before print") are COMPOSED from existing engine data — `found_note` findings, `unanswered`, `integrity_notes`, provenance. No new editorial gate, no new fields.
6. **Public article sources**: captured versions and evidence compare stay. Never reduce to bare URLs.
7. **Keep digging** is available whenever a file is on the desk — not only when `still to open > 0` (a timeout can end a round empty; the editor may still want another search pass).
8. **Auth chrome stays**: the signed-in UserButton (account/sign out) remains in the desk masthead beside the mode control (shown as the "SC" mark in the prototype). Login, membership, and get-the-code pages are OUT of this package's scope — leave as-is.
9. **Dateline** is the real date only. No "editions"/"put to bed" flavor — the product has no editions.
10. **390px behavior**: board columns stack (queue → Dark Desk → wire); Needs You becomes a left-aligned vertical list (items wrap, one per line); tables may scroll horizontally rather than reflow.
11. **"Follow this lead"** (Dark Desk) opens a NEW file, matching current engine behavior — make the relationship visible: the new file's "what started this" line names the parent file (the prototype does this), and a future pass may add a "followed from" backlink on the card. Do not silently deepen the same file.

## Staging (implement in this order)
- **Phase 1 — chrome + command center**: new nav/masthead, Needs You, three-column Desk, queue/story restyle. No backend change.
- **Phase 2 — drill-ins**: Sources tables, Scan, Published (read + post-correction; needs the `published` desk query), Memory folded in, Dark Desk restyle (piles + open file, reading list first).
- **Phase 3 — feature work with tests**: Unpublish (lead returns as draft), desk dark mode, paper front/article refresh. Fix the existing `node:dns/promises` browser/server module leak before phase 1, separately from this design.

## Copy rules (unchanged from the repo brief)
Plain English only. Banned: hop(s), frontier, research budget, artifact, heuristic, synthesis, raw URLs as headlines, raw errors. All engine strings pass through `src/lib/news/desk-copy.ts`.

## Assets
None — no images or icon fonts. The diamond bullet and rules are CSS. Fonts from Google Fonts (Fraunces, Source Serif 4).

## Files in this bundle
- `TownReporter Desk.html` — the prototype entry (open in a browser; state is simulated).
- `desk/data.jsx` — realistic sample data shapes (useful as fixture reference).
- `desk/chrome.jsx` — shell, masthead, nav, primitives (buttons, chips, score, section heads).
- `desk/screens-main.jsx` — command center, queue, story workbench.
- `desk/screens-side.jsx` — sources, scan, published, Dark Desk + open file.
- `desk/paper.jsx` — public front page + article.
