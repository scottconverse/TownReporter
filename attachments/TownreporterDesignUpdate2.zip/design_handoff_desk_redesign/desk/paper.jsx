const {useState:uS3} = React;
const PTOPICS = ["all","council","money","water","schools","development","utilities","parks"];

function PaperChrome({nav, mode, setMode, children, compact}){
  return <div className={"shell paper-shell"+(mode==="dark"?" night":"")}>
    <div className="paper-wrap">
      <div className="ptop">
        <span>Independent civic reporting · Longmont</span>
        <span className="ptop-mid">Wednesday, August 26, 2026</span>
        <span className="ptop-r"><ModeSeg mode={mode} setMode={setMode}/></span>
      </div>
      <div className={"pmast"+(compact?" compact":"")}>
        <button className="pname" onClick={()=>nav("paper")}>TownReporter</button>
        <p className="ploc">Longmont, Colorado</p>
        {!compact?<p className="ptagline">The public record is only the beginning.</p>:null}
      </div>
      <div className="pnav-band">
        <nav className="pnav">
          <button className="pnav-item on">The paper</button>
          <button className="pnav-item">About</button>
          <button className="pnav-item">How we report</button>
          <button className="pnav-item">Corrections</button>
          <button className="pnav-item">RSS</button>
        </nav>
        <button className="pnav-desk" onClick={()=>nav("desk")}>Editor desk</button>
      </div>
      <div id="paper" className="pbody">{children}</div>
      <footer className="pfoot">TownReporter · Longmont, Colorado. The public record is only the beginning. Free to reprint with credit and a link back. Verify details against the official record.</footer>
    </div>
  </div>;
}

function PaperScreen({S, nav, openArticle, mode, setMode}){
  const [topic, setTopic] = uS3("all");
  const arts = S.published.filter(p=>topic==="all"||p.topic===topic);
  const featured = arts[0];
  const rest = arts.slice(1);
  return <PaperChrome nav={nav} mode={mode} setMode={setMode}>
    <div className="chips">{PTOPICS.map(t=><button key={t} className={"pchip"+(topic===t?" on":"")} onClick={()=>setTopic(t)}>{t}</button>)}</div>
    {topic==="all"?<p className="pdeck">TownReporter follows Longmont's meetings, money, contracts and public records — then keeps digging when something changes, disappears or doesn't add up. Human-edited. Sources shown.</p>:null}
    {!featured?<p className="lede">That beat is quiet in this edition. Pick another topic.</p>:<>
      <article className="feat">
        <Kicker>{featured.topic} · {featured.date}</Kicker>
        <h2 className="feat-h"><button className="p-hl" onClick={()=>openArticle(featured.id)}>{featured.headline}</button></h2>
        <p className="feat-dek">{featured.dek}</p>
        {featured.body?<div className="feat-body">{featured.body.split("\n\n").slice(0,2).map((p,i)=><p key={i}>{p}</p>)}
          <button className="inline-link" onClick={()=>openArticle(featured.id)}>Continue reading →</button></div>:null}
      </article>
      {rest.length?<div className="pgrid">{rest.map(a=><article key={a.id} className="pcell">
        <Kicker>{a.topic} · {a.date}</Kicker>
        <h3 className="pcell-h"><button className="p-hl" onClick={()=>openArticle(a.id)}>{a.headline}</button></h3>
        <p className="pcell-dek">{a.dek}</p>
        {a.corrections.length?<p className="pcell-corr">Corrected {a.corrections[a.corrections.length-1].date}</p>:null}
      </article>)}</div>:null}
    </>}
    <section className="pnews">
      <h2 className="pnews-h">In your inbox</h2>
      <p className="pcell-dek">New articles when they publish. No spam. We store the address to send the paper; we do not sell it.</p>
      <div className="pnews-form"><input placeholder="you@example.com"/><Btn solid small>Subscribe</Btn></div>
    </section>
  </PaperChrome>;
}

function ArticleScreen({S, nav, openArticle, mode, setMode}){
  const a = S.published.find(p=>p.id===S.articleId) || S.published[0];
  if(!a) return <PaperChrome nav={nav} mode={mode} setMode={setMode}><p className="lede">That story is not in this edition. <button className="inline-link" onClick={()=>nav("paper")}>Back to the paper</button></p></PaperChrome>;
  const more = S.published.filter(p=>p.id!==a.id).slice(0,4);
  return <PaperChrome nav={nav} mode={mode} setMode={setMode} compact>
    <button className="crumb" onClick={()=>nav("paper")}>← The paper</button>
    <Kicker>{a.topic} · {a.date}</Kicker>
    <h1 className="art-h">{a.headline}</h1>
    <p className="art-dek">{a.dek}</p>
    <div className="art-body">{(a.body||"[Body as published.]").split("\n\n").map((p,i)=><p key={i}>{p}</p>)}</div>
    {a.corrections.length?<div className="art-corrs">{a.corrections.map((c,i)=><p key={i} className="pub-corr"><b>Correction, {c.date}:</b> {c.body}</p>)}</div>:null}
    {a.sources&&a.sources.length?<div className="art-src"><p className="side-label">Sources for this story</p>{a.sources.map((s,i)=><p key={i} className="side-url">{s}</p>)}</div>:null}
    <p className="art-reprint">Free to reprint in whole or part with credit to TownReporter and a link back. Do not imply endorsement.</p>
    {more.length?<section className="art-more"><h2 className="pnews-h">Also in the paper</h2>
      {more.map(m=><p key={m.id} className="art-more-i"><button className="p-hl md" onClick={()=>openArticle(m.id)}>{m.headline}</button></p>)}</section>:null}
  </PaperChrome>;
}
Object.assign(window, {PaperScreen, ArticleScreen});
