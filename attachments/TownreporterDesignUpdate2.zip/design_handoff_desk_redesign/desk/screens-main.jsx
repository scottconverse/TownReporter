const {useState:uS} = React;

function NeedsStrip({leads, sources, invs, scans, nav, openDark}){
  const drafted = leads.filter(l=>l.status==="drafted").length;
  const proposed = sources.filter(s=>s.status==="proposed").length;
  const failing = sources.filter(s=>s.status==="accepted"&&s.error&&s.errKind!=="flaky").length;
  const errStops = invs.filter(i=>i.status==="paused"&&i.stopKind==="error");
  const roundStops = invs.filter(i=>i.status==="paused"&&i.stopKind!=="error");
  const items = [];
  if(drafted) items.push({t:`${drafted} draft${drafted>1?"s":""} ready to publish`, go:()=>nav("queue")});
  if(errStops.length) items.push({t:`${errStops.length} Dark Desk file${errStops.length>1?"s":""} stopped on an error — what it found is saved`, go:()=>openDark(errStops[0].id)});
  if(proposed) items.push({t:`${proposed} proposed source${proposed>1?"s":""} await review`, go:()=>nav("sources")});
  if(failing) items.push({t:`${failing} official source${failing>1?"s":""} failing to fetch`, go:()=>nav("sources")});
  if(roundStops.length) items.push({t:`${roundStops.length} Dark Desk file${roundStops.length>1?"s":""} ready for another round`, go:()=>openDark(roundStops[0].id), quiet:true});
  if(!items.length) return null;
  return <div className="needs">
    <span className="needs-label">Needs you</span>
    {items.map((it,i)=><button key={i} className={"needs-item"+(it.quiet?" quiet":"")} onClick={it.go}>{it.t}</button>)}
  </div>;
}

function LeadRow({l, open, act, table, openArt}){
  const actions = <span className="row-acts">
    <Btn small quiet onClick={()=>open(l.id)}>Open</Btn>
    {l.dup&&openArt?<Btn small quiet onClick={()=>openArt(l.dup.pid)}>The piece</Btn>:null}
    {l.status!=="held"&&l.status!=="published"&&l.status!=="killed"?<Btn small quiet onClick={()=>act(l.id,"held")}>Hold</Btn>:null}
    {l.status==="held"?<Btn small quiet onClick={()=>act(l.id,"new")}>Back</Btn>:null}
    {l.status!=="killed"&&l.status!=="published"?<Btn small quiet danger onClick={()=>act(l.id,"killed")}>Kill</Btn>:null}
  </span>;
  if(table) return <tr className={"lead-tr"+(l.status==="killed"?" dead":"")}>
    <td><Score v={l.score}/></td>
    <td className="td-hl"><button className="hl-link" onClick={()=>open(l.id)}>{l.headline}</button><span className="meta-inline">{l.why}</span>{l.dup?<span className="meta-inline block">≈ covers “{l.dup.note}”, published {l.dup.date}</span>:null}</td>
    <td className="td-meta">{l.topic}</td>
    <td className="td-meta">{l.age}</td>
    <td className="td-meta">{l.from==="dark"?"Dark Desk":l.from==="scan"?"scanner":"editor"}</td>
    <td><Chip s={l.status}/>{l.dup?<span className="chip dup" style={{marginLeft:"6px"}} title={"Covers ground published "+l.dup.date}>≈ printed</span>:null}</td>
    <td className="td-acts">{actions}</td>
  </tr>;
  return <div className={"lead-row"+(l.status==="killed"?" dead":"")}>
    <Score v={l.score}/>
    <div className="lead-main">
      <button className="hl-link" onClick={()=>open(l.id)}>{l.headline}</button>
      <p className="lead-why">{l.why}</p>
      {l.dup?<p className="meta">≈ covers “{l.dup.note}”, published {l.dup.date}</p>:null}
      <p className="meta">{l.topic} · {l.age} · {l.from==="dark"?"from Dark Desk":l.from==="scan"?"from the scanner":"filed by you"} {actions}</p>
    </div>
    <div style={{display:"flex",flexDirection:"column",alignItems:"end",gap:"4px"}}><Chip s={l.status}/>{l.dup?<span className="chip dup" title={"Covers ground published "+l.dup.date}>≈ printed</span>:null}</div>
  </div>;
}

function Overview({S, A, nav, layout, setLayout}){
  const {leads, sources, scans, invs, worth, published, memory, scanBusy} = S;
  const live = leads.filter(l=>l.status!=="killed"&&l.status!=="published");
  const queueLeads = [...live].sort((a,b)=>b.score-a.score);
  const onDesk = invs.filter(i=>i.status==="paused"||i.status==="open"||i.status==="investigating");
  const aside = invs.filter(i=>i.status==="aside");
  const last = scans[0];
  const proposed = sources.filter(s=>s.status==="proposed");
  const officialFail = sources.filter(s=>s.status==="accepted"&&s.error&&s.errKind!=="flaky");
  const flaky = sources.filter(s=>s.status==="accepted"&&s.error&&s.errKind==="flaky");
  const head = <div className="ov-head">
    <div><Kicker>Command center</Kicker><h1 className="h1">The desk</h1></div>
  </div>;
  const needs = <NeedsStrip leads={leads} sources={sources} invs={invs} scans={scans} nav={nav} openDark={id=>{A.setOpenDark(id); nav("dark");}}/>;

  const wire = <>
    <SecHead title="The wire" aside={<Btn small onClick={A.runScan} disabled={scanBusy}>{scanBusy?"Scanning…":"Run scan"}</Btn>}/>
    {scanBusy?<Busy label="Fetching the watch list, then one pass for leads."/>:null}
    <p className="wire-line"><b>Last scan</b> · {last.date} · {last.fetched} fetched · {last.leads?`${last.leads} leads · ${last.proposed} proposed`:<b>filed nothing</b>}</p>
    <p className="wire-sum">{last.summary}</p>
    <div className="wire-block">
      <p className="wire-line"><b>Source health</b> · {sources.filter(s=>s.status==="accepted").length} on watch{officialFail.length+flaky.length?` · ${officialFail.length+flaky.length} failing`:""}</p>
      {officialFail.map(s=><p key={s.id} className="wire-warn">{s.title} — {s.error}</p>)}
      {flaky.length?<details className="wire-flaky"><summary>{flaky.length} social & discovery sources didn't answer — they rarely do</summary>{flaky.map(s=><p key={s.id}>{s.title} — {s.error}</p>)}</details>:null}
      {proposed.map(s=><p key={s.id} className="wire-row">Proposed: {s.title} <Btn small quiet onClick={()=>A.sourceStatus(s.id,"accepted")}>Accept</Btn><Btn small quiet onClick={()=>A.sourceStatus(s.id,"rejected")}>Drop</Btn></p>)}
      {!officialFail.length&&!flaky.length&&!proposed.length?<p className="meta">All quiet.</p>:null}
    </div>
    <div className="wire-block">
      <p className="wire-line"><b>On the paper</b> · this week</p>
      {published.slice(0,3).map(p=><p key={p.id} className="wire-row"><button className="hl-link sm" onClick={()=>nav("published")}>{p.headline}</button><span className="meta-inline">{p.date}{p.corrections.length?" · corrected":""}</span></p>)}
    </div>
    <div className="wire-block">
      <p className="wire-line"><b>Beat memory</b> · what we already covered</p>
      {memory.slice(0,4).map((m,i)=><p key={i} className="wire-row"><b className="mem-e">{m.e}</b> <span className="meta-inline">{m.angle}</span></p>)}
    </div>
  </>;

  const darkCol = <div className="nightpanel">
    <SecHead title="Dark Desk" aside={<Btn small onClick={()=>nav("dark")}>Open the desk</Btn>} />
    <p className="np-note">Investigates. Never prints.</p>
    <p className="np-pile">To look at <span className="sec-count">{worth.length}</span></p>
    {worth.slice(0,3).map(w=><div key={w.id} className="np-item">
      <p className="np-kind">{w.kind}</p>
      <p className="np-title">{worthTitle(w)}</p>
      <p className="np-meta">{w.src}</p>
      <div className="np-acts"><Btn small onClick={()=>{A.startDig(w); nav("dark");}}>Start digging</Btn></div>
    </div>)}
    <p className="np-pile">On the desk <span className="sec-count">{onDesk.length}</span></p>
    {onDesk.map(i=><div key={i.id} className="np-item">
      <p className="np-kind">{i.status==="paused"?"Stopped — more to read":"Ready to continue"}</p>
      <p className="np-title">{i.title}</p>
      <p className="np-meta">{i.records} records · {i.stillOpen} still to open</p>
      <div className="np-acts"><Btn small onClick={()=>{A.setOpenDark(i.id); nav("dark");}}>Open file</Btn></div>
    </div>)}
    <p className="np-pile">Set aside <span className="sec-count">{aside.length}</span> <button className="np-link" onClick={()=>nav("dark")}>see the pile</button></p>
  </div>;

  if(layout==="board"){
    const acc = sources.filter(s=>s.status==="accepted").length;
    return <div>
      {head}{needs}
      <div className="pipeline">
        {[
          {k:"Sources", v:acc+" on watch", w:(proposed.length?proposed.length+" proposed":officialFail.length?officialFail.length+" official failing":"healthy"), go:"sources"},
          {k:"Scan", v:"last "+last.date.split(", ")[1], w:last.leads+" leads filed", go:"scan"},
          {k:"Queue", v:live.length+" open", w:leads.filter(l=>l.status==="drafted").length+" drafted", go:"queue"},
          {k:"Published", v:published.length+" this week", w:(published.reduce((a,p)=>a+p.corrections.length,0)||"no")+" corrections", go:"published"},
        ].map((st,i)=><React.Fragment key={st.k}>
          {i?<span className="pipe-arrow">→</span>:null}
          <button className="pipe-cell" onClick={()=>nav(st.go)}><span className="pipe-k">{st.k}</span><span className="pipe-v">{st.v}</span><span className="pipe-w">{st.w}</span></button>
        </React.Fragment>)}
      </div>
      <SecHead title="The queue" count={live.length} aside={<Btn small quiet onClick={()=>nav("queue")}>Open the queue</Btn>}/>
      <table className="ltable"><thead><tr><th>Score</th><th>Lead</th><th>Topic</th><th>Age</th><th>From</th><th>Status</th><th></th></tr></thead>
        <tbody>{queueLeads.map(l=><LeadRow key={l.id} l={l} table open={A.openStory} act={A.setLeadStatus} openArt={A.openArticle}/>)}</tbody></table>
      <div className="board-lower">
        <div>{darkCol}</div>
        <div className="wirecol">{wire}</div>
      </div>
    </div>;
  }
  return <div>
    {head}{needs}
    <div className="front">
      <section className="front-queue">
        <SecHead title="The queue" count={live.length} sub="What might be news, best first. Open a lead to work it." aside={<Btn small quiet onClick={()=>nav("queue")}>Full queue</Btn>}/>
        <div className="lead-list">{queueLeads.map(l=><LeadRow key={l.id} l={l} open={A.openStory} act={A.setLeadStatus} openArt={A.openArticle}/>)}</div>
      </section>
      <section>{darkCol}</section>
      <section className="wirecol">{wire}</section>
    </div>
  </div>;
}

function QueueScreen({S, A, nav}){
  const [filter, setFilter] = uS("all");
  const [form, setForm] = uS({headline:"", why:"", topic:"council", url:""});
  const [err, setErr] = uS(null);
  const leads = [...S.leads].sort((a,b)=>b.score-a.score);
  const shown = leads.filter(l=>filter==="all"?true:l.status===filter);
  const counts = s=>leads.filter(l=>l.status===s).length;
  return <div className="narrowish">
    <Kicker>Leads</Kicker><h1 className="h1">The queue</h1>
    <p className="lede">Everything that might be news, scored and sorted. The scanner and Dark Desk file leads here; so do you. Nothing prints until you open a lead and publish it.</p>
    <details className="file-form">
      <summary>File a lead yourself</summary>
      <div className="form-grid">
        <label className="f"><span>Headline</span><input value={form.headline} onChange={e=>setForm({...form, headline:e.target.value})} placeholder="What happened"/></label>
        <label className="f"><span>Why now</span><input value={form.why} onChange={e=>setForm({...form, why:e.target.value})} placeholder="Why this is news in Longmont today"/></label>
        <label className="f"><span>Topic</span><select value={form.topic} onChange={e=>setForm({...form, topic:e.target.value})}>{window.TOPICS.map(t=><option key={t}>{t}</option>)}</select></label>
        <label className="f"><span>Source URL (optional)</span><input value={form.url} onChange={e=>setForm({...form, url:e.target.value})} placeholder="https://"/></label>
      </div>
      {err?<Note kind="err">{err}</Note>:null}
      <Btn solid small onClick={()=>{
        if(form.headline.length<8||form.why.length<8){setErr("Headline and why-now both need at least 8 characters."); return;}
        setErr(null); const id=A.fileLead(form); setForm({headline:"", why:"", topic:"council", url:""}); A.openStory(id);
      }}>File lead</Btn>
    </details>
    <div className="filters">
      {["all","new","drafted","held","killed"].map(f=><button key={f} className={"filter"+(filter===f?" on":"")} onClick={()=>setFilter(f)}>{f}{f!=="all"?` ${counts(f)}`:` ${leads.length}`}</button>)}
    </div>
    <div className="lead-list roomy">{shown.map(l=><LeadRow key={l.id} l={l} open={A.openStory} act={A.setLeadStatus} openArt={A.openArticle}/>)}
      {!shown.length?<p className="meta">Nothing with that status.</p>:null}</div>
  </div>;
}

function NotesBlock({l, A}){
  const n = l.notes;
  const [line, setLine] = uS("");
  const small = useSmall("(max-width:720px)");
  const add = ()=>{ if(!line.trim()) return; A.addNoteLine(l.id, line.trim()); setLine(""); };
  const inner = <div className="notes">
    {!small?<div className="notes-head"><p className="side-label" style={{margin:0}}>Reporting notes</p><span className="chip dnp">does not print</span></div>:null}
    {!n||!n.news?<>
      <p className="note-one" style={{marginTop:small?0:"8px"}}>{l.draft?"This draft was written before notes were kept. Redraft fills them; lines you add stay.":"Draft with AI fills this. You can add a line."}</p>
      {n&&n.todo&&n.todo.length?<div className="note-sec"><p className="side-label">Still to pull</p>
        {n.todo.map((t,i)=><button key={i} className={"todo"+(t.done?" done":"")} title={t.done?"Struck — click to restore":"Click to strike as done"} onClick={()=>A.toggleNote(l.id,i)}><span className="todo-box"></span><span className="todo-t">{t.t}</span>{t.src==="you"?<span className="todo-src">yours</span>:null}</button>)}
      </div>:null}
    </>:<>
      <div className="note-sec"><p className="side-label">The news</p><p className="note-one">{n.news}</p></div>
      <div className="note-sec"><p className="side-label">Why it matters</p><p className="note-one">{n.why}</p></div>
      <div className="note-sec"><p className="side-label">Angle</p><p className="note-one">{n.angle}</p></div>
      {n.todo&&n.todo.length?<div className="note-sec"><p className="side-label">Still to pull</p>
        {n.todo.map((t,i)=><button key={i} className={"todo"+(t.done?" done":"")} title={t.done?"Struck — click to restore":"Click to strike as done"} onClick={()=>A.toggleNote(l.id,i)}><span className="todo-box"></span><span className="todo-t">{t.t}</span>{t.src==="you"?<span className="todo-src">yours</span>:null}</button>)}
      </div>:null}
      {n.found&&n.found.length?<div className="note-sec"><p className="side-label">What we found</p>{n.found.map((f,i)=><p key={i} className="note-one">{f.t}{f.src?<span className="meta-inline">· {f.src}</span>:null}</p>)}</div>:null}
      {n.verify&&n.verify.length?<div className="note-sec"><p className="side-label">Verify before print</p>{n.verify.map((v,i)=><p key={i} className="note-one">{v}</p>)}</div>:null}
      {n.opened&&n.opened.length?<div className="note-sec"><p className="side-label">Documents opened for this draft</p>{n.opened.map((d,i)=><p key={i} className="note-one"><a className="inline-link" href="#" onClick={e=>e.preventDefault()} title="Opens the original in the real desk">{d.title}</a></p>)}</div>:null}
    </>}
    <div className="note-add"><input value={line} onChange={e=>setLine(e.target.value)} onKeyDown={e=>e.key==="Enter"?add():null} placeholder="Add a line — a call to make, a record to pull"/><Btn small onClick={add} disabled={!line.trim()}>Add</Btn></div>
  </div>;
  if(small) return <details className="notes-disc"><summary>Reporting notes <span className="chip dnp" style={{marginLeft:"6px"}}>does not print</span></summary>{inner}</details>;
  return inner;
}

function StoryScreen({S, A, nav}){
  const l = S.leads.find(x=>x.id===S.storyId);
  const [msg, setMsg] = uS(null);
  if(!l) return <div className="narrowish"><h1 className="h1">That lead is not on this desk</h1><p className="lede">It may have been killed. The queue has what is still open.</p><Btn onClick={()=>nav("queue")}>Back to queue</Btn></div>;
  const d = l.draft;
  const set = (k,v)=>A.saveDraft(l.id, {...d, [k]:v});
  const locked = l.status==="killed";
  const published = l.status==="published";
  return <div>
    <button className="crumb" onClick={()=>nav("queue")}>← Queue</button>
    <div className="story-grid">
      <aside className="story-side">
        <Kicker>{l.from==="dark"?"Working notes from Dark Desk":"The lead"}</Kicker>
        <h2 className="side-h">{l.headline}</h2>
        <p className="side-why">{l.why}</p>
        <Meta>{l.topic} · filed {l.created} · scored {l.score}/20 · {l.from==="dark"?"from Dark Desk":l.from==="scan"?"from the scanner":"filed by you"}</Meta>
        {l.from==="dark"?<p className="side-note">This trail came from Dark Desk. Draft privately here; printing is a separate click and every claim still needs evidence.</p>:null}
        {l.urls&&l.urls.length?<div className="side-block"><p className="side-label">Sources on the lead</p>{l.urls.map(u=><p key={u} className="side-url">{u}</p>)}</div>:null}
        <NotesBlock l={l} A={A}/>
        {!l.notes&&l.found&&l.found.length?<div className="side-block"><p className="side-label">What we found</p>{l.found.map((f,i)=><p key={i} className="side-item">{f.t}{f.u?<span className="meta-inline"> · {f.u}</span>:null}</p>)}</div>:null}
        {!l.notes&&l.unanswered&&l.unanswered.length?<div className="side-block"><p className="side-label">Still unanswered</p>{l.unanswered.map((q,i)=><p key={i} className="side-item">{q}</p>)}</div>:null}
        {!l.notes&&(d&&d.verify||l.verify)?<div className="side-block"><p className="side-label">Verify before print</p><p className="side-item">{l.verify}</p></div>:null}
      </aside>
      <section className="story-work">
        <div className="work-bar">
          {!locked&&!published?<Btn solid disabled={S.draftBusy} onClick={()=>A.draftLead(l.id)}>{S.draftBusy?"Drafting…":d?"Redraft":"Draft with AI"}</Btn>:null}
          {d&&!locked&&!published?<><Btn onClick={()=>setMsg("Saved.")}>Save edits</Btn>
          <Btn solid disabled={!d.headline||!d.body} onClick={()=>{A.publishLead(l.id); setMsg("pub");}}>Publish to the paper</Btn></>:null}
          {published?<Note kind="ok">On the paper. <button className="inline-link" onClick={()=>nav("published")}>See it under Published</button></Note>:null}
        </div>
        {S.draftBusy?<Busy label="Reporting first — following the trail, then drafting."/>:null}
        {msg==="Saved."?<Note kind="ok">Saved.</Note>:null}
        {msg==="pub"&&!published?null:null}
        {d?<div className="work-form">
          <label className="f"><span>Headline</span><input value={d.headline} onChange={e=>set("headline",e.target.value)} disabled={published}/></label>
          <label className="f"><span>Dek</span><input value={d.dek} onChange={e=>set("dek",e.target.value)} disabled={published}/></label>
          <label className="f"><span>Topic</span><input value={d.topic} onChange={e=>set("topic",e.target.value)} disabled={published}/></label>
          <label className="f"><span>Body</span><textarea rows={16} value={d.body} onChange={e=>set("body",e.target.value)} disabled={published}/></label>
          {d.form?<Meta>Form · {d.form}</Meta>:null}
        </div>:<p className="meta" style={{marginTop:"14px"}}>{locked?"This lead was killed. Nothing to draft.":"No draft yet. Draft with AI writes a first pass from the lead and its sources; you edit, then publish."}</p>}
      </section>
    </div>
  </div>;
}
Object.assign(window, {Overview, QueueScreen, StoryScreen, LeadRow, NotesBlock});
