import { Link } from "@tanstack/react-router";
import { PAPER, formatDate } from "@/lib/paper";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export function Masthead({ compact = false }: { compact?: boolean }) {
  const today = formatDate(new Date());
  return (
    <header className="border-b border-ink">
      <div className="flex items-center justify-between gap-3 border-b border-rule px-1 py-2 text-[11px] tracking-[0.14em] text-muted uppercase">
        <span>{PAPER.kicker}</span>
        <span className="hidden sm:inline">{today}</span>
        <AuthSlot />
      </div>
      <div className={compact ? "py-4 text-center" : "py-8 text-center sm:py-10"}>
        <Link to="/" className="inline-block">
          <p className="font-display text-4xl font-semibold tracking-tight text-ink sm:text-6xl">
            {PAPER.name}
          </p>
          <p className="mt-2 text-sm tracking-[0.18em] text-muted uppercase">
            {PAPER.location}
          </p>
        </Link>
        {!compact && (
          <p className="mx-auto mt-3 max-w-md font-display text-base italic text-ink-2">
            {PAPER.tagline}
          </p>
        )}
      </div>
      <nav className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 border-y-2 border-ink py-2.5 text-[12px] font-medium tracking-[0.12em] uppercase">
        <Link to="/" className="hover:text-rust">
          The paper
        </Link>
        <Link to="/about" className="hover:text-rust">
          About
        </Link>
        <Link to="/how-we-report" className="hover:text-rust">
          How we report
        </Link>
        <Link to="/corrections" className="hover:text-rust">
          Corrections
        </Link>
        <a href="/feed" className="hover:text-rust">
          RSS
        </a>
        <Link to="/desk" className="text-rust hover:text-rust-2">
          Editor desk
        </Link>
      </nav>
    </header>
  );
}

function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return <div className="h-5 w-16 animate-pulse bg-paper-2" />;
  }
  if (user) {
    return (
      <span className="flex items-center gap-2 normal-case tracking-normal">
        <SignedIn>
          <UserButton />
        </SignedIn>
      </span>
    );
  }
  return (
    <SignedOut>
      <Link to="/login" className="hover:text-rust">
        Sign in
      </Link>
    </SignedOut>
  );
}

export function PaperShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh bg-paper text-ink">
      <div className="mx-auto max-w-5xl px-4 py-4 sm:px-6">
        <Masthead />
        <div className="py-8">{children}</div>
        <footer className="mt-8 border-t border-ink pt-4 pb-10 text-sm text-muted">
          <p>
            {PAPER.name} · {PAPER.location}. Free to reprint with credit and a
            link back. Verify details against the official record.
          </p>
          <p className="mt-1">
            Drafts never publish themselves. The archive on this host lasts as
            long as the paper is published here.
          </p>
        </footer>
      </div>
    </div>
  );
}

export function TopicChip({
  topic,
  active,
}: {
  topic: string;
  active?: boolean;
}) {
  return (
    <Link
      to="/"
      search={{ topic }}
      className={
        "border px-3 py-1 text-[11px] tracking-[0.14em] uppercase " +
        (active
          ? "border-ink bg-ink text-paper"
          : "border-rule text-ink-2 hover:border-ink")
      }
    >
      {topic}
    </Link>
  );
}
