import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { DeskShell } from "@/components/desk-chrome";
import { listLeads, listScans, listSources } from "@/lib/news/desk";

export const Route = createFileRoute("/desk/")({ component: DeskHome });

function DeskHome() {
  const sources = useQuery({ queryKey: ["sources"], queryFn: () => listSources() });
  const leads = useQuery({ queryKey: ["leads"], queryFn: () => listLeads() });
  const scans = useQuery({ queryKey: ["scans"], queryFn: () => listScans() });

  const accepted = (sources.data ?? []).filter((s) => s.status === "accepted").length;
  const proposed = (sources.data ?? []).filter((s) => s.status === "proposed").length;
  const openLeads = (leads.data ?? []).filter(
    (l) => l.status === "new" || l.status === "drafted",
  ).length;
  const last = scans.data?.[0];

  return (
    <DeskShell title="The desk" kicker="Editor-in-chief">
      <p className="max-w-2xl text-ink-2">
        You are the editor. Grok fetches Longmont’s public sources, files leads,
        and drafts recaps. Nothing prints until you say so. Scans and drafts
        spend your Grok quota — they only run when you click.
      </p>
      <dl className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Stat label="Sources on watch" value={accepted} />
        <Stat label="Proposed sources" value={proposed} />
        <Stat label="Open leads" value={openLeads} />
        <Stat label="Scans run" value={scans.data?.length ?? 0} />
      </dl>
      {last?.summary && (
        <section className="mt-8 border border-rule bg-paper p-4">
          <p className="text-[11px] tracking-[0.14em] text-muted uppercase">
            Last scan
          </p>
          <p className="mt-2 text-ink-2">{last.summary}</p>
        </section>
      )}
      <div className="mt-8 flex flex-wrap gap-3">
        <Link
          to="/desk/scan"
          className="inline-flex min-h-11 items-center bg-ink px-4 text-sm text-paper hover:bg-ink-2"
        >
          Run a scan
        </Link>
        <Link
          to="/desk/queue"
          className="inline-flex min-h-11 items-center border border-ink px-4 text-sm hover:bg-paper-2"
        >
          Open the queue
        </Link>
        <Link
          to="/desk/dark"
          className="inline-flex min-h-11 items-center border border-ink bg-ink px-4 text-sm text-paper hover:bg-ink-2"
        >
          Dark desk
        </Link>
        <Link
          to="/desk/sources"
          className="inline-flex min-h-11 items-center border border-ink px-4 text-sm hover:bg-paper-2"
        >
          Review sources
        </Link>
      </div>
    </DeskShell>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="border border-rule bg-paper p-4">
      <dt className="text-[11px] tracking-[0.12em] text-muted uppercase">{label}</dt>
      <dd className="mt-1 font-display text-3xl tabular-nums">{value}</dd>
    </div>
  );
}
