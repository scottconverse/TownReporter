import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { DeskShell, InkButton, areaClass } from "@/components/desk-chrome";
import {
  listDarkPromises,
  listDarkRuns,
  listDarkSignals,
  runDarkDesk,
  sendDarkSignalToQueue,
} from "@/lib/news/dark";
import { formatDate, formatShortDate } from "@/lib/paper";

export const Route = createFileRoute("/desk/dark")({ component: DarkPage });

function DarkPage() {
  const qc = useQueryClient();
  const [paste, setPaste] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const signals = useQuery({ queryKey: ["dark-signals"], queryFn: () => listDarkSignals() });
  const runs = useQuery({ queryKey: ["dark-runs"], queryFn: () => listDarkRuns() });
  const promises = useQuery({ queryKey: ["dark-promises"], queryFn: () => listDarkPromises() });

  const run = useMutation({
    mutationFn: () => runDarkDesk({ data: { paste } }),
    onSuccess: (res) => {
      if (!res.ok) {
        setNotice(res.error);
        return;
      }
      setNotice(null);
      void qc.invalidateQueries({ queryKey: ["dark-signals"] });
      void qc.invalidateQueries({ queryKey: ["dark-runs"] });
      void qc.invalidateQueries({ queryKey: ["dark-promises"] });
    },
    onError: (err) => {
      setNotice(err instanceof Error ? err.message : "Dark desk failed");
    },
  });

  const toQueue = useMutation({
    mutationFn: (id: number) => sendDarkSignalToQueue({ data: id }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["leads"] });
    },
  });

  return (
    <DeskShell night title="Dark desk" kicker="Lane 3 — questions only">
      <p className="max-w-2xl text-paper-2">
        One Grok pass over scan snapshots, the paper, beat memory, and
        whatever you paste. Output is never copy. Confidence is capped at 0.5.
        Coordination is not deception. Private people stay aggregate. Nothing
        here prints.
      </p>
      <label className="mt-6 block space-y-1.5">
        <span className="text-[11px] tracking-[0.14em] text-paper-2 uppercase">
          Paste minutes, comments, a packet — optional
        </span>
        <textarea
          className={areaClass + " min-h-36"}
          value={paste}
          onChange={(e) => setPaste(e.target.value)}
          placeholder="Transcript, public comment, a staff report excerpt…"
        />
      </label>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <InkButton
          tone="invert"
          disabled={run.isPending}
          onClick={() => run.mutate()}
        >
          {run.isPending ? "Running Dark Desk…" : "Run Dark Desk"}
        </InkButton>
        {run.isPending && (
          <p className="text-sm text-paper-2">One Grok call. Stay on this page.</p>
        )}
      </div>
      {run.data?.ok && (
        <div className="mt-6 border border-ink-2 bg-ink-2 p-4">
          <p className="font-medium">
            {run.data.stored} signal{run.data.stored === 1 ? "" : "s"} filed
          </p>
          {run.data.summary && (
            <p className="mt-2 whitespace-pre-wrap text-paper-2">{run.data.summary}</p>
          )}
        </div>
      )}
      {(signals.error || runs.error) && (
        <p className="mt-4 text-[#e8b4a8]">
          Dark desk tables are warming up. Try Run again.
          {signals.error instanceof Error ? ` ${signals.error.message}` : ""}
        </p>
      )}
      {(notice || (run.data && !run.data.ok)) && (
        <p className="mt-4 text-[#e8b4a8]">
          {notice || (run.data && !run.data.ok ? run.data.error : "")}
        </p>
      )}

      {(promises.data ?? []).length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl">Promise ledger</h2>
          <ul className="mt-3 divide-y divide-ink-2 border border-ink-2">
            {(promises.data ?? []).map((p) => (
              <li key={p.id} className="px-4 py-3">
                <p className="font-medium">
                  {p.who_promised} — {p.what}
                </p>
                <p className="text-sm text-paper-2">
                  {p.status}
                  {p.when_due ? ` · due ${p.when_due}` : ""}
                  {p.source_cite ? ` · ${p.source_cite}` : ""}
                </p>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-10">
        <h2 className="font-display text-2xl">Signals</h2>
        {(signals.data ?? []).length === 0 && (
          <p className="mt-3 text-paper-2">None yet. Run the desk.</p>
        )}
        <ul className="mt-4 space-y-4">
          {(signals.data ?? []).map((s) => (
            <li key={s.id} className="border border-ink-2 p-4">
              <p className="text-[11px] tracking-[0.14em] text-rust uppercase">
                {s.posture} · {s.signal_type} · strength {s.strength} ·
                confidence {Number(s.confidence).toFixed(2)} · {s.handoff}
              </p>
              <h3 className="mt-1 font-display text-xl">{s.name}</h3>
              <Block label="Observation" text={s.observation} />
              <Block label="Pattern" text={s.pattern} />
              <Block label="Linkage" text={s.linkage_map} />
              <Block label="Alternatives" text={s.alternatives} />
              <Block label="Counter-narrative" text={s.counter_narrative} />
              <Block label="What would kill this" text={s.what_would_kill} />
              <Block label="Pathway" text={s.pathway} />
              <Block label="Privacy" text={s.privacy_review} />
              <div className="mt-3 flex flex-wrap gap-2">
                {s.handoff === "FOR VERIFICATION" && (
                  <InkButton
                    tone="invert"
                    disabled={toQueue.isPending}
                    onClick={() => toQueue.mutate(s.id)}
                  >
                    Send to queue as a question
                  </InkButton>
                )}
                <span className="self-center text-sm text-paper-2">
                  {formatShortDate(s.created_at)}
                </span>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {(runs.data ?? []).length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl">Previous runs</h2>
          <ul className="mt-3 divide-y divide-ink-2 border border-ink-2">
            {(runs.data ?? []).map((r) => (
              <li key={r.id} className="px-4 py-3">
                <p className="text-sm text-paper-2">{formatDate(r.started_at)}</p>
                {r.error && <p className="text-danger">{r.error}</p>}
                {r.summary && (
                  <p className="mt-1 whitespace-pre-wrap text-paper-2">{r.summary}</p>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}

      {toQueue.isSuccess && (
        <p className="mt-4 text-sm text-paper-2">
          Held in the queue as a question.{" "}
          <Link to="/desk/queue" className="text-rust">
            Open the queue
          </Link>
        </p>
      )}
    </DeskShell>
  );
}

function Block({ label, text }: { label: string; text: string }) {
  if (!text.trim()) return null;
  return (
    <div className="mt-3">
      <p className="text-[11px] tracking-[0.14em] text-paper-2 uppercase">{label}</p>
      <p className="mt-1 whitespace-pre-wrap text-paper-2">{text}</p>
    </div>
  );
}
