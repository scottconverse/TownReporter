import { createFileRoute, Outlet } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/desk")({ component: DeskGate });

function DeskGate() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <div className="grid min-h-dvh place-items-center bg-desk text-muted">
        Opening the desk…
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return <Outlet />;
}
