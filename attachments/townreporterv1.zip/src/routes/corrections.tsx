import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PaperShell } from "@/components/paper-chrome";
import { listPublicCorrections } from "@/lib/news/public";
import { formatShortDate } from "@/lib/paper";

export const Route = createFileRoute("/corrections")({ component: Corrections });

function Corrections() {
  const { data: items = [] } = useQuery({
    queryKey: ["corrections"],
    queryFn: () => listPublicCorrections(),
  });
  return (
    <PaperShell>
      <h1 className="font-display text-4xl font-semibold">Corrections</h1>
      <p className="mt-4 max-w-2xl text-lg text-ink-2">
        If we got it wrong, it lives here in the open — not buried in a
        rewrite nobody sees.
      </p>
      {items.length === 0 ? (
        <p className="mt-8 text-muted">No corrections have been posted yet.</p>
      ) : (
        <ul className="mt-8 max-w-2xl space-y-6">
          {items.map((c) => (
            <li key={c.id} className="border-t border-rule pt-4">
              <p className="text-[11px] tracking-[0.14em] text-muted uppercase">
                {formatShortDate(c.created_at)}
                {c.headline ? ` · ${c.headline}` : ""}
              </p>
              <p className="mt-2 text-ink-2">{c.body}</p>
            </li>
          ))}
        </ul>
      )}
    </PaperShell>
  );
}
