import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { PAPER, SEED_SOURCES, slugify } from "@/lib/paper";
import { fetchSourceText, sha256 } from "./fetch-url";
import {
  DRAFT_SYSTEM,
  SCAN_SYSTEM,
  grokChat,
  parseJsonBlock,
} from "./ai";
import type {
  DraftRow,
  LeadRow,
  MemoryRow,
  ScanRow,
  SourceRow,
} from "./types";

async function ensureSeeds(userId: string) {
  const sql = await getSql();
  const existing = await sql<{ c: number }>`
    select count(*)::int as c from sources where user_id = ${userId}
  `;
  if ((existing[0]?.c ?? 0) > 0) return;
  for (const s of SEED_SOURCES) {
    await sql`
      insert into sources (user_id, url, title, kind, tier, status)
      values (${userId}, ${s.url}, ${s.title}, ${s.kind}, ${s.tier}, 'accepted')
      on conflict (user_id, url) do nothing
    `;
  }
}

export const bootstrapDesk = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureSeeds(context.userId);
    return { ok: true as const };
  });

export const listSources = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureSeeds(context.userId);
    const sql = await getSql();
    return sql<SourceRow>`
      select id, url, title, kind, tier, status, last_hash, last_fetched_at, last_error
      from sources
      where user_id = ${context.userId}
      order by
        case status when 'proposed' then 0 when 'accepted' then 1 else 2 end,
        id asc
    `;
  });

function parseHttpUrl(raw: string): { ok: true; url: string; host: string } | { ok: false; error: string } {
  let value = raw.trim();
  if (!value) return { ok: false, error: "Empty URL" };
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return { ok: false, error: "Need an http(s) URL." };
    }
    return { ok: true, url: parsed.toString(), host: parsed.hostname };
  } catch {
    return { ok: false, error: "That is not a valid URL." };
  }
}

function parseSourceLines(text: string): {
  title: string;
  url: string;
  tier: string;
  kind: string;
}[] {
  let currentTier: "A" | "B" | "C" = "A";
  const out: { title: string; url: string; tier: string; kind: string }[] = [];
  const seen = new Set<string>();
  const urlRe = /https?:\/\/[^\s<>"'\\)\]]+/gi;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;

    const header = line.match(/^TIER\s*([ABC])\b/i);
    if (header && !/https?:\/\//i.test(line)) {
      currentTier = header[1]!.toUpperCase() as "A" | "B" | "C";
      continue;
    }

    urlRe.lastIndex = 0;
    const found = line.match(urlRe);
    if (!found?.length) continue;

    const first = found[0]!.replace(/[.,;:]+$/, "");
    const parsed = parseHttpUrl(first);
    if (!parsed.ok) continue;
    if (seen.has(parsed.url)) continue;
    seen.add(parsed.url);

    let title = line
      .replace(urlRe, " ")
      .replace(/^[\s*•\-–—\d.)]+/, "")
      .replace(/\s*\([^)]*@[^)]*\)\s*/g, " ")
      .replace(/\s*[|:]\s*$/g, "")
      .replace(/\s{2,}/g, " ")
      .trim()
      .replace(/[:：]\s*$/, "");

    const kind =
      /youtube\.com|youtu\.be/i.test(parsed.url)
        ? "youtube"
        : currentTier === "B"
          ? "news"
          : currentTier === "C"
            ? "community"
            : "official";

    out.push({
      title: title || parsed.host,
      url: parsed.url,
      tier: currentTier,
      kind,
    });
  }
  return out.slice(0, 400);
}

async function upsertSource(
  userId: string,
  url: string,
  title: string,
  kind: string,
  tier: string,
) {
  const sql = await getSql();
  const rows = await sql<SourceRow>`
    insert into sources (user_id, url, title, kind, tier, status)
    values (${userId}, ${url}, ${title}, ${kind}, ${tier}, 'accepted')
    on conflict (user_id, url) do update set title = excluded.title, kind = excluded.kind, tier = excluded.tier, status = 'accepted'
    returning id, url, title, kind, tier, status, last_hash, last_fetched_at, last_error
  `;
  return rows[0] ?? null;
}

export const addSource = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { url: string; title: string; kind: string; tier: string }) => input)
  .handler(async ({ context, data }) => {
    const parsed = parseHttpUrl(data.url);
    if (!parsed.ok) return { ok: false as const, error: parsed.error };
    const title = data.title.trim() || parsed.host;
    const source = await upsertSource(
      context.userId,
      parsed.url,
      title,
      data.kind || "official",
      data.tier || "A",
    );
    if (!source) return { ok: false as const, error: "Could not save that source." };
    return { ok: true as const, source };
  });

export const addSourcesBulk = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { text: string }) => input)
  .handler(async ({ context, data }) => {
    const rows = parseSourceLines(data.text);
    if (rows.length === 0) {
      return {
        ok: false as const,
        error: "No URLs found. One per line, or Title | URL.",
        added: 0,
      };
    }
    let added = 0;
    const byTier = { A: 0, B: 0, C: 0 };
    for (const row of rows) {
      const source = await upsertSource(
        context.userId,
        row.url,
        row.title,
        row.kind,
        row.tier,
      );
      if (source) {
        added += 1;
        if (row.tier === "A" || row.tier === "B" || row.tier === "C") {
          byTier[row.tier] += 1;
        }
      }
    }
    return { ok: true as const, added, total: rows.length, byTier };
  });

export const setSourceStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; status: "accepted" | "rejected" | "proposed" }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      update sources set status = ${data.status}
      where id = ${data.id} and user_id = ${context.userId}
    `;
    return { ok: true as const };
  });

export const listLeads = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<LeadRow>`
      select id, headline, why, topic, status, source_urls, evidence, newsworthiness, created_at
      from leads
      where user_id = ${context.userId}
      order by created_at desc
      limit 80
    `;
  });

export const getLead = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    const leads = await sql<LeadRow>`
      select id, headline, why, topic, status, source_urls, evidence, newsworthiness, created_at
      from leads where id = ${id} and user_id = ${context.userId} limit 1
    `;
    const lead = leads[0];
    if (!lead) return null;
    const drafts = await sql<DraftRow>`
      select id, lead_id, headline, dek, body, topic, source_urls, integrity_notes, updated_at
      from drafts where lead_id = ${id} and user_id = ${context.userId}
      order by updated_at desc limit 1
    `;
    return { lead, draft: drafts[0] ?? null };
  });

export const listMemory = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<MemoryRow>`
      select id, entity, last_angle, updated_at
      from beat_memory
      where user_id = ${context.userId}
      order by updated_at desc
      limit 80
    `;
  });

export const listScans = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<ScanRow>`
      select id, started_at, finished_at, sources_fetched, leads_created, sources_proposed, summary, error
      from scan_runs
      where user_id = ${context.userId}
      order by started_at desc
      limit 12
    `;
  });

type ScanLead = {
  headline: string;
  why: string;
  topic: string;
  source_urls: string[];
  evidence: string;
  newsworthiness: number;
};

type ScanResult = {
  leads: ScanLead[];
  proposed_sources: { url: string; title: string; why: string }[];
  editor_summary: string;
};

export const runScan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureSeeds(context.userId);
    const sql = await getSql();
    const runRows = await sql<{ id: number }>`
      insert into scan_runs (user_id) values (${context.userId}) returning id
    `;
    const runId = runRows[0]!.id;

    const sources = await sql<SourceRow>`
      select id, url, title, kind, tier, status, last_hash, last_fetched_at, last_error
      from sources
      where user_id = ${context.userId} and status = 'accepted' and tier <> 'C'
      order by case tier when 'A' then 0 when 'B' then 1 else 2 end, id asc
    `;

    const fetched: { title: string; url: string; text: string; changed: boolean }[] = [];
    let fetchedCount = 0;
    for (const src of sources.slice(0, 8)) {
      try {
        const { text } = await fetchSourceText(src.url);
        const hash = await sha256(text);
        const changed = hash !== src.last_hash;
        await sql`
          update sources
          set last_hash = ${hash}, last_fetched_at = now(), last_error = null
          where id = ${src.id} and user_id = ${context.userId}
        `;
        await sql`
          insert into snapshots (user_id, source_id, content_hash, excerpt)
          values (${context.userId}, ${src.id}, ${hash}, ${text.slice(0, 8000)})
        `;
        fetchedCount += 1;
        fetched.push({
          title: src.title,
          url: src.url,
          text: text.slice(0, 4500),
          changed,
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : "fetch failed";
        await sql`
          update sources set last_error = ${msg}, last_fetched_at = now()
          where id = ${src.id} and user_id = ${context.userId}
        `;
      }
    }

    const memory = await sql<MemoryRow>`
      select id, entity, last_angle, updated_at from beat_memory
      where user_id = ${context.userId} order by updated_at desc limit 24
    `;

    const payload = fetched
      .map(
        (f) =>
          `SOURCE: ${f.title}\nURL: ${f.url}\nCHANGED: ${f.changed ? "yes" : "no (still include if newly newsworthy)"}\nTEXT:\n${f.text}`,
      )
      .join("\n\n---\n\n")
      .slice(0, 22000);

    const userMsg = `City: ${PAPER.city}, ${PAPER.state}.
Already covered (do not refile as news unless there is a new fact):
${memory.map((m) => `- ${m.entity}: ${m.last_angle}`).join("\n") || "(none yet)"}

Fetched source text:
${payload || "(no source text this run)"}

Return JSON:
{
  "editor_summary": "2-4 sentences for the editor",
  "leads": [
    {
      "headline": "",
      "why": "why this is news now",
      "topic": "council|budget|housing|utilities|schools|planning|infrastructure|elections",
      "source_urls": ["https://..."],
      "evidence": "short quotes or facts from the text",
      "newsworthiness": 0
    }
  ],
  "proposed_sources": [
    { "url": "https://...", "title": "", "why": "official page worth watching" }
  ]
}
File 0-6 leads. Prefer changed pages. newsworthiness is 0-20. proposed_sources: only official city/county/school URLs not already in the fetch list. Max 4.`;

    const ai = await grokChat(SCAN_SYSTEM, userMsg, 1600);
    if (!ai.ok) {
      await sql`
        update scan_runs
        set finished_at = now(), sources_fetched = ${fetchedCount}, error = ${ai.error}
        where id = ${runId} and user_id = ${context.userId}
      `;
      return { ok: false as const, error: ai.error, runId, fetchedCount };
    }

    const parsed = parseJsonBlock<ScanResult>(ai.text) ?? {
      leads: [],
      proposed_sources: [],
      editor_summary: ai.text.slice(0, 600),
    };

    let leadsCreated = 0;
    for (const lead of parsed.leads ?? []) {
      if (!lead.headline?.trim()) continue;
      const urls = JSON.stringify(lead.source_urls ?? []);
      await sql`
        insert into leads (user_id, scan_run_id, headline, why, topic, source_urls, evidence, newsworthiness, status)
        values (
          ${context.userId}, ${runId}, ${lead.headline.slice(0, 180)},
          ${String(lead.why ?? "").slice(0, 800)},
          ${String(lead.topic ?? "council").slice(0, 40)},
          ${urls},
          ${String(lead.evidence ?? "").slice(0, 2000)},
          ${Number(lead.newsworthiness) || 0},
          'new'
        )
      `;
      leadsCreated += 1;
    }

    let proposed = 0;
    for (const p of parsed.proposed_sources ?? []) {
      if (!p.url || !/^https?:\/\//i.test(p.url)) continue;
      await sql`
        insert into sources (user_id, url, title, kind, tier, status)
        values (${context.userId}, ${p.url}, ${p.title || p.url}, 'official', 'A', 'proposed')
        on conflict (user_id, url) do nothing
      `;
      proposed += 1;
    }

    const summary = String(parsed.editor_summary ?? "").slice(0, 1200);
    await sql`
      update scan_runs
      set finished_at = now(),
          sources_fetched = ${fetchedCount},
          leads_created = ${leadsCreated},
          sources_proposed = ${proposed},
          summary = ${summary}
      where id = ${runId} and user_id = ${context.userId}
    `;

    return {
      ok: true as const,
      runId,
      fetchedCount,
      leadsCreated,
      proposed,
      summary,
    };
  });

export const draftLead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((leadId: number) => leadId)
  .handler(async ({ context, data: leadId }) => {
    const sql = await getSql();
    const leads = await sql<LeadRow>`
      select id, headline, why, topic, status, source_urls, evidence, newsworthiness, created_at
      from leads where id = ${leadId} and user_id = ${context.userId} limit 1
    `;
    const lead = leads[0];
    if (!lead) return { ok: false as const, error: "Lead not found" };

    let urls: string[] = [];
    try {
      urls = JSON.parse(lead.source_urls) as string[];
    } catch {
      urls = [];
    }

    const evidenceBits: string[] = [];
    if (lead.evidence) evidenceBits.push(lead.evidence);
    for (const url of urls.slice(0, 4)) {
      try {
        const { text } = await fetchSourceText(url);
        evidenceBits.push(`URL ${url}\n${text.slice(0, 3500)}`);
      } catch {
        evidenceBits.push(`URL ${url} (could not refetch)`);
      }
    }

    const memory = await sql<MemoryRow>`
      select entity, last_angle from beat_memory
      where user_id = ${context.userId} order by updated_at desc limit 16
    `;

    const userMsg = `Draft a publishable recap.
Lead headline: ${lead.headline}
Why: ${lead.why}
Topic hint: ${lead.topic}
Already covered: ${memory.map((m) => `${m.entity} (${m.last_angle})`).join("; ") || "none"}

Evidence:
${evidenceBits.join("\n\n").slice(0, 16000)}`;

    const ai = await grokChat(DRAFT_SYSTEM, userMsg, 1800);
    if (!ai.ok) return { ok: false as const, error: ai.error };

    type DraftJson = {
      headline: string;
      dek: string;
      body: string;
      topic: string;
      source_urls: string[];
      integrity_notes: string;
      memory_entities: string[];
    };
    const parsed = parseJsonBlock<DraftJson>(ai.text);
    const headline = parsed?.headline?.trim() || lead.headline;
    const dek = parsed?.dek?.trim() || lead.why;
    const body = parsed?.body?.trim() || ai.text;
    const topic = parsed?.topic?.trim() || lead.topic;
    const sourceUrls = JSON.stringify(parsed?.source_urls?.length ? parsed.source_urls : urls);
    const notes = parsed?.integrity_notes?.trim() || "";

    await sql`
      insert into drafts (user_id, lead_id, headline, dek, body, topic, source_urls, integrity_notes)
      values (${context.userId}, ${leadId}, ${headline}, ${dek}, ${body}, ${topic}, ${sourceUrls}, ${notes})
    `;
    await sql`
      update leads set status = 'drafted' where id = ${leadId} and user_id = ${context.userId}
    `;

    return { ok: true as const };
  });

export const saveDraft = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: {
      leadId: number;
      headline: string;
      dek: string;
      body: string;
      topic: string;
    }) => input,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const existing = await sql<{ id: number }>`
      select id from drafts where lead_id = ${data.leadId} and user_id = ${context.userId}
      order by updated_at desc limit 1
    `;
    if (existing[0]) {
      await sql`
        update drafts
        set headline = ${data.headline}, dek = ${data.dek}, body = ${data.body},
            topic = ${data.topic}, updated_at = now()
        where id = ${existing[0].id} and user_id = ${context.userId}
      `;
    } else {
      await sql`
        insert into drafts (user_id, lead_id, headline, dek, body, topic)
        values (${context.userId}, ${data.leadId}, ${data.headline}, ${data.dek}, ${data.body}, ${data.topic})
      `;
    }
    return { ok: true as const };
  });

export const setLeadStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; status: "held" | "killed" | "new" }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      update leads set status = ${data.status}
      where id = ${data.id} and user_id = ${context.userId}
    `;
    return { ok: true as const };
  });

export const publishLead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((leadId: number) => leadId)
  .handler(async ({ context, data: leadId }) => {
    const sql = await getSql();
    const drafts = await sql<DraftRow>`
      select id, lead_id, headline, dek, body, topic, source_urls, integrity_notes, updated_at
      from drafts where lead_id = ${leadId} and user_id = ${context.userId}
      order by updated_at desc limit 1
    `;
    const draft = drafts[0];
    if (!draft) return { ok: false as const, error: "Draft this lead before publishing." };

    let slug = slugify(draft.headline);
    const clash = await sql<{ slug: string }>`select slug from articles where slug = ${slug}`;
    if (clash[0]) slug = `${slug}-${leadId}`;

    await sql`
      insert into articles (user_id, lead_id, slug, headline, dek, body, topic, source_urls, status, published_at)
      values (
        ${context.userId}, ${leadId}, ${slug}, ${draft.headline}, ${draft.dek},
        ${draft.body}, ${draft.topic}, ${draft.source_urls}, 'published', now()
      )
    `;
    await sql`
      update leads set status = 'published' where id = ${leadId} and user_id = ${context.userId}
    `;

    const entities = [draft.topic, ...draft.headline.split(/[:,—-]/).slice(0, 2)];
    for (const entity of entities.map((e) => e.trim()).filter((e) => e.length > 2)) {
      await sql`
        insert into beat_memory (user_id, entity, last_angle)
        values (${context.userId}, ${entity.slice(0, 80)}, ${draft.dek.slice(0, 200)})
      `;
    }

    return { ok: true as const, slug };
  });

export const addCorrection = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { articleSlug?: string; body: string }) => input)
  .handler(async ({ context, data }) => {
    const body = data.body.trim();
    if (body.length < 8) return { ok: false as const, error: "Write the correction." };
    const sql = await getSql();
    let articleId: number | null = null;
    if (data.articleSlug) {
      const rows = await sql<{ id: number }>`
        select id from articles where slug = ${data.articleSlug} limit 1
      `;
      articleId = rows[0]?.id ?? null;
    }
    await sql`
      insert into corrections (user_id, article_id, body)
      values (${context.userId}, ${articleId}, ${body})
    `;
    return { ok: true as const };
  });
