const PRIVATE =
  /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.|0\.|\[::1\]|169\.254\.)/i;

export function assertPublicHttpUrl(raw: string): URL {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    throw new Error("Invalid URL");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("Only http(s) URLs are allowed");
  }
  if (PRIVATE.test(url.hostname) || url.hostname.endsWith(".local")) {
    throw new Error("That host is not fetchable");
  }
  return url;
}

function stripHtml(html: string) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&/g, "&")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function youtubeVideoId(url: URL): string | null {
  if (url.hostname.includes("youtu.be")) {
    return url.pathname.replace("/", "") || null;
  }
  if (url.hostname.includes("youtube.com")) {
    return url.searchParams.get("v");
  }
  return null;
}

async function fetchYoutubeCaptions(videoId: string): Promise<string | null> {
  const timed = new URL("https://www.youtube.com/api/timedtext");
  timed.searchParams.set("v", videoId);
  timed.searchParams.set("lang", "en");
  timed.searchParams.set("fmt", "srv3");
  const res = await fetch(timed, {
    headers: { "User-Agent": "TownReporter/1.0 civic-news desk" },
    signal: AbortSignal.timeout(8000),
  });
  if (!res.ok) return null;
  const xml = await res.text();
  const text = stripHtml(xml);
  return text.length > 40 ? text : null;
}

export async function fetchSourceText(
  rawUrl: string,
): Promise<{ text: string; titleHint: string }> {
  const url = assertPublicHttpUrl(rawUrl);
  const videoId = youtubeVideoId(url);
  if (videoId) {
    const captions = await fetchYoutubeCaptions(videoId);
    if (captions) {
      return {
        text: `YouTube captions (auto or manual; verify quotes against the video).\nVideo ${videoId}\n\n${captions}`,
        titleHint: `YouTube ${videoId}`,
      };
    }
  }

  const res = await fetch(url, {
    redirect: "follow",
    headers: {
      "User-Agent":
        "TownReporter/1.0 (+https://grok.me; civic newspaper source fetch)",
      Accept: "text/html,application/xhtml+xml,application/xml,text/plain;q=0.9",
    },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) throw new Error(`Fetch failed (${res.status})`);
  const ctype = res.headers.get("content-type") ?? "";
  if (
    !/text\/html|application\/xhtml|application\/xml|text\/plain|application\/json|text\/xml/i.test(
      ctype,
    ) &&
    ctype
  ) {
    throw new Error(`Unsupported content type: ${ctype}`);
  }
  const html = await res.text();
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const titleHint = titleMatch ? stripHtml(titleMatch[1]).slice(0, 140) : url.hostname;
  const text = stripHtml(html).slice(0, 14000);
  if (text.length < 40) throw new Error("Page had almost no readable text");
  return { text, titleHint };
}

export async function sha256(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
