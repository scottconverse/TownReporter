import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import type { ArticleRow, CorrectionRow } from "./types";

export const listPublishedArticles = createServerFn({ method: "GET" }).handler(
  async () => {
    const sql = await getSql();
    return sql<ArticleRow>`
      select id, slug, headline, dek, body, topic, source_urls, status, published_at
      from articles
      where status = 'published'
      order by published_at desc
    `;
  },
);

export const getPublishedArticle = createServerFn({ method: "GET" })
  .validator((slug: string) => slug)
  .handler(async ({ data: slug }) => {
    const sql = await getSql();
    const rows = await sql<ArticleRow>`
      select id, slug, headline, dek, body, topic, source_urls, status, published_at
      from articles
      where slug = ${slug} and status = 'published'
      limit 1
    `;
    return rows[0] ?? null;
  });

export const listPublishedByTopic = createServerFn({ method: "GET" })
  .validator((topic: string) => topic)
  .handler(async ({ data: topic }) => {
    const sql = await getSql();
    return sql<ArticleRow>`
      select id, slug, headline, dek, body, topic, source_urls, status, published_at
      from articles
      where status = 'published' and topic = ${topic}
      order by published_at desc
    `;
  });

export const searchPublished = createServerFn({ method: "GET" })
  .validator((q: string) => q.trim().slice(0, 80))
  .handler(async ({ data: q }) => {
    if (!q) return [] as ArticleRow[];
    const sql = await getSql();
    const like = `%${q}%`;
    return sql<ArticleRow>`
      select id, slug, headline, dek, body, topic, source_urls, status, published_at
      from articles
      where status = 'published'
        and (headline ilike ${like} or dek ilike ${like} or body ilike ${like})
      order by published_at desc
      limit 40
    `;
  });

export const listPublicCorrections = createServerFn({ method: "GET" }).handler(
  async () => {
    const sql = await getSql();
    return sql<CorrectionRow>`
      select c.id, c.body, c.created_at, a.headline
      from corrections c
      left join articles a on a.id = c.article_id
      order by c.created_at desc
      limit 50
    `;
  },
);

export const subscribeNewsletter = createServerFn({ method: "POST" })
  .validator((email: string) => email.trim().toLowerCase())
  .handler(async ({ data: email }) => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false as const, error: "That does not look like an email." };
    }
    const sql = await getSql();
    try {
      await sql`insert into subscribers (email) values (${email})`;
    } catch {
      return { ok: true as const };
    }
    return { ok: true as const };
  });
