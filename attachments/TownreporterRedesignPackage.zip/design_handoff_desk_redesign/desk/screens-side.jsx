const {useState:uS2} = React;

function SourcesScreen({S, A}){
  const [form, setForm] = uS2({url:"", title:""});
  const [note, setNote] = uS2(null);
  const groups = [
    {k:"proposed", title:"Proposed", sub:"Turned up by scans and Dark Desk. Nothing is fetched until you accept it.", acts:["accepted","rejected"]},
    {k:"accepted", title:"On watch", sub:"What the scanner is allowed to fetch. Tier A is official record; B is journalism; C is a discovery clue, never treated as fact.", acts:["rejected"]},
    {k:"rejected", title:"Rejected", sub:null, acts:["accepted"]},
  ];
  return <div className="narrowish">
    <Kicker>Watch list</Kicker><h1 className="h1">Sources</h1>
    <p className="lede">The pages the scanner reads on every pass. Add one, paste a whole registry, or review what the machine proposes.</p>
    <div className="src-add">
      <label className="f"><span>URL</span><input value={form.url} onChange={e=>setForm({...form, url:e.target.value})} placeholder="https://www.longmontcolorado.gov/…"/></label>
      <label className="f"><span>Name</span><input value={form.title} onChange={e=>setForm({...form, title:e.target.value})} placeholder="City Council packets"/></label>
      <Btn solid small disabled={!form.url.trim()} onClick={()=>{A.addSource(form); setNote("On watch: "+(form.title||form.url)); setForm({url:"", title:""});}}>Add source</Btn>
    </div>
    <details className="file-form"><summary>Bulk paste a registry (.txt, .md, .csv — TIER A/B/C headers honored)</summary>
      <textarea rows={5} className="bulk" placeholder={"TIER A — OFFICIAL RECORD\n* City Council: https://www.longmontcolorado.gov/…\nTIER B — JOURNALISM\n* Times-Call: https://www.timescall.com/"}></textarea>
      <Btn small solid onClick={()=>setNote("Prototype: bulk add is simulated in the real desk.")}>Add list</Btn>
    </details>
    {note?<Note kind="ok">{note}</Note>:null}
    {groups.map(g=>{
      const rows = S.sources.filter(s=>s.status===g.k);
      if(!rows.length&&g.k!=="accepted") return null;
      return <section key={g.k} className="src-sec">
        <SecHead title={g.title} count={rows.length} sub={g.sub}/>
        <table className="ltable"><thead><tr><th>Source</th><th>Tier</th><th>Kind</th><th>Last fetched</th><th></th></tr></thead><tbody>
          {rows.map(s=><tr key={s.id} className="lead-tr">
            <td className="td-hl"><span className="src-t">{s.title}</span><span className="meta-inline">{s.url}</span>{s.note?<span className="meta-inline block">{s.note}</span>:null}{s.error?<span className="warn-inline">{s.error}</span>:null}</td>
            <td className="td-meta">{s.tier}</td><td className="td-meta">{s.kind}</td><td className="td-meta">{s.fetched||"—"}</td>
            <td className="td-acts"><span className="row-acts">
              {g.acts.includes("accepted")?<Btn small quiet onClick={()=>A.sourceStatus(s.id,"accepted")}>Accept</Btn>:null}
              {g.acts.includes("rejected")?<Btn small quiet danger onClick={()=>A.sourceStatus(s.id,"rejected")}>Drop</Btn>:null}
            </span></td>
          </tr>)}
        </tbody></table>
      </section>;
    })}
  </div>;
}

function ScanScreen({S, A, nav}){
  const last = S.scans[0];
  return <div className="narrowish">
    <Kicker>Reporter pass</Kicker><h1 className="h1">Scan</h1>
    <p className="lede">One pass over the watch list: fetch every accepted source, then one AI read for leads and proposed sources. It runs only when you click — this is the expensive button, not a loop.</p>
    <div className="scan-bar"><Btn solid disabled={S.scanBusy} onClick={A.runScan}>{S.scanBusy?"Scanning sources…":"Run scan"}</Btn>
      <Meta>{S.sources.filter(s=>s.status==="accepted").length} sources on watch · last ran {last.date}</Meta></div>
    {S.scanBusy?<Busy label="Fetching accepted sources, then one pass for leads. Stay on this page."/>:null}
    {S.scanDone?<div className="scan-result"><p className="wire-line"><b>Done.</b> {S.scanDone.fetched} fetched · {S.scanDone.leads} leads filed · {S.scanDone.proposed} source proposed</p><p className="wire-sum">{S.scanDone.summary}</p><Btn small solid onClick={()=>nav("queue")}>Open the queue</Btn></div>:null}
    <SecHead title="Previous scans" count={S.scans.length}/>
    <div className="scan-hist">{S.scans.map(s=><div key={s.id} className="scan-row">
      <p className="meta">{s.date}</p>
      <p className="scan-line">{s.fetched} fetched · {s.leads} leads · {s.proposed} proposed</p>
      <p className="wire-sum">{s.summary}</p>
    </div>)}</div>
  </div>;
}

function PublishedScreen({S, A, nav}){
  const [corrFor, setCorrFor] = uS2(null);
  const [corrText, setCorrText] = uS2("");
  return <div className="narrowish">
    <Kicker>The record</Kicker><h1 className="h1">Published</h1>
    <p className="lede">What is live on the paper, with its corrections. Corrections are public; unpublishing pulls a piece back to the queue as a draft.</p>
    <div className="pub-list">{S.published.map(p=><div key={p.id} className="pub-row">
      <div className="pub-main">
        <Meta>{p.topic} · {p.date} · scored {p.leadScore}/20 at filing</Meta>
        <h3 className="pub-h">{p.headline}</h3>
        <p className="pub-dek">{p.dek}</p>
        {p.corrections.map((c,i)=><p key={i} className="pub-corr"><b>Correction, {c.date}:</b> {c.body}</p>)}
        {corrFor===p.id?<div className="corr-form">
          <textarea rows={3} value={corrText} onChange={e=>setCorrText(e.target.value)} placeholder="What was wrong, and what is right."/>
          <div className="row-acts static"><Btn small solid disabled={!corrText.trim()} onClick={()=>{A.postCorrection(p.id, corrText); setCorrFor(null); setCorrText("");}}>Publish correction</Btn><Btn small quiet onClick={()=>setCorrFor(null)}>Cancel</Btn></div>
        </div>:null}
      </div>
      <div className="pub-acts">
        <Btn small quiet onClick={()=>A.openArticle(p.id)}>Read on the paper</Btn>
        <Btn small quiet onClick={()=>{setCorrFor(p.id); setCorrText("");}}>Post correction</Btn>
        <Btn small quiet danger onClick={()=>A.unpublish(p.id)}>Unpublish</Btn>
      </div>
    </div>)}</div>
    <SecHead title="Beat memory" count={S.memory.length} sub="What the drafting AI is told we already covered, so the paper doesn't repeat itself."/>
    <table className="ltable"><thead><tr><th>Entity</th><th>Last angle</th><th>Updated</th></tr></thead><tbody>
      {S.memory.map((m,i)=><tr key={i} className="lead-tr"><td className="td-hl"><span className="src-t">{m.e}</span></td><td className="td-meta wide">{m.angle}</td><td className="td-meta">{m.d}</td></tr>)}
    </tbody></table>
  </div>;
}

function OpenFile({inv, S, A, nav}){
  const [showAll, setShowAll] = uS2(false);
  const arts = showAll?inv.artifacts:inv.artifacts.slice(0,4);
  const paused = inv.status==="paused";
  return <section className="openfile">
    <div className="of-head">
      <div>
        <Kicker tone="dark">Open file</Kicker>
        <h2 className="of-title">{inv.title}</h2>
        <Meta>{paused?"Stopped — more to read":inv.status==="aside"?"Set aside":"Ready to continue"} · {inv.records} records on file{inv.stillOpen?` · ${inv.stillOpen} still to open`:""} · round {inv.round} of {inv.budget} · last touched {inv.touched}</Meta>
      </div>
      <div className="row-acts static">
        {inv.stillOpen>0?<Btn solid disabled={S.digBusy} onClick={()=>A.keepDigging(inv.id)}>{S.digBusy?"Reading…":"Keep digging"}</Btn>:null}
        <Btn onClick={()=>A.sendToQueue(inv.id)}>Send to the queue</Btn>
        <Btn quiet onClick={()=>A.park(inv.id)}>Set aside</Btn>
        <Btn quiet onClick={()=>A.setOpenDark(null)}>Close file</Btn>
      </div>
    </div>
    {S.digBusy?<Busy label={S.digPhase||"Searching records…"}/>:null}
    {inv.queuedNote?<Note kind="ok">{inv.queuedNote} <button className="inline-link" onClick={()=>nav("queue")}>Open the queue</button></Note>:null}
    <p className="of-started">{inv.started}</p>
    {paused&&inv.stopReason?<p className="of-stop"><b>Why it stopped:</b> {inv.stopReason} Keep digging reads the next batch.</p>:null}
    <div className="of-grid">
      <div>
        <SecHead title="What to read" count={inv.records} sub="Pages and documents already captured. This is the file — click into any of them."/>
        <div className="of-reads">{arts.map(a=><ReadItem key={a.id} a={a}/>)}</div>
        {inv.artifacts.length>4&&!showAll?<Btn small quiet onClick={()=>setShowAll(true)}>Show all {inv.records} records ({inv.artifacts.length} captured in this prototype)</Btn>:null}
      </div>
      <div>
        {inv.stillOpen>0?<>
          <SecHead title="Still unopened" count={inv.stillOpen} sub="Names, pages, and documents mentioned in the records. Not read yet."/>
          <div className="of-frontier">{inv.frontier.map(f=><div key={f.id} className="fr-item">
            <p className="fr-label">{f.label}</p>
            <p className="fr-why">{f.why}</p>
            <Btn small quiet onClick={()=>{A.followLead(f, inv);}}>Follow this lead</Btn>
          </div>)}</div>
        </>:null}
        {inv.noticed.length?<div className="of-block"><p className="side-label">What Dark Desk noticed</p>{inv.noticed.map((n,i)=><p key={i} className="side-item">{n}</p>)}</div>:null}
        {inv.know.length?<div className="of-block"><p className="side-label">What we know</p>{inv.know.map((n,i)=><p key={i} className="side-item">{n}</p>)}</div>:null}
        <details className="of-trail"><summary>Research trail — {inv.trail.length} searches</summary>{inv.trail.map((t,i)=><p key={i} className="side-item">“{t}”</p>)}</details>
        {inv.deadEnds.length?<details className="of-trail"><summary>Dead ends — {inv.deadEnds.length}</summary>{inv.deadEnds.map((d,i)=><p key={i} className="side-item"><b>{d.h}</b> — {d.why}</p>)}</details>:null}
      </div>
    </div>
  </section>;
}
function ReadItem({a}){
  const [open, setOpen] = uS2(false);
  return <div className="read-item">
    <p className="read-kind">{a.kind} · {a.org} · captured {a.captured}</p>
    <p className="read-title">{a.title}</p>
    <p className="read-ex">{a.excerpt}</p>
    <p className="read-acts"><button className="inline-link" onClick={()=>setOpen(!open)}>{open?"Hide captured copy":"Read captured copy"}</button><span className="read-url">{a.url}</span></p>
    {open?<p className="read-full">{a.excerpt} [Full captured text opens here in the real desk.]</p>:null}
  </div>;
}

function DarkScreen({S, A, nav}){
  const [tip, setTip] = uS2("");
  const open = S.invs.find(i=>i.id===S.openDarkId);
  const onDesk = S.invs.filter(i=>(i.status==="paused"||i.status==="open"||i.status==="investigating"));
  const aside = S.invs.filter(i=>i.status==="aside");
  return <div>
    <div className="ov-head"><div><Kicker tone="dark">Investigative desk</Kicker><h1 className="h1">Dark Desk</h1></div>
    <p className="dark-lede">Three piles. <b>To look at</b> is new. <b>On the desk</b> is started. <b>Set aside</b> is parked — nothing is deleted. It digs; it never prints.</p></div>
    {open?<OpenFile inv={open} S={S} A={A} nav={nav}/>:null}
    <div className="piles">
      <section>
        <SecHead title="To look at" count={S.worth.length} sub="New material. Nobody has opened it yet."/>
        {S.worth.map(w=><div key={w.id} className="worth">
          <p className="np-kind">{w.kind}</p>
          <p className="worth-t">{w.title}</p>
          <p className="worth-line"><b>Why it matters</b> — {w.why}</p>
          <p className="worth-line"><b>What changed</b> — {w.happened}</p>
          <p className="worth-q">First question: {w.q}</p>
          <p className="meta">{w.src}</p>
          <div className="np-acts"><Btn small solid disabled={S.digBusy} onClick={()=>A.startDig(w)}>Start digging</Btn></div>
        </div>)}
        {!S.worth.length?<p className="meta">Nothing new tonight — everything interesting is already on the desk.</p>:null}
      </section>
      <section>
        <SecHead title="On the desk" count={onDesk.length} sub="Started. A stop mid-file is normal — it means more to read, not a failure."/>
        {onDesk.map(i=><div key={i.id} className={"deskfile"+(i.id===S.openDarkId?" sel":"")}>
          <p className="np-kind">{i.status==="paused"?"Stopped — more to read":"Ready to continue"}</p>
          <p className="worth-t">{i.title}</p>
          <p className="np-meta">{i.records} records on file{i.stillOpen?` · ${i.stillOpen} still to open`:""} · last touched {i.touched}</p>
          <div className="np-acts">
            <Btn small solid onClick={()=>A.setOpenDark(i.id)}>{i.id===S.openDarkId?"Viewing above":"Open file"}</Btn>
            {i.stillOpen>0?<Btn small disabled={S.digBusy} onClick={()=>{A.setOpenDark(i.id); A.keepDigging(i.id);}}>Keep digging</Btn>:null}
            <Btn small quiet onClick={()=>A.park(i.id)}>Set aside</Btn>
          </div>
        </div>)}
        {!onDesk.length?<p className="meta">Empty. Start digging on a card and it moves here.</p>:null}
      </section>
      <section>
        <SecHead title="Set aside" count={aside.length} sub="Parked or finished. Pull anything back."/>
        {aside.map(i=><div key={i.id} className="deskfile dim">
          <p className="worth-t">{i.title}</p>
          <p className="np-meta">{i.records} records · last touched {i.touched}</p>
          {i.know.length?<p className="np-meta">{i.know[0]}</p>:null}
          <div className="np-acts"><Btn small onClick={()=>A.pullBack(i.id)}>Pull back</Btn><Btn small quiet onClick={()=>A.setOpenDark(i.id)}>Read</Btn></div>
        </div>)}
        {!aside.length?<p className="meta">Nothing set aside yet.</p>:null}
        <div className="tipbox">
          <p className="side-label">Start from a tip</p>
          <p className="meta">A URL, a person, an LLC, a contract number, a rumor, a gap. It opens a new file on the desk.</p>
          <textarea rows={3} value={tip} onChange={e=>setTip(e.target.value)} placeholder="Transcript, staff report, an LLC, an RFP number…"/>
          <Btn small solid disabled={!tip.trim()||S.digBusy} onClick={()=>{A.startTip(tip); setTip("");}}>Start digging</Btn>
        </div>
        <details className="of-trail runs"><summary>What Dark Desk did — {S.runs.length} recent runs</summary>
          {S.runs.map((r,i)=><div key={i} className="run-row"><p className="meta">{r.d}</p><p className="side-item">{r.text}</p></div>)}
        </details>
      </section>
    </div>
  </div>;
}
Object.assign(window, {SourcesScreen, ScanScreen, PublishedScreen, DarkScreen});
