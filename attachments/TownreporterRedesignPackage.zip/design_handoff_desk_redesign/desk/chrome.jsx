const {useState, useEffect} = React;
function ModeSeg({mode, setMode}){
  return <div className="seg" role="group" aria-label="Light or dark">
    <button className={"seg-opt"+(mode==="light"?" on":"")} onClick={()=>setMode("light")}>Light</button>
    <button className={"seg-opt"+(mode==="dark"?" on":"")} onClick={()=>setMode("dark")}>Dark</button>
  </div>;
}
function Kicker({children, tone}){ return <p className={"kick"+(tone?" "+tone:"")}>{children}</p>; }
function Btn({children, onClick, solid, danger, quiet, disabled, small, title}){
  const cls = "btn"+(solid?" solid":"")+(danger?" danger":"")+(quiet?" quiet":"")+(small?" small":"");
  return <button className={cls} onClick={onClick} disabled={disabled} title={title}>{children}</button>;
}
function Chip({s}){ return <span className={"chip st-"+s}>{s==="aside"?"set aside":s}</span>; }
function Score({v}){ return <span className={"score"+(v>=14?" hot":v>=10?" warm":"")} title={"Newsworthiness "+v+"/20"}>{v}</span>; }
function SecHead({title, count, aside, sub}){
  return <div className="sechead">
    <div className="sechead-l"><h3 className="sec-title">{title}</h3>{count!=null?<span className="sec-count">{count}</span>:null}</div>
    {aside||null}
    {sub?<p className="sec-sub">{sub}</p>:null}
  </div>;
}
function Busy({label}){ return <div className="busy"><div className="busy-rule"></div><p className="busy-label">{label}</p></div>; }
function Note({kind, children}){ return <p className={"note "+(kind||"ok")}>{children}</p>; }
function Meta({children}){ return <p className="meta">{children}</p>; }

const NAV = [
  {id:"desk", label:"Desk"},
  {id:"sources", label:"Sources"},
  {id:"scan", label:"Scan"},
  {id:"queue", label:"Queue"},
  {id:"published", label:"Published"},
];
function Shell({screen, nav, mode, setMode, night, children}){
  return <div className={"shell"+(night?" night":"")}>
    <header className="masthead">
      <div className="mast-row">
        <div className="mast-brand">
          <span className="brand" onClick={()=>nav("desk")}>TownReporter</span>
          <span className="brand-sub">{night?"Dark Desk — investigates, never prints":"Editor's desk — Longmont"}</span>
        </div>
        <div className="mast-date">Wednesday, August 26, 2026 · morning edition not yet put to bed</div>
        <div className="mast-tools">
          <button className="mast-link" onClick={()=>nav("paper")}>View paper</button>
          <ModeSeg mode={mode} setMode={setMode}/>
        </div>
      </div>
      <div className="rule2"></div>
      <nav className="deskname">
        {NAV.map(n=>{
          const on = screen===n.id || (n.id==="queue" && screen==="story");
          return <button key={n.id} className={"nav-item"+(on?" on":"")} onClick={()=>nav(n.id)}>{n.label}</button>;
        })}
        <span className="nav-sep" aria-hidden></span>
        <button className={"nav-item nav-dark"+(screen==="dark"?" on":"")} onClick={()=>nav("dark")}>Dark Desk</button>
      </nav>
      <div className="rule1"></div>
    </header>
    <main className="deskmain">{children}</main>
  </div>;
}
Object.assign(window, {Kicker, Btn, Chip, Score, SecHead, Busy, Note, Meta, Shell, ModeSeg});
