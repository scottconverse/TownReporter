import { createFileRoute, Link } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { PAPER } from "@/lib/paper";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <main
      className="grid min-h-dvh place-items-center bg-paper px-6 text-ink"
      style={{ background: "#F6F1E7", color: "#1C1410", minHeight: "100dvh" }}
    >
      <div className="w-full max-w-sm space-y-5">
        <div>
          <p className="text-[11px] tracking-[0.18em] text-rust uppercase">
            {PAPER.name}
          </p>
          <h1 className="mt-2 font-display text-3xl font-semibold">
            Editor sign-in
          </h1>
          <p className="mt-2 text-sm text-muted">
            The public paper is open. The desk is not. Sign in to scan sources,
            draft, and publish.
          </p>
        </div>
        {authEnabled ? (
          GROK_PROVIDERS.map((p) => (
            <button
              key={p.providerId}
              type="button"
              onClick={() => signIn(p.providerId, { callbackURL: "/desk" })}
              className="w-full min-h-11 border border-ink bg-paper px-4 text-sm hover:bg-paper-2"
            >
              Continue with {p.label}
            </button>
          ))
        ) : (
          <p className="text-sm text-muted">Sign-in is disabled.</p>
        )}
        <Link to="/" className="inline-block text-sm text-muted hover:text-ink">
          Back to the paper
        </Link>
      </div>
    </main>
  );
}
