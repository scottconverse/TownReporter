import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { DeskShell, InkButton } from "@/components/desk-chrome";
import { listScans, runScan } from "@/lib/news/desk";
import { formatDate } from "@/lib/paper";

export const Route = createFileRoute("/desk/scan")({ component: ScanPage });

function ScanPage() {
  const qc = useQueryClient();
  const scans = useQuery({ queryKey: ["scans"], queryFn: () => listScans() });
  const scan = useMutation({
    mutationFn: () => runScan(),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["scans"] });
      void qc.invalidateQueries({ queryKey: ["leads"] });
      void qc.invalidateQueries({ queryKey: ["sources"] });
    },
  });

  return (
    <DeskShell title="Scan" kicker="Reporter pass">
      <p className="max-w-2xl text-ink-2">
        Fetches up to sixteen accepted sources, then asks Grok for leads and new
        official URLs. This is the expensive button. Use it when you want a
        new edition, not on a loop.
      </p>
      <div className="mt-6 flex flex-wrap items-center gap-3">
        <InkButton disabled={scan.isPending} onClick={() => scan.mutate()}>
          {scan.isPending ? "Scanning sources…" : "Run scan"}
        </InkButton>
        {scan.isPending && (
          <p className="text-sm text-muted">
            Fetch plus one Grok call. Stay on this page.
          </p>
        )}
      </div>
      {scan.data && scan.data.ok && (
        <div className="mt-6 border border-ink bg-paper p-4">
          <p className="font-medium">
            Fetched {scan.data.fetchedCount} · leads {scan.data.leadsCreated} ·
            proposed {scan.data.proposed}
          </p>
          <p className="mt-2 text-ink-2">{scan.data.summary}</p>
          <Link
            to="/desk/queue"
            className="mt-4 inline-flex min-h-11 items-center bg-ink px-4 text-sm text-paper hover:bg-ink-2"
          >
            Open the queue
            {scan.data.leadsCreated ? ` (${scan.data.leadsCreated} leads)` : ""}
          </Link>
        </div>
      )}
      {scan.data && !scan.data.ok && (
        <p className="mt-4 text-danger">{scan.data.error}</p>
      )}
      {scan.error && (
        <p className="mt-4 text-danger">
          {scan.error instanceof Error ? scan.error.message : "Scan failed"}
        </p>
      )}

      <h2 className="mt-10 font-display text-2xl">Previous scans</h2>
      <ul className="mt-3 divide-y divide-rule border border-rule bg-paper">
        {(scans.data ?? []).map((s) => (
          <li key={s.id} className="px-4 py-3">
            <p className="text-sm text-muted">{formatDate(s.started_at)}</p>
            <p className="mt-1">
              {s.sources_fetched} sources · {s.leads_created} leads
              {s.error ? ` · ${s.error}` : ""}
            </p>
            {s.summary && <p className="mt-1 text-ink-2">{s.summary}</p>}
          </li>
        ))}
      </ul>
    </DeskShell>
  );
}
