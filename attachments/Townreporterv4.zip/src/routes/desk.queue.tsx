import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { DeskShell, InkButton } from "@/components/desk-chrome";
import { listLeads, setLeadStatus } from "@/lib/news/desk";
import { formatShortDate } from "@/lib/paper";

export const Route = createFileRoute("/desk/queue")({ component: QueuePage });

function QueuePage() {
  const qc = useQueryClient();
  const { data: leads = [], isPending } = useQuery({
    queryKey: ["leads"],
    queryFn: () => listLeads(),
  });
  const setStatus = useMutation({
    mutationFn: (input: { id: number; status: "held" | "killed" | "new" }) =>
      setLeadStatus({ data: input }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["leads"] }),
  });

  return (
    <DeskShell title="Queue" kicker="Leads">
      <p className="max-w-2xl text-ink-2">
        What Grok thinks is news. Draft, hold, or kill. Published items stay
        here as a record.
      </p>
      {isPending && <p className="mt-4 text-muted">Loading leads…</p>}
      {leads.length === 0 && !isPending && (
        <p className="mt-6 text-muted">
          Queue is empty.{" "}
          <Link to="/desk/scan" className="text-rust hover:text-rust-2">
            Run a scan
          </Link>{" "}
          or send a Dark desk signal here.
        </p>
      )}
      <ul className="mt-6 space-y-4">
        {leads.map((l) => (
          <li key={l.id} className="border border-rule bg-paper p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="text-[11px] tracking-[0.14em] text-muted uppercase">
                {l.topic} · {l.status} · {formatShortDate(l.created_at)}
                {l.newsworthiness != null ? ` · ${l.newsworthiness}/20` : ""}
              </p>
            </div>
            <h2 className="mt-1 font-display text-2xl">
              <Link
                to="/desk/story/$leadId"
                params={{ leadId: String(l.id) }}
                className="hover:text-rust"
              >
                {l.headline}
              </Link>
            </h2>
            <p className="mt-2 text-ink-2">{l.why}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link
                to="/desk/story/$leadId"
                params={{ leadId: String(l.id) }}
                className="inline-flex min-h-11 items-center bg-ink px-4 text-sm text-paper hover:bg-ink-2"
              >
                Open
              </Link>
              {l.article_slug ? (
                <Link
                  to="/articles/$slug"
                  params={{ slug: l.article_slug }}
                  className="inline-flex min-h-11 items-center border border-ink px-4 text-sm hover:bg-paper-2"
                >
                  On the paper
                </Link>
              ) : null}
              {l.status !== "held" && l.status !== "published" && (
                <InkButton
                  tone="ghost"
                  onClick={() => setStatus.mutate({ id: l.id, status: "held" })}
                >
                  Hold
                </InkButton>
              )}
              {l.status !== "killed" && l.status !== "published" && (
                <InkButton
                  tone="danger"
                  onClick={() => setStatus.mutate({ id: l.id, status: "killed" })}
                >
                  Kill
                </InkButton>
              )}
            </div>
          </li>
        ))}
      </ul>
    </DeskShell>
  );
}
