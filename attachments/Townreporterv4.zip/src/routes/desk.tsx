import { createFileRoute, Outlet } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/desk")({
  component: DeskGate,
});

function DeskGate() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <div className="grid min-h-dvh place-items-center bg-desk px-6 text-ink">
        <p className="font-display text-2xl">Checking sign-in…</p>
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return (
    <div className="min-h-dvh bg-desk text-desk-ink">
      <Outlet />
    </div>
  );
}
