import { looksLikeSoft404, type FetchOutcome } from "./fetch-outcome.ts";
import { assertPublicHttpUrl, fetchPublicHttp, fetchSourceText } from "./fetch-url.ts";

export async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  async function worker() {
    while (next < items.length) {
      const i = next++;
      out[i] = await fn(items[i]!, i);
    }
  }
  const n = Math.max(1, Math.min(limit, items.length));
  await Promise.all(Array.from({ length: n }, () => worker()));
  return out;
}

export async function withRetry<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    const msg = err instanceof Error ? err.message : "";
    if (/not fetchable|Invalid URL|Only http/i.test(msg)) throw err;
    await new Promise((r) => setTimeout(r, 400));
    return fn();
  }
}

function decodePdfString(raw: string): string {
  return raw
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\r")
    .replace(/\\t/g, "\t")
    .replace(/\\\(/g, "(")
    .replace(/\\\)/g, ")")
    .replace(/\\\\/g, "\\")
    .replace(/\\(\d{3})/g, (_, oct) => String.fromCharCode(parseInt(oct, 8)));
}

/** Best-effort text from a PDF without a native parser. Civic packets are often uncompressed. */
export function extractPdfText(buf: Uint8Array): string {
  const latin = new TextDecoder("latin1").decode(buf);
  const chunks: string[] = [];
  const tj = /\((?:\\.|[^\\)]){2,}\)(?:\s*Tj|\s*TJ)/g;
  let m: RegExpExecArray | null;
  while ((m = tj.exec(latin))) {
    const inner = m[0].slice(1, m[0].lastIndexOf(")"));
    chunks.push(decodePdfString(inner));
  }
  const hex = /<([0-9A-Fa-f]{4,})>\s*Tj/g;
  while ((m = hex.exec(latin))) {
    const hexStr = m[1]!;
    if (hexStr.length % 2) continue;
    const bytes = hexStr.match(/.{2}/g)!.map((h) => parseInt(h, 16));
    if (bytes[0] === 0xfe && bytes[1] === 0xff) {
      const chars: string[] = [];
      for (let i = 2; i + 1 < bytes.length; i += 2) {
        chars.push(String.fromCharCode((bytes[i]! << 8) + bytes[i + 1]!));
      }
      chunks.push(chars.join(""));
    }
  }
  return chunks.join(" ").replace(/\s+/g, " ").trim().slice(0, 14000);
}

export async function extractPdfBetter(
  buf: Uint8Array,
): Promise<{ text: string; method: "unpdf" | "tj-regex" | "none"; needsOcr: boolean }> {
  try {
    const { extractText } = await import("unpdf");
    const result = await extractText(buf, { mergePages: true });
    const text = String(result.text ?? "")
      .replace(/\s+/g, " ")
      .trim();
    if (text.length >= 40) {
      return { text: text.slice(0, 40000), method: "unpdf", needsOcr: false };
    }
  } catch {
    /* fall through to regex */
  }
  const fallback = extractPdfText(buf);
  if (fallback.length >= 40) {
    return { text: fallback, method: "tj-regex", needsOcr: false };
  }
  return { text: fallback, method: "none", needsOcr: true };
}

export function parseRssItems(xml: string): { title: string; link: string; summary: string }[] {
  const items: { title: string; link: string; summary: string }[] = [];
  const blocks = xml.split(/<item[\s>]/i).slice(1);
  const entries = blocks.length ? blocks : xml.split(/<entry[\s>]/i).slice(1);
  for (const block of entries.slice(0, 8)) {
    const title = (block.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? "")
      .replace(/<!\[CDATA\[|\]\]>/g, "")
      .replace(/<[^>]+>/g, "")
      .trim();
    const link =
      block.match(/<link[^>]*href=["']([^"']+)["']/i)?.[1] ??
      block.match(/<link[^>]*>([\s\S]*?)<\/link>/i)?.[1]?.trim() ??
      "";
    const summary = (block.match(/<(?:description|summary|content)[^>]*>([\s\S]*?)<\/(?:description|summary|content)>/i)?.[1] ?? "")
      .replace(/<!\[CDATA\[|\]\]>/g, "")
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 800);
    if (title || link) items.push({ title, link, summary });
  }
  return items;
}

const DOC_HREF =
  /\.pdf(?:$|[?#])|agenda|minutes|packet|staff.?report|ordinance|resolution|budget|attachment/i;

export function discoverDocLinks(html: string, base: URL): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  const re = /href\s*=\s*["']([^"']+)["']/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    let href = m[1]!;
    if (href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("javascript:")) continue;
    try {
      const abs = new URL(href, base);
      if (abs.protocol !== "http:" && abs.protocol !== "https:") continue;
      if (!DOC_HREF.test(abs.pathname + abs.search) && !abs.pathname.toLowerCase().endsWith(".pdf")) continue;
      const key = abs.toString();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(key);
    } catch {
      /* skip */
    }
    if (out.length >= 10) break;
  }
  return out;
}

function youtubeChannelId(html: string): string | null {
  return (
    html.match(/"channelId":"(UC[\w-]+)"/)?.[1] ??
    html.match(/https:\/\/www\.youtube\.com\/channel\/(UC[\w-]+)/)?.[1] ??
    null
  );
}

function youtubeVideoIdsFromRss(xml: string): string[] {
  const ids: string[] = [];
  const re = /<yt:videoId>([\w-]+)<\/yt:videoId>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    if (!ids.includes(m[1]!)) ids.push(m[1]!);
    if (ids.length >= 3) break;
  }
  if (ids.length === 0) {
    const alt = /watch\?v=([\w-]{6,})/g;
    while ((m = alt.exec(xml))) {
      if (!ids.includes(m[1]!)) ids.push(m[1]!);
      if (ids.length >= 3) break;
    }
  }
  return ids;
}

export type IngestResult = { text: string; titleHint: string; extras: string[] };

export type IngestDocument = {
  ok: boolean;
  status: number;
  outcome: FetchOutcome;
  text: string;
  title: string;
  extras: string[];
  contentType: string;
  needsOcr: boolean;
};

export async function ingestDocument(raw: string): Promise<IngestDocument> {
  try {
    const url = await assertPublicHttpUrl(raw);
    const res = await fetchPublicHttp(url);
    const status = res.status;
    const ctype = (res.headers.get("content-type") ?? "").toLowerCase();
    const buf = new Uint8Array(await res.arrayBuffer());
    const path = url.pathname.toLowerCase();

    if (!res.ok) {
      const title = url.hostname;
      let text = "";
      try {
        text = new TextDecoder("utf-8", { fatal: false }).decode(buf).slice(0, 4000);
      } catch {
        text = "";
      }
      const outcome: FetchOutcome =
        status === 404 || status === 410 ? "not-found" : "fetch-failed";
      return {
        ok: false,
        status,
        outcome,
        text,
        title,
        extras: [],
        contentType: ctype,
        needsOcr: false,
      };
    }

    if (ctype.includes("pdf") || path.endsWith(".pdf")) {
      const pdf = await extractPdfBetter(buf);
      if (pdf.needsOcr) {
        return {
          ok: false,
          status,
          outcome: "needs-ocr",
          text: pdf.text,
          title: url.pathname.split("/").pop() ?? "pdf",
          extras: [],
          contentType: "application/pdf",
          needsOcr: true,
        };
      }
      return {
        ok: true,
        status,
        outcome: "fetched",
        text: `PDF ${url.toString()}\n\n${pdf.text}`,
        title: url.pathname.split("/").pop() ?? "pdf",
        extras: [],
        contentType: "application/pdf",
        needsOcr: false,
      };
    }

    const body = new TextDecoder("utf-8", { fatal: false }).decode(buf);
    const titleMatch = body.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const title = titleMatch
      ? titleMatch[1]!.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim().slice(0, 140)
      : url.hostname;
    const text = body
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 14000);
    if (looksLikeSoft404(title, text)) {
      return {
        ok: false,
        status,
        outcome: "soft-404",
        text,
        title,
        extras: [],
        contentType: ctype,
        needsOcr: false,
      };
    }
    const extras = discoverDocLinks(body, url);
    return {
      ok: text.length >= 40,
      status,
      outcome: text.length >= 40 ? "fetched" : "parse-failed",
      text,
      title,
      extras,
      contentType: ctype || "text/html",
      needsOcr: false,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "fetch failed";
    const timeout = /timeout|aborted/i.test(msg);
    return {
      ok: false,
      status: 0,
      outcome: "fetch-failed",
      text: timeout ? "timeout" : msg,
      title: "",
      extras: [],
      contentType: "",
      needsOcr: false,
    };
  }
}

async function ingestYoutubeChannel(url: URL): Promise<IngestResult> {
  const page = await fetchPublicHttp(url);
  const html = await page.text();
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const titleHint = titleMatch
    ? titleMatch[1]!.replace(/<[^>]+>/g, "").trim().slice(0, 140)
    : url.hostname;
  const channelId = youtubeChannelId(html);
  const parts = [
    `YouTube channel ${url.toString()}. Listing only — captions are pulled from recent watch URLs.`,
  ];
  if (channelId) {
    const rssUrl = new URL(
      `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`,
    );
    const rssRes = await fetchPublicHttp(rssUrl);
    const xml = await rssRes.text();
    const ids = youtubeVideoIdsFromRss(xml);
    parts.push(`Recent videos: ${ids.join(", ") || "(none parsed)"}`);
    for (const id of ids) {
      try {
        const cap = await fetchSourceText(`https://www.youtube.com/watch?v=${id}`);
        parts.push(`--- video ${id} ---\n${cap.text.slice(0, 2500)}`);
      } catch {
        parts.push(`--- video ${id} --- (no captions)`);
      }
    }
  } else {
    parts.push(html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 4000));
  }
  return { text: parts.join("\n\n").slice(0, 14000), titleHint, extras: [] };
}

export async function ingestUrl(raw: string): Promise<IngestResult> {
  const url = await assertPublicHttpUrl(raw);
  const host = url.hostname.replace(/^www\./, "");
  const path = url.pathname.toLowerCase();
  if (
    (host === "youtube.com" || host === "m.youtube.com") &&
    (path.startsWith("/@") ||
      path.startsWith("/channel/") ||
      path.startsWith("/c/") ||
      path.startsWith("/user/") ||
      path.endsWith("/videos") ||
      path.endsWith("/streams"))
  ) {
    return ingestYoutubeChannel(url);
  }

  const res = await fetchPublicHttp(url);
  if (!res.ok) throw new Error(`Fetch failed (${res.status})`);
  const ctype = (res.headers.get("content-type") ?? "").toLowerCase();
  const buf = new Uint8Array(await res.arrayBuffer());

  if (ctype.includes("pdf") || path.endsWith(".pdf")) {
    const text = extractPdfText(buf);
    if (text.length < 40) throw new Error("PDF had no extractable text");
    return { text: `PDF ${url.toString()}\n\n${text}`, titleHint: url.pathname.split("/").pop() ?? "pdf", extras: [] };
  }

  const body = new TextDecoder("utf-8", { fatal: false }).decode(buf);
  if (
    ctype.includes("xml") ||
    ctype.includes("rss") ||
    ctype.includes("atom") ||
    /\/(rss|atom|feed)(\.xml)?$/i.test(path)
  ) {
    const items = parseRssItems(body);
    const text = items
      .map((it) => `${it.title}\n${it.link}\n${it.summary}`)
      .join("\n\n")
      .slice(0, 14000);
    if (text.length < 40) throw new Error("Feed had almost no readable text");
    return { text: `RSS ${url.toString()}\n\n${text}`, titleHint: url.hostname, extras: [] };
  }

  const titleMatch = body.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const titleHint = titleMatch
    ? titleMatch[1]!.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim().slice(0, 140)
    : url.hostname;
  const text = body
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 14000);
  if (text.length < 40) throw new Error("Page had almost no readable text");
  const extras = discoverDocLinks(body, url);
  const alt = body.match(/rel=["']alternate["'][^>]*type=["']application\/(rss|atom)\+xml["'][^>]*href=["']([^"']+)/i);
  if (alt?.[2]) {
    try {
      extras.unshift(new URL(alt[2], url).toString());
    } catch {
      /* skip */
    }
  }
  return { text, titleHint, extras };
}
