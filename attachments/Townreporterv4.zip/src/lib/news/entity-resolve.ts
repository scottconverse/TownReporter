export type EntityVerdict = "same" | "possible" | "different" | "unresolved";

export function normalizeEntity(name: string): string {
  return name
    .trim()
    .toLowerCase()
    .replace(/[.,]/g, "")
    .replace(/\s+/g, " ")
    .replace(/\b(llc|l\.l\.c\.|inc|corp|corporation|ltd|the)\b/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 160);
}

export function resolveEntityName(
  name: string,
  known: { canonical: string; name: string }[],
): { verdict: EntityVerdict; canonical: string; matched?: string } {
  const n = normalizeEntity(name);
  if (!n) return { verdict: "unresolved", canonical: n };
  for (const k of known) {
    if (k.canonical === n) return { verdict: "same", canonical: k.canonical, matched: k.name };
    const a = new Set(n.split(" ").filter((w) => w.length > 1));
    const b = new Set(k.canonical.split(" ").filter((w) => w.length > 1));
    const inter = [...a].filter((w) => b.has(w));
    if (inter.length >= 2) {
      return { verdict: "possible", canonical: k.canonical, matched: k.name };
    }
    if (n.includes(k.canonical) || k.canonical.includes(n)) {
      if (Math.min(n.length, k.canonical.length) >= 6) {
        return { verdict: "possible", canonical: k.canonical, matched: k.name };
      }
    }
  }
  return { verdict: "unresolved", canonical: n };
}
