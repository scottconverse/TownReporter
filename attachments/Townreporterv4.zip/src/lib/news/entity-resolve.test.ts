import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { normalizeEntity, resolveEntityName } from "./entity-resolve.ts";

describe("normalizeEntity", () => {
  it("strips LLC/Inc noise without inventing identity", () => {
    assert.equal(normalizeEntity("Peak Range Holdings LLC"), "peak range holdings");
    assert.equal(normalizeEntity("The Peak Range Holdings, Inc."), "peak range holdings");
  });
});

describe("resolveEntityName", () => {
  const known = [
    { canonical: "jane smith", name: "Jane Smith" },
    { canonical: "peak range holdings", name: "Peak Range Holdings LLC" },
  ];

  it("matches an exact canonical as same", () => {
    const r = resolveEntityName("Jane Smith", known);
    assert.equal(r.verdict, "same");
    assert.equal(r.canonical, "jane smith");
  });

  it("does not auto-merge a possible person overlap", () => {
    const r = resolveEntityName("Jane A. Smith", known);
    assert.equal(r.verdict, "possible");
    assert.equal(r.matched, "Jane Smith");
  });

  it("leaves an unrelated name unresolved", () => {
    const r = resolveEntityName("Front Range Municipal Solutions LLC", known);
    assert.equal(r.verdict, "unresolved");
    assert.match(r.canonical, /front range municipal solutions/);
  });
});
