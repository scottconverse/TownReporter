import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  classifyClaimKind,
  detectMissingCadence,
  diffExcerpt,
  extractReferences,
  queriesForRef,
} from "./extract.ts";

describe("extractReferences", () => {
  it("pulls companies, contracts, RFPs, URLs, and 'pursuant to' phrases", () => {
    const text = `
      Staff recommends award to Front Range Municipal Solutions LLC
      under contract #C-2024-118 pursuant to agreement dated March 3, 2023.
      See attachment https://www.longmontcolorado.gov/rfp/FRMS-09.pdf
      RFP 2024-09. Parcel 1313200001. Ordinance 2024-15.
    `;
    const refs = extractReferences(text);
    const kinds = new Set(refs.map((r) => r.kind));
    assert.ok(refs.some((r) => /Front Range Municipal Solutions LLC/i.test(r.value)));
    assert.ok(kinds.has("contract"));
    assert.ok(kinds.has("rfp"));
    assert.ok(kinds.has("url"));
    assert.ok(kinds.has("parcel"));
    assert.ok(kinds.has("legislation"));
    assert.ok(kinds.has("reference"));
  });
});

describe("queriesForRef", () => {
  it("turns a company into agent and contribution searches", () => {
    const qs = queriesForRef({ kind: "company", value: "Front Range Municipal Solutions LLC" });
    assert.ok(qs.some((q) => /registered agent/i.test(q)));
    assert.ok(qs.some((q) => /campaign contribution/i.test(q)));
  });
});

describe("detectMissingCadence", () => {
  it("flags a monthly report that did not appear", () => {
    const last = new Date("2026-06-01T00:00:00Z");
    const now = new Date("2026-08-20T00:00:00Z");
    const missing = detectMissingCadence(
      [
        {
          key: "water-quality",
          at: last,
          title: "Water Quality Report",
          url: "https://www.longmontcolorado.gov/water",
        },
      ],
      now,
      30,
      7,
    );
    assert.equal(missing.length, 1);
    assert.ok(missing[0]!.daysLate > 20);
  });
});

describe("diffExcerpt", () => {
  it("describes added and removed wording", () => {
    const d = diffExcerpt("staff recommended denial of the annexation", "staff recommended approval of the annexation");
    assert.match(d, /Removed:.*denial/i);
    assert.match(d, /Added:.*approval/i);
  });
});

describe("classifyClaimKind", () => {
  it("keeps FACT and defaults unknown", () => {
    assert.equal(classifyClaimKind("fact"), "FACT");
    assert.equal(classifyClaimKind("maybe"), "UNKNOWN");
  });
});
