import { getSql } from "../db.ts";
import { grokChat, parseJsonBlock } from "./ai.ts";
import { DARK_PLANNER } from "./dark-prompt.ts";
import {
  classifyClaimKind,
  detectMissingCadence,
  diffExcerpt,
  extractReferences,
  heuristicPlan as heuristicFromText,
  queriesForRef,
  type ExtractedRef,
} from "./extract.ts";
import { sha256 } from "./fetch-url.ts";
import { classifyFetchedPage, canonicalPublicUrl, type FetchOutcome } from "./fetch-outcome.ts";
import { ingestDocument } from "./ingest.ts";
import { searchWithFallback, waybackCopies, type SearchAttempt, type WebHit } from "./search-web.ts";
import { resolveEntityName } from "./entity-resolve.ts";
import { sanitizePublicUrls } from "./schema.ts";

export const HOPS_PER_RUN = 5;
export const SEARCHES_PER_HOP = 3;
export const FETCHES_PER_HOP = 4;

export type HopPlan = {
  searches: string[];
  fetch_urls: string[];
  entities: { name: string; kind: string; why: string }[];
  relationships: { from: string; to: string; kind: string; evidence: string }[];
  hypotheses: { text: string; supporting: string; contradicting: string }[];
  claims: { text: string; kind: string; evidence: string; source_url?: string; confidence?: number }[];
  frontier: { label: string; kind: string; why: string; priority: number; queries?: string[] }[];
  anomalies: { kind: string; summary: string; url?: string }[];
  dead_ends: { hypothesis: string; reason: string }[];
  questions: string[];
  stop: boolean;
  summary: string;
};

export type SearchFn = (query: string) => Promise<WebHit[]>;
export type FetchFn = (url: string) => Promise<{
  ok: boolean;
  status: number;
  text: string;
  title: string;
  extras: string[];
  outcome?: string;
}>;
export type SearchAttemptFn = (query: string) => Promise<SearchAttempt>;
export type PlannerFn = (pack: string) => Promise<HopPlan>;

const SCHEMA_SQL = `
alter table snapshots add column if not exists url text;
alter table snapshots add column if not exists fetch_status integer;
alter table leads add column if not exists investigation_id integer;
create table if not exists investigations (
  id serial primary key,
  user_id text not null,
  title text not null,
  status text not null default 'open',
  summary text not null default '',
  hops integer not null default 0,
  budget integer not null default 5,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists frontier_items (
  id serial primary key,
  user_id text not null,
  investigation_id integer not null,
  kind text not null,
  label text not null,
  why text not null default '',
  evidence text not null default '',
  priority integer not null default 5,
  queries_tried text not null default '[]',
  next_steps text not null default '',
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create table if not exists artifacts (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  url text not null,
  referrer_url text,
  query text,
  title text not null default '',
  content_type text not null default 'html',
  content_hash text not null,
  full_text text not null default '',
  classification text not null default 'discovered',
  fetch_status integer,
  created_at timestamptz not null default now()
);
create table if not exists entities (
  id serial primary key,
  user_id text not null,
  canonical text not null,
  name text not null,
  kind text not null,
  why text not null default '',
  unique (user_id, canonical)
);
create table if not exists relationships (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  from_name text not null,
  to_name text not null,
  kind text not null,
  evidence text not null default '',
  source_url text,
  created_at timestamptz not null default now()
);
create table if not exists claims (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  body text not null,
  kind text not null,
  evidence text not null default '',
  source_url text,
  confidence numeric,
  created_at timestamptz not null default now()
);
create table if not exists hypotheses (
  id serial primary key,
  user_id text not null,
  investigation_id integer not null,
  body text not null,
  supporting text not null default '',
  contradicting text not null default '',
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create table if not exists anomalies (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  kind text not null,
  summary text not null,
  url text,
  details text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists dead_ends (
  id serial primary key,
  user_id text not null,
  investigation_id integer,
  hypothesis text not null,
  why_interesting text not null default '',
  searches text not null default '',
  entities text not null default '',
  dismissed_because text not null default '',
  unresolved text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists search_log (
  id serial primary key,
  user_id text not null,
  investigation_id integer not null,
  hop integer not null,
  query text not null,
  results_json text not null default '[]',
  created_at timestamptz not null default now()
);
create table if not exists recurring_baselines (
  id serial primary key,
  user_id text not null,
  key text not null,
  kind text not null,
  cadence_days integer not null default 30,
  last_seen timestamptz,
  typical_title text not null default '',
  typical_url text not null default '',
  unique (user_id, key)
);
create table if not exists artifact_versions (
  id serial primary key,
  user_id text not null,
  url text not null,
  content_hash text not null,
  title text not null default '',
  full_text text not null default '',
  fetch_status integer,
  fetch_outcome text not null default 'fetched',
  content_type text not null default 'html',
  captured_at timestamptz not null default now(),
  unique (user_id, url, content_hash)
);
create table if not exists entity_aliases (
  id serial primary key,
  user_id text not null,
  canonical text not null,
  alias text not null,
  verdict text not null default 'unresolved',
  evidence text not null default '',
  unique (user_id, canonical, alias)
);
alter table artifacts add column if not exists version_id integer;
alter table artifacts add column if not exists fetch_outcome text;
alter table claims add column if not exists version_id integer;
alter table claims add column if not exists excerpt text;
alter table claims add column if not exists capture_hash text;
alter table relationships add column if not exists version_id integer;
alter table relationships add column if not exists excerpt text;
alter table frontier_items add column if not exists closed_reason text;
alter table hypotheses add column if not exists transition_note text;
alter table search_log add column if not exists provider text;
alter table search_log add column if not exists state text;
alter table search_log add column if not exists caused_by text;
alter table recurring_baselines add column if not exists sightings integer;
alter table recurring_baselines add column if not exists usual_weekday text;
`;

export async function ensureInvestigateSchema() {
  const sql = await getSql();
  for (const stmt of SCHEMA_SQL.split(";").map((s) => s.trim()).filter(Boolean)) {
    try {
      await sql.query(stmt);
    } catch {
      /* already exists / older PGLite */
    }
  }
}

function canonical(name: string) {
  return name.trim().toLowerCase().replace(/\s+/g, " ").slice(0, 160);
}

export function emptyPlan(): HopPlan {
  return {
    searches: [],
    fetch_urls: [],
    entities: [],
    relationships: [],
    hypotheses: [],
    claims: [],
    frontier: [],
    anomalies: [],
    dead_ends: [],
    questions: [],
    stop: false,
    summary: "",
  };
}

export function heuristicPlan(text: string, tried: Set<string>): HopPlan {
  const h = heuristicFromText(text, tried, SEARCHES_PER_HOP, FETCHES_PER_HOP);
  const plan = emptyPlan();
  plan.searches = h.searches;
  plan.fetch_urls = sanitizePublicUrls(h.fetch_urls);
  plan.frontier = h.frontier;
  plan.summary = h.summary;
  return plan;
}

function parsePlan(raw: unknown): HopPlan {
  const plan = emptyPlan();
  if (!raw || typeof raw !== "object") return plan;
  const o = raw as Record<string, unknown>;
  plan.searches = Array.isArray(o.searches) ? o.searches.map(String).slice(0, 8) : [];
  plan.fetch_urls = sanitizePublicUrls(o.fetch_urls).slice(0, 10);
  plan.stop = Boolean(o.stop);
  plan.summary = String(o.summary ?? "").slice(0, 2000);
  plan.questions = Array.isArray(o.questions) ? o.questions.map(String).slice(0, 12) : [];
  const arr = <T>(key: string) => (Array.isArray(o[key]) ? (o[key] as T[]) : []);
  for (const e of arr<Record<string, unknown>>("entities")) {
    if (e?.name) plan.entities.push({ name: String(e.name), kind: String(e.kind ?? "unknown"), why: String(e.why ?? "") });
  }
  for (const r of arr<Record<string, unknown>>("relationships")) {
    if (r?.from && r?.to) {
      plan.relationships.push({
        from: String(r.from),
        to: String(r.to),
        kind: String(r.kind ?? "related"),
        evidence: String(r.evidence ?? ""),
      });
    }
  }
  for (const h of arr<Record<string, unknown>>("hypotheses")) {
    if (h?.text) {
      plan.hypotheses.push({
        text: String(h.text),
        supporting: String(h.supporting ?? ""),
        contradicting: String(h.contradicting ?? ""),
      });
    }
  }
  for (const c of arr<Record<string, unknown>>("claims")) {
    if (c?.text) {
      plan.claims.push({
        text: String(c.text),
        kind: classifyClaimKind(String(c.kind ?? "UNKNOWN")),
        evidence: String(c.evidence ?? ""),
        source_url: c.source_url ? String(c.source_url) : undefined,
        confidence: typeof c.confidence === "number" ? c.confidence : undefined,
      });
    }
  }
  for (const f of arr<Record<string, unknown>>("frontier")) {
    if (f?.label) {
      plan.frontier.push({
        label: String(f.label),
        kind: String(f.kind ?? "unknown"),
        why: String(f.why ?? ""),
        priority: Number(f.priority) || 5,
        queries: Array.isArray(f.queries) ? f.queries.map(String) : [],
      });
    }
  }
  for (const a of arr<Record<string, unknown>>("anomalies")) {
    if (a?.summary) {
      plan.anomalies.push({
        kind: String(a.kind ?? "anomaly"),
        summary: String(a.summary),
        url: a.url ? String(a.url) : undefined,
      });
    }
  }
  for (const d of arr<Record<string, unknown>>("dead_ends")) {
    if (d?.hypothesis) {
      plan.dead_ends.push({ hypothesis: String(d.hypothesis), reason: String(d.reason ?? "") });
    }
  }
  return plan;
}

export async function grokPlanner(pack: string): Promise<HopPlan> {
  const ai = await grokChat(DARK_PLANNER, pack.slice(0, 24000), 2200);
  if (!ai.ok) return heuristicPlan(pack, new Set());
  return parsePlan(parseJsonBlock<unknown>(ai.text));
}

async function defaultFetch(url: string): Promise<{
  ok: boolean;
  status: number;
  text: string;
  title: string;
  extras: string[];
  outcome?: string;
}> {
  const doc = await ingestDocument(url);
  return {
    ok: doc.ok,
    status: doc.status,
    text: doc.text,
    title: doc.title,
    extras: doc.extras,
    outcome: doc.outcome,
  };
}

export async function seedInvestigation(
  userId: string,
  investigationId: number,
  paste: string,
  snapshotBits: { title: string; url: string; excerpt: string }[],
) {
  const sql = await getSql();
  if (paste.trim()) {
    const hash = await sha256(paste);
    await sql`
      insert into artifacts (
        user_id, investigation_id, url, title, content_hash, full_text, classification, fetch_status
      ) values (
        ${userId}, ${investigationId}, ${"editor://paste"}, ${"Editor paste"},
        ${hash}, ${paste.slice(0, 40000)}, ${"watch"}, ${200}
      )
    `;
  }
  for (const snap of snapshotBits.slice(0, 20)) {
    const hash = await sha256(snap.excerpt);
    await sql`
      insert into artifacts (
        user_id, investigation_id, url, title, content_hash, full_text, classification, fetch_status
      ) values (
        ${userId}, ${investigationId}, ${snap.url}, ${snap.title},
        ${hash}, ${snap.excerpt.slice(0, 40000)}, ${"watch"}, ${200}
      )
    `;
    const refs = extractReferences(`${snap.title}\n${snap.excerpt}`);
    await addFrontierFromRefs(userId, investigationId, refs, snap.url);
  }
  if (paste.trim()) {
    await addFrontierFromRefs(userId, investigationId, extractReferences(paste), "editor://paste");
  }
}

async function addFrontierFromRefs(
  userId: string,
  investigationId: number,
  refs: ExtractedRef[],
  evidence: string,
) {
  const sql = await getSql();
  for (const ref of refs.slice(0, 30)) {
    const existing = await sql<{ id: number }>`
      select id from frontier_items
      where investigation_id = ${investigationId} and user_id = ${userId}
        and label = ${ref.value} limit 1
    `;
    if (existing[0]) continue;
    await sql`
      insert into frontier_items (
        user_id, investigation_id, kind, label, why, evidence, priority, next_steps
      ) values (
        ${userId}, ${investigationId}, ${ref.kind}, ${ref.value},
        ${"Referenced in evidence"}, ${evidence.slice(0, 400)},
        ${ref.kind === "company" || ref.kind === "url" ? 9 : 6},
        ${queriesForRef(ref).join(" | ").slice(0, 500)}
      )
    `;
  }
}

async function persistDiscovery(
  userId: string,
  investigationId: number,
  item: { kind: string; label: string; why: string; evidence?: string; priority?: number; query?: string },
) {
  const sql = await getSql();
  const label = item.label.slice(0, 240);
  if (!label) return;
  const existing = await sql<{ id: number; queries_tried: string }>`
    select id, queries_tried from frontier_items
    where investigation_id = ${investigationId} and user_id = ${userId} and label = ${label}
    limit 1
  `;
  if (existing[0]) {
    if (item.query) {
      let tried: string[] = [];
      try {
        tried = JSON.parse(existing[0].queries_tried || "[]") as string[];
      } catch {
        tried = [];
      }
      if (!tried.includes(item.query)) {
        tried.push(item.query);
        await sql`
          update frontier_items
          set queries_tried = ${JSON.stringify(tried).slice(0, 4000)}
          where id = ${existing[0].id}
        `;
      }
    }
    return;
  }
  await sql`
    insert into frontier_items (
      user_id, investigation_id, kind, label, why, evidence, priority, next_steps, queries_tried
    ) values (
      ${userId}, ${investigationId}, ${item.kind.slice(0, 40)}, ${label},
      ${item.why.slice(0, 800)}, ${(item.evidence ?? "").slice(0, 400)},
      ${item.priority ?? 7}, ${(item.query ?? "").slice(0, 500)},
      ${JSON.stringify(item.query ? [item.query] : [])}
    )
  `;
}

async function markFrontier(
  userId: string,
  investigationId: number,
  label: string,
  status: string,
  reason: string,
) {
  const sql = await getSql();
  await sql`
    update frontier_items
    set status = ${status}, closed_reason = ${reason.slice(0, 800)}
    where investigation_id = ${investigationId} and user_id = ${userId}
      and label = ${label.slice(0, 240)} and status in ('open', 'investigating')
  `;
}

async function rememberVersion(opts: {
  userId: string;
  investigationId: number;
  url: string;
  title: string;
  text: string;
  hash: string;
  status: number;
  outcome: string;
  classification?: string;
}): Promise<number | null> {
  const sql = await getSql();
  let url = opts.url;
  try {
    url = canonicalPublicUrl(opts.url);
  } catch {
    /* keep raw */
  }
  const existing = await sql<{ id: number }>`
    select id from artifact_versions
    where user_id = ${opts.userId} and url = ${url} and content_hash = ${opts.hash}
    limit 1
  `;
  let versionId = existing[0]?.id ?? null;
  if (!versionId) {
    try {
      const created = await sql<{ id: number }>`
        insert into artifact_versions (
          user_id, url, content_hash, title, full_text, fetch_status, fetch_outcome
        ) values (
          ${opts.userId}, ${url}, ${opts.hash}, ${opts.title.slice(0, 200)},
          ${opts.text.slice(0, 40000)}, ${opts.status}, ${opts.outcome}
        )
        on conflict (user_id, url, content_hash) do update set title = excluded.title
        returning id
      `;
      versionId = created[0]?.id ?? null;
    } catch {
      const again = await sql<{ id: number }>`
        select id from artifact_versions
        where user_id = ${opts.userId} and url = ${url} and content_hash = ${opts.hash}
        limit 1
      `;
      versionId = again[0]?.id ?? null;
      if (!versionId) {
        const created = await sql<{ id: number }>`
          insert into artifact_versions (
            user_id, url, content_hash, title, full_text, fetch_status, fetch_outcome
          ) values (
            ${opts.userId}, ${url}, ${opts.hash}, ${opts.title.slice(0, 200)},
            ${opts.text.slice(0, 40000)}, ${opts.status}, ${opts.outcome}
          )
          returning id
        `;
        versionId = created[0]?.id ?? null;
      }
    }
  }
  await sql`
    insert into artifacts (
      user_id, investigation_id, url, title, content_hash, full_text,
      classification, fetch_status, fetch_outcome, version_id
    ) values (
      ${opts.userId}, ${opts.investigationId}, ${url}, ${opts.title.slice(0, 200)},
      ${opts.hash}, ${opts.text.slice(0, 40000)}, ${opts.classification ?? "discovered"},
      ${opts.status}, ${opts.outcome}, ${versionId}
    )
  `;
  return versionId;
}

function baselineSpec(url: string, title: string): { key: string; kind: string } | null {
  const blob = `${url} ${title}`.toLowerCase();
  let kind = "";
  if (/agenda|minutes|city.?council|board.?meeting/.test(blob)) kind = "meeting";
  else if (/(water|utility|wastewater|drinking).{0,40}(report|quality)/.test(blob)) kind = "report";
  else if (/budget|cafr|financial.?report/.test(blob)) kind = "report";
  else if (/staff.?report|packet/.test(blob)) kind = "packet";
  else return null;
  let path = url;
  try {
    const u = new URL(url);
    path = u.origin + u.pathname;
  } catch {
    /* keep */
  }
  const key = `${kind}:${path.replace(/\/\d{4}([/-]\d{1,2}){0,2}/g, "").replace(/\/\d{4,8}\b/g, "").slice(0, 200)}`;
  return { key, kind };
}

export async function observeBaseline(userId: string, url: string, title: string, at?: Date) {
  const spec = baselineSpec(url, title);
  if (!spec) return;
  const sql = await getSql();
  const prev = await sql<{ last_seen: string | null; sightings: number | null; cadence_days: number }>`
    select last_seen::text as last_seen, sightings, cadence_days
    from recurring_baselines where user_id = ${userId} and key = ${spec.key} limit 1
  `;
  const now = at ?? new Date();
  let cadence = prev[0]?.cadence_days ?? 30;
  const sightings = (prev[0]?.sightings ?? 0) + 1;
  if (prev[0]?.last_seen) {
    const gap = (now.getTime() - new Date(prev[0].last_seen).getTime()) / 86400000;
    if (gap > 3 && gap < 400) {
      cadence = Math.round(((prev[0].cadence_days || 30) + gap) / 2);
    }
  }
  const weekday = now.toLocaleDateString("en-US", { weekday: "long" });
  const seen = now.toISOString();
  if (prev[0]) {
    await sql`
      update recurring_baselines
      set last_seen = ${seen}::timestamptz, typical_title = ${title.slice(0, 200)}, typical_url = ${url.slice(0, 500)},
          cadence_days = ${cadence}, sightings = ${sightings}, usual_weekday = ${weekday}
      where user_id = ${userId} and key = ${spec.key}
    `;
  } else {
    await sql`
      insert into recurring_baselines (
        user_id, key, kind, cadence_days, last_seen, typical_title, typical_url, sightings, usual_weekday
      ) values (
        ${userId}, ${spec.key}, ${spec.kind}, ${cadence}, ${seen}::timestamptz,
        ${title.slice(0, 200)}, ${url.slice(0, 500)}, ${1}, ${weekday}
      )
      on conflict (user_id, key) do update set last_seen = excluded.last_seen, sightings = recurring_baselines.sightings + 1
    `;
  }
}

async function retrievePack(
  userId: string,
  investigationId: number,
  terms: string[],
): Promise<string> {
  const sql = await getSql();
  const seeds = await sql<{ url: string; title: string; full_text: string }>`
    select url, title, full_text from artifacts
    where investigation_id = ${investigationId} and user_id = ${userId} and classification = 'watch'
    order by id asc limit 3
  `;
  const recent = await sql<{ url: string; title: string; full_text: string }>`
    select url, title, full_text from artifacts
    where investigation_id = ${investigationId} and user_id = ${userId}
    order by id desc limit 40
  `;
  const lowered = terms.map((t) => t.toLowerCase()).filter((t) => t.length > 3);
  const scored = recent
    .map((a) => {
      const blob = `${a.title} ${a.url} ${a.full_text}`.toLowerCase();
      const score = lowered.reduce((s, t) => s + (blob.includes(t) ? 2 : 0), 0);
      return { ...a, score };
    })
    .sort((a, b) => b.score - a.score);
  const picked = [...seeds, ...scored.filter((a) => !seeds.some((s) => s.url === a.url)).slice(0, 8)];
  const frontier = await sql<{ label: string; kind: string; why: string; priority: number; next_steps: string; status: string }>`
    select label, kind, why, priority, next_steps, status from frontier_items
    where investigation_id = ${investigationId} and user_id = ${userId}
    order by priority desc, id asc limit 16
  `;
  const hyps = await sql<{ body: string; status: string; supporting: string; contradicting: string }>`
    select body, status, supporting, contradicting from hypotheses
    where investigation_id = ${investigationId} and user_id = ${userId}
    order by id desc limit 12
  `;
  const ents = await sql<{ name: string; kind: string; why: string }>`
    select name, kind, why from entities where user_id = ${userId} order by id desc limit 20
  `;
  const rels = await sql<{ from_name: string; to_name: string; kind: string; evidence: string }>`
    select from_name, to_name, kind, evidence from relationships
    where investigation_id = ${investigationId} and user_id = ${userId} limit 16
  `;
  const claims = await sql<{ body: string; kind: string; evidence: string }>`
    select body, kind, evidence from claims
    where investigation_id = ${investigationId} and user_id = ${userId} order by id desc limit 12
  `;
  const anoms = await sql<{ kind: string; summary: string }>`
    select kind, summary from anomalies
    where investigation_id = ${investigationId} and user_id = ${userId} order by id desc limit 10
  `;
  const dead = await sql<{ hypothesis: string; dismissed_because: string }>`
    select hypothesis, dismissed_because from dead_ends
    where investigation_id = ${investigationId} and user_id = ${userId} order by id desc limit 8
  `;
  const searches = await sql<{ query: string; state: string | null }>`
    select query, state from search_log
    where investigation_id = ${investigationId} and user_id = ${userId} order by id desc limit 24
  `;
  return [
    `FRONTIER:\n${frontier.map((f) => `${f.status} ${f.priority} ${f.kind}: ${f.label} — ${f.why}`).join("\n") || "(empty)"}`,
    `HYPOTHESES:\n${hyps.map((h) => `[${h.status}] ${h.body} pro:${h.supporting} con:${h.contradicting}`).join("\n") || "(none)"}`,
    `ENTITIES:\n${ents.map((e) => `${e.kind}: ${e.name} — ${e.why}`).join("\n") || "(none)"}`,
    `RELATIONSHIPS:\n${rels.map((r) => `${r.from_name} -[${r.kind}]-> ${r.to_name}`).join("\n") || "(none)"}`,
    `CLAIMS:\n${claims.map((c) => `${c.kind}: ${c.body}`).join("\n") || "(none)"}`,
    `ANOMALIES:\n${anoms.map((a) => `${a.kind}: ${a.summary}`).join("\n") || "(none)"}`,
    `DEAD ENDS:\n${dead.map((d) => `${d.hypothesis} — ${d.dismissed_because}`).join("\n") || "(none)"}`,
    `SEARCHES:\n${searches.map((s) => `${s.state ?? "unknown"} ${s.query}`).join("\n") || "(none)"}`,
    `RELEVANT ARTIFACTS:\n${picked.map((a) => `### ${a.title}\n${a.url}\n${a.full_text.slice(0, 1800)}`).join("\n\n") || "(none)"}`,
  ].join("\n\n");
}

export async function researchLoop(opts: {
  userId: string;
  investigationId: number;
  hops?: number;
  search?: SearchFn;
  searchAttempt?: SearchAttemptFn;
  fetch?: FetchFn;
  planner?: PlannerFn;
  archives?: (url: string) => Promise<string[]>;
}): Promise<{ hops: number; artifacts: number; frontier: number; paused: boolean; summary: string }> {
  const sql = await getSql();
  const hopsBudget = opts.hops ?? HOPS_PER_RUN;
  const fetchDoc = opts.fetch ?? defaultFetch;
  const planner = opts.planner;
  const tried = new Set<string>();
  const priorQueries = await sql<{ query: string }>`
    select query from search_log where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
  `;
  for (const q of priorQueries) tried.add(q.query);

  let hopsDone = 0;
  let lastSummary = "";
  let lastVersionId: number | null = null;
  const fetchedThisRun = new Set<string>();

  function canon(raw: string) {
    try {
      return canonicalPublicUrl(raw);
    } catch {
      return raw;
    }
  }

  async function runSearch(q: string): Promise<SearchAttempt> {
    if (opts.searchAttempt) return opts.searchAttempt(q);
    if (opts.search) {
      try {
        const hits = await opts.search(q);
        return {
          state: hits.length ? "SEARCH_SUCCESS_RESULTS" : "SEARCH_SUCCESS_ZERO_RESULTS",
          hits,
          provider: "injected",
        };
      } catch (err) {
        return {
          state: "SEARCH_FAILED_NETWORK",
          hits: [],
          provider: "injected",
          error: err instanceof Error ? err.message : "search failed",
        };
      }
    }
    return searchWithFallback(q);
  }

  for (let hop = 0; hop < hopsBudget; hop++) {
    const openFrontier = await sql<{ label: string; kind: string; next_steps: string }>`
      select label, kind, next_steps from frontier_items
      where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
        and status in ('open', 'investigating', 'reopened')
      order by priority desc limit 16
    `;
    const terms = openFrontier.map((f) => f.label);
    const graph = await retrievePack(opts.userId, opts.investigationId, terms);
    const pack = [
      `INVESTIGATION ${opts.investigationId}. Hop ${hop + 1}. Longmont, Colorado.`,
      graph,
      `QUERIES ALREADY TRIED:\n${[...tried].slice(-40).join("\n") || "(none)"}`,
      `Generate the NEXT searches and fetches. Follow names, companies, contracts, parcels. Search contradictions. A failed search is not "nothing found." Do not stop after one hop.`,
    ].join("\n\n");

    let plan: HopPlan;
    if (planner) plan = await planner(pack);
    else {
      const grok = await grokPlanner(pack);
      const heur = heuristicPlan(graph, tried);
      plan = grok.searches.length || grok.fetch_urls.length ? grok : heur;
      if (!plan.searches.length && heur.searches.length) plan.searches = heur.searches;
      if (!plan.fetch_urls.length && heur.fetch_urls.length) plan.fetch_urls = heur.fetch_urls;
      plan.frontier = [...plan.frontier, ...heur.frontier];
    }

    lastSummary = plan.summary;

    for (const url of plan.fetch_urls) {
      await persistDiscovery(opts.userId, opts.investigationId, {
        kind: "url",
        label: url,
        why: "Planner fetch target",
        evidence: url,
        priority: 10,
      });
    }
    for (const f of plan.frontier) {
      await persistDiscovery(opts.userId, opts.investigationId, {
        kind: f.kind,
        label: f.label,
        why: f.why,
        priority: f.priority,
        query: (f.queries ?? [])[0],
      });
    }

    const fromFrontier: string[] = [];
    for (const f of openFrontier) {
      for (const q of (f.next_steps || "")
        .split("|")
        .map((s) => s.trim())
        .filter(Boolean)) {
        if (q && !tried.has(q)) fromFrontier.push(q);
      }
    }
    const queries = [...fromFrontier, ...plan.searches]
      .filter((q, i, arr) => q && !tried.has(q) && arr.indexOf(q) === i)
      .slice(0, SEARCHES_PER_HOP);
    const toFetch = new Set<string>(plan.fetch_urls);

    for (const q of queries) {
      tried.add(q);
      const attempt = await runSearch(q);
      await sql`
        insert into search_log (user_id, investigation_id, hop, query, results_json, provider, state, caused_by)
        values (
          ${opts.userId}, ${opts.investigationId}, ${hop + 1}, ${q.slice(0, 300)},
          ${JSON.stringify(attempt.hits).slice(0, 8000)},
          ${attempt.provider}, ${attempt.state}, ${plan.summary.slice(0, 200)}
        )
      `;
      if (attempt.state !== "SEARCH_SUCCESS_RESULTS" && attempt.state !== "SEARCH_SUCCESS_ZERO_RESULTS") {
        await sql`
          insert into anomalies (user_id, investigation_id, kind, summary, details)
          values (
            ${opts.userId}, ${opts.investigationId}, ${"search-failed"},
            ${`Search ${attempt.state} via ${attempt.provider}: ${q.slice(0, 180)}`},
            ${attempt.error ?? attempt.state}
          )
        `;
      }
      for (const hit of attempt.hits.slice(0, 6)) {
        toFetch.add(hit.url);
        await persistDiscovery(opts.userId, opts.investigationId, {
          kind: "url",
          label: hit.url,
          why: `Search hit for ${q}`,
          evidence: hit.title,
          priority: 9,
          query: q,
        });
      }
      for (const f of openFrontier) {
        if (q.toLowerCase().includes(f.label.toLowerCase().slice(0, 24))) {
          await sql`
            update frontier_items set status = 'investigating'
            where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
              and label = ${f.label} and status = 'open'
          `;
          await persistDiscovery(opts.userId, opts.investigationId, {
            kind: f.kind,
            label: f.label,
            why: "query attempted",
            query: q,
          });
          if (attempt.state === "SEARCH_SUCCESS_ZERO_RESULTS") {
            await markFrontier(opts.userId, opts.investigationId, f.label, "exhausted", `Zero results for ${q}`);
          }
        }
      }
    }

    const urls = [...new Set(sanitizePublicUrls([...toFetch]).map(canon).filter((u) => !fetchedThisRun.has(u)))].slice(
      0,
      FETCHES_PER_HOP,
    );
    for (const url of urls) {
      fetchedThisRun.add(url);
      await persistDiscovery(opts.userId, opts.investigationId, {
        kind: "url",
        label: url,
        why: "Queued for fetch",
        evidence: url,
        priority: 10,
      });
      const prior = await sql<{ content_hash: string; full_text: string; fetch_status: number | null }>`
        select content_hash, full_text, fetch_status from artifact_versions
        where user_id = ${opts.userId} and url = ${url}
        order by id desc limit 1
      `;
      const got = await fetchDoc(url);
      const hash = got.ok ? await sha256(got.text) : "missing";
      const classified = classifyFetchedPage({
        status: got.status,
        title: got.title,
        text: got.text,
        priorHash: prior[0]?.content_hash,
        priorStatus: prior[0]?.fetch_status,
        newHash: hash,
      });
      const outcome: FetchOutcome = got.outcome === "needs-ocr" ? "needs-ocr" : classified;
      const versionId = await rememberVersion({
        userId: opts.userId,
        investigationId: opts.investigationId,
        url,
        title: got.title || url,
        text: got.text,
        hash,
        status: got.status,
        outcome,
      });
      lastVersionId = versionId ?? lastVersionId;

      if (outcome === "unchanged") {
        await markFrontier(opts.userId, opts.investigationId, url, "resolved", "Unchanged capture");
        continue;
      }

      if (outcome === "removed" || outcome === "not-found" || outcome === "soft-404") {
        if (prior[0] && prior[0].fetch_status === 200) {
          await sql`
            insert into anomalies (user_id, investigation_id, kind, summary, url, details)
            values (
              ${opts.userId}, ${opts.investigationId}, ${"disappeared"},
              ${`Previously captured document is gone: ${url}`},
              ${url},
              ${`Prior hash ${prior[0].content_hash}. Outcome ${outcome}. Status ${got.status}. Original version retained.`}
            )
          `;
          const follow = [
            `"${url}" (wayback OR archive.org OR relocated OR moved)`,
            `${(got.title || "document").slice(0, 80)} Longmont (replacement OR "no longer" OR cancelled)`,
          ];
          for (const q of follow) {
            await persistDiscovery(opts.userId, opts.investigationId, {
              kind: "missing-record",
              label: q.slice(0, 240),
              why: `Follow-up after ${outcome} of ${url}`,
              evidence: url,
              priority: 12,
              query: q,
            });
          }
          try {
            const copies = opts.archives ? await opts.archives(url) : await waybackCopies(url);
            for (const c of copies.slice(0, 3)) {
              toFetch.add(c);
              await persistDiscovery(opts.userId, opts.investigationId, {
                kind: "url",
                label: c,
                why: `Archive copy after disappearance of ${url}`,
                evidence: url,
                priority: 12,
              });
            }
          } catch {
            /* archive optional */
          }
        }
        await markFrontier(opts.userId, opts.investigationId, url, "exhausted", outcome);
        continue;
      }

      if (!got.ok) {
        await markFrontier(opts.userId, opts.investigationId, url, "deferred", `Fetch ${outcome}`);
        continue;
      }

      if (outcome === "changed" && prior[0]?.full_text) {
        const delta = diffExcerpt(prior[0].full_text, got.text);
        if (delta) {
          await sql`
            insert into anomalies (user_id, investigation_id, kind, summary, url, details)
            values (
              ${opts.userId}, ${opts.investigationId}, ${"changed"},
              ${`Document changed: ${url}`}, ${url}, ${delta.slice(0, 4000)}
            )
          `;
        }
      }

      await observeBaseline(opts.userId, url, got.title);
      await markFrontier(opts.userId, opts.investigationId, url, "resolved", "Fetched");
      for (const extra of got.extras.slice(0, 6)) {
        toFetch.add(extra);
        await persistDiscovery(opts.userId, opts.investigationId, {
          kind: "url",
          label: extra,
          why: `Attachment/document link on ${url}`,
          evidence: url,
          priority: 11,
        });
      }
      await addFrontierFromRefs(
        opts.userId,
        opts.investigationId,
        extractReferences(got.text),
        url,
      );
    }

    for (const extra of sanitizePublicUrls([...toFetch])) {
      const leftover = canon(extra);
      if (fetchedThisRun.has(leftover)) continue;
      await persistDiscovery(opts.userId, opts.investigationId, {
        kind: "url",
        label: leftover,
        why: "Discovered this hop — fetch next",
        evidence: leftover,
        priority: 10,
      });
    }

    await persistPlan(opts.userId, opts.investigationId, plan, lastVersionId);

    hopsDone += 1;
    await sql`
      update investigations
      set hops = hops + 1, summary = ${lastSummary.slice(0, 2500)}, updated_at = now()
      where id = ${opts.investigationId} and user_id = ${opts.userId}
    `;

    const open = await sql<{ c: number }>`
      select count(*)::int as c from frontier_items
      where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
        and status in ('open', 'investigating', 'reopened')
    `;
    if (plan.stop && (open[0]?.c ?? 0) === 0) break;
  }

  const open = await sql<{ c: number }>`
    select count(*)::int as c from frontier_items
    where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
      and status in ('open', 'investigating', 'reopened')
  `;
  const artsN = await sql<{ c: number }>`
    select count(*)::int as c from artifacts
    where investigation_id = ${opts.investigationId} and user_id = ${opts.userId}
  `;
  const paused = (open[0]?.c ?? 0) > 0;
  await sql`
    update investigations
    set status = ${paused ? "paused" : "open"}, updated_at = now()
    where id = ${opts.investigationId} and user_id = ${opts.userId}
  `;
  return {
    hops: hopsDone,
    artifacts: artsN[0]?.c ?? 0,
    frontier: open[0]?.c ?? 0,
    paused,
    summary: lastSummary,
  };
}

async function persistPlan(
  userId: string,
  investigationId: number,
  plan: HopPlan,
  versionId: number | null = null,
) {
  const sql = await getSql();
  const known = await sql<{ canonical: string; name: string }>`
    select canonical, name from entities where user_id = ${userId}
  `;
  for (const e of plan.entities) {
    const resolved = resolveEntityName(e.name, known);
    const c = resolved.canonical || canonical(e.name);
    if (!c) continue;
    try {
      await sql`
        insert into entities (user_id, canonical, name, kind, why)
        values (${userId}, ${c}, ${e.name.slice(0, 200)}, ${e.kind.slice(0, 40)}, ${e.why.slice(0, 800)})
        on conflict (user_id, canonical) do update set why = excluded.why
      `;
    } catch {
      try {
        await sql`
          insert into entities (user_id, canonical, name, kind, why)
          values (${userId}, ${c}, ${e.name.slice(0, 200)}, ${e.kind.slice(0, 40)}, ${e.why.slice(0, 800)})
        `;
      } catch {
        await sql`
          update entities set why = ${e.why.slice(0, 800)}
          where user_id = ${userId} and canonical = ${c}
        `;
      }
    }
    if (resolved.verdict !== "same" && resolved.matched) {
      try {
        await sql`
          insert into entity_aliases (user_id, canonical, alias, verdict, evidence)
          values (${userId}, ${resolved.canonical}, ${e.name.slice(0, 200)}, ${resolved.verdict}, ${e.why.slice(0, 400)})
          on conflict (user_id, canonical, alias) do update set verdict = excluded.verdict
        `;
      } catch {
        /* alias already recorded */
      }
    }
    known.push({ canonical: c, name: e.name });
  }
  for (const r of plan.relationships) {
    await sql`
      insert into relationships (user_id, investigation_id, from_name, to_name, kind, evidence, source_url, version_id, excerpt)
      values (
        ${userId}, ${investigationId}, ${r.from.slice(0, 200)}, ${r.to.slice(0, 200)},
        ${r.kind.slice(0, 80)}, ${r.evidence.slice(0, 2000)}, ${null}, ${versionId},
        ${r.evidence.slice(0, 800)}
      )
    `;
  }
  for (const h of plan.hypotheses) {
    const status = h.contradicting.trim()
      ? "weakened"
      : h.supporting.trim()
        ? "strengthened"
        : "active";
    const existing = await sql<{ id: number }>`
      select id from hypotheses
      where investigation_id = ${investigationId} and user_id = ${userId} and body = ${h.text.slice(0, 2000)}
      limit 1
    `;
    if (existing[0]) {
      await sql`
        update hypotheses
        set supporting = ${h.supporting.slice(0, 2000)},
            contradicting = ${h.contradicting.slice(0, 2000)},
            status = ${status},
            transition_note = ${`Evidence update (${status})`}
        where id = ${existing[0].id}
      `;
    } else {
      await sql`
        insert into hypotheses (user_id, investigation_id, body, supporting, contradicting, status, transition_note)
        values (
          ${userId}, ${investigationId}, ${h.text.slice(0, 2000)},
          ${h.supporting.slice(0, 2000)}, ${h.contradicting.slice(0, 2000)},
          ${status}, ${"opened"}
        )
      `;
    }
  }
  for (const c of plan.claims) {
    const conf = c.confidence;
    let claimVersion = versionId;
    let captureHash: string | null = null;
    if (c.source_url) {
      let source = c.source_url;
      try {
        source = canonicalPublicUrl(c.source_url);
      } catch {
        /* keep */
      }
      const found = await sql<{ id: number; content_hash: string }>`
        select id, content_hash from artifact_versions
        where user_id = ${userId} and url = ${source}
        order by id desc limit 1
      `;
      if (found[0]) {
        claimVersion = found[0].id;
        captureHash = found[0].content_hash;
      }
    } else if (versionId) {
      const found = await sql<{ content_hash: string }>`
        select content_hash from artifact_versions where id = ${versionId} limit 1
      `;
      captureHash = found[0]?.content_hash ?? null;
    }
    await sql`
      insert into claims (user_id, investigation_id, body, kind, evidence, source_url, confidence, version_id, excerpt, capture_hash)
      values (
        ${userId}, ${investigationId}, ${c.text.slice(0, 2000)}, ${c.kind},
        ${c.evidence.slice(0, 2000)}, ${c.source_url ?? null}, ${conf ?? null},
        ${claimVersion}, ${c.evidence.slice(0, 800)}, ${captureHash}
      )
    `;
  }
  for (const f of plan.frontier) {
    await persistDiscovery(userId, investigationId, {
      kind: f.kind,
      label: f.label,
      why: f.why,
      priority: f.priority,
      query: (f.queries ?? [])[0],
    });
  }
  for (const a of plan.anomalies) {
    await sql`
      insert into anomalies (user_id, investigation_id, kind, summary, url, details)
      values (
        ${userId}, ${investigationId}, ${a.kind.slice(0, 40)}, ${a.summary.slice(0, 1000)},
        ${a.url ?? null}, ${""}
      )
    `;
  }
  for (const d of plan.dead_ends) {
    await sql`
      insert into dead_ends (user_id, investigation_id, hypothesis, dismissed_because)
      values (${userId}, ${investigationId}, ${d.hypothesis.slice(0, 1000)}, ${d.reason.slice(0, 2000)})
    `;
    await markFrontier(userId, investigationId, d.hypothesis, "dead-end", d.reason);
    await sql`
      update hypotheses
      set status = 'dead-end', transition_note = ${d.reason.slice(0, 800)}
      where investigation_id = ${investigationId} and user_id = ${userId}
        and body = ${d.hypothesis.slice(0, 2000)}
    `;
  }
}

export async function matchDeadEnds(userId: string, names: string[]) {
  const sql = await getSql();
  const rows = await sql<{ id: number; hypothesis: string; dismissed_because: string; entities: string }>`
    select id, hypothesis, dismissed_because, entities from dead_ends
    where user_id = ${userId} order by created_at desc limit 80
  `;
  const lower = names.map((n) => n.toLowerCase());
  return rows.filter((r) => {
    const blob = `${r.hypothesis} ${r.entities}`.toLowerCase();
    return lower.some((n) => n.length > 3 && blob.includes(n));
  });
}

export async function checkBaselines(userId: string, investigationId: number, now = new Date()) {
  const sql = await getSql();
  const rows = await sql<{
    key: string;
    typical_title: string;
    typical_url: string;
    cadence_days: number;
    last_seen: string | null;
    usual_weekday: string | null;
    sightings: number | null;
  }>`
    select key, typical_title, typical_url, cadence_days, last_seen::text as last_seen, usual_weekday, sightings
    from recurring_baselines where user_id = ${userId}
  `;
  let flagged = 0;
  for (const r of rows) {
    if (!r.last_seen) continue;
    const events = [
      {
        key: r.key,
        at: new Date(r.last_seen),
        title: r.typical_title,
        url: r.typical_url,
      },
    ];
    const missing = detectMissingCadence(events, now, r.cadence_days || 30, 7);
    for (const m of missing) {
      const already = await sql<{ id: number }>`
        select id from anomalies
        where user_id = ${userId} and investigation_id = ${investigationId}
          and kind = ${"missing-cadence"} and url is not distinct from ${m.url || null}
        limit 1
      `;
      if (already[0]) {
        flagged += 1;
        continue;
      }
      const details = [
        `Last seen ${m.lastSeen.toISOString()}.`,
        `Learned cadence ${r.cadence_days} days.`,
        r.usual_weekday ? `Usual weekday ${r.usual_weekday}.` : "",
        r.sightings ? `${r.sightings} prior sightings.` : "",
        `Search for cancellation, reschedule, rename, archive.`,
      ]
        .filter(Boolean)
        .join(" ");
      await sql`
        insert into anomalies (user_id, investigation_id, kind, summary, url, details)
        values (
          ${userId}, ${investigationId}, ${"missing-cadence"},
          ${`Expected recurring record is late: ${m.title || m.key} (${m.daysLate} days past cadence)`},
          ${m.url || null},
          ${details}
        )
      `;
      const next = [
        `${m.title} cancellation`,
        `${m.title} rescheduled OR postponed`,
        `${m.title} agenda OR minutes OR notice`,
      ].join(" | ");
      await sql`
        insert into frontier_items (user_id, investigation_id, kind, label, why, priority, next_steps)
        values (
          ${userId}, ${investigationId}, ${"missing-record"}, ${m.title || m.key},
          ${"Dog that didn't bark — expected cadence broken"}, ${12},
          ${next.slice(0, 500)}
        )
      `;
      flagged += 1;
    }
  }
  return flagged;
}

export { detectMissingCadence };
