import { r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-BdnjwljA.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { t as deskMiddleware } from "./desk-auth-Bu4R-hGI.mjs";
import { a as grokChat, i as audit, o as parseJsonBlock, r as assertRate } from "./ops-P1rfsvDH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dark-xFYxgJfV.js
var DARK_SYSTEM = `TOWNREPORTER — DARK DESK: ANOMALY, LINKAGE & COORDINATION ANALYSIS
CITY: Longmont, Colorado. Role: civic pattern analyst.
Mode: fail-open collection, fail-closed escalation. Speculation by design.
Output is NEVER journalism and NEVER publishable. It is a question generator.

CONFIDENCE on every signal is CAPPED AT 0.5. High strength + low confidence = investigative priority, not a story.
Nothing reaches the public without Tier A grounding, the Section 6 gate, and a human producer. Most anomalies have boring explanations; find those first.

RULE 1 — COORDINATION IS NOT DECEPTION.
Neighborhood associations, unions, churches, advocacy talking points: normal, legal, healthy. Not astroturfing.
The story is never "these people were organized." Only: UNDISCLOSED SPONSORSHIP, FABRICATED IDENTITY, or MANUFACTURED SCALE (bots, duplicates, non-residents presented as residents).
If you cannot distinguish a finding from ordinary organizing, discard it.

RULE 2 — PRIVATE CITIZENS IN AGGREGATE ONLY.
Never profile a private resident, unmask an anonymous account, correlate a pseudonym to a real identity, or compile someone's civic participation to characterize them.
"17 of 22 comments shared a distinctive phrase" is allowed. "User X is fake, operated by Y" is forbidden.
Public officials in official capacity, organizations, businesses, paid lobbyists, and applicants seeking public action ARE in scope.

RULE 3 — ALLEGING PAID DECEPTION IS DEFAMATION-GRADE.
Pattern inference = a QUESTION. Never an assertion.

FIVE POSTURES
1. Dog that didn't bark — absence vs an EXPECTED CADENCE. No cadence, no signal.
2. Whisper in the crowd — 3+ independent reports within 7 days; below that is one bad week.
3. Fiscal fray — money moving without narrative (reserves, transfers, emergency procurement, threshold hugging, change orders).
4. Chorus that rhymes — concealment, fabrication, faked scale. NEVER mere coordination. Read Rule 1.
5. The web — who is connected to whom, and was it disclosed? Small cities are small; proximity is not corruption.

TRANSCRIPT / RECORD CHECKS (use only when the packet actually contains them)
A1 Commitment decay — "staff will return / we'll bring that back"; who promised what by when; did it return?
A2 Consent-agenda burial — high-dollar, land-use, contracts, policy in ~60 seconds of discussion.
A3 Vote that moved with no stated reason.
A4 Recusal drift — recuses on X, participates on the same parcel/parent/partner.
A5 Selective silence — only after a baseline of that member on that topic class.
A6 Who wasn't in the room — continuances vs attendance on decisive votes.
A7 Routine as camouflage — "code modernization / cleanup / housekeeping / pilot / efficiency / administrative amendment / technical correction" that changes who decides, who pays, or who may appeal.
A8 Procedural pivot — rules, quorum, comment limits, notice, schedule; especially on consent.
A9 Missing promised/required document.
A10 Sole-source repetition.
A11 Threshold hugging.
A12 Change-order creep after the public vote.
A13 Unannounced load overlapping a major project.

AUTHENTICITY (Chorus) — concealment/fabrication/faked scale only
F1 Near-duplicate DISTINCTIVE phrasing — quantify N of M. Common phrases do not count.
F2 Same arguments in the same ORDER.
F3 Imported vocabulary matching applicant/staff filings.
F4 Template artifacts, unfilled placeholders, identical typos.
F5 Missing middle — uniform length/register, no personal stakes.
P1 Volume vs baseline (quantify; do not just say "unusually high").
P2 Geography only from the PUBLIC record (no private address research).
P3 One-and-done cohort — aggregate only.
P4 Account provenance (Tier C) — aggregate only. Never name/unmask.
P5 Paid-canvass tell — participants saying they were asked/paid to come. Strongest astroturf evidence.
S1 Group with no past.
S2 Shared plumbing (agent, address, officers, phone) with the applicant/PR firm — documentary, strongest linkage.
S3 Undisclosed tie from PUBLIC affiliations only.
S4 Funded voice (990s, sponsor lists) undisclosed at testimony.
S5 Lobbyist registration gap.

MANDATORY innocent explanations before any coordination finding:
- Legitimate open advocacy / HOA / union / church campaign.
- Local coverage drove real turnout.
- Applicant openly told employees and neighbors.
- Everyone echoed the same staff report.
- The phrase is common in this policy area.
If any innocent account fits as well as coordination, DISCARD or HOLD. Language similarity alone cannot exceed strength 9. To exceed 9 needs documentary sponsorship or P5.

LINKAGE — nodes: applicant, parents/subs, LLC members, registered agent, counsel, consultants, owner of record, contractors, donors, board/staff, affiliated nonprofits.
Edges: shared plumbing; money (contribution amount, dates, vote date); revolving door; repeat consultant paid by applicant but cited as independent; parcel chain (sequence matters); cross-board actor; family edge from PUBLIC filings only.
A linkage is newsworthy only if: it should have been disclosed and was not; it contradicts the record; it coincides with a discretionary benefit; it explains another anomaly; or recusal was inconsistent. Else note in beat memory and move on.

TEMPORAL (sequence is the story)
T1 Contribution/hire/transfer within a short window of a discretionary decision — state interval in days.
T2 Pre-positioned fix (easement, utility, annexation, code) that only makes sense given an unannounced project.
T3 Quiet window — holidays, December, spring break, meeting after an election.
T4 Continuance until roster/attention/news cycle favors it.
T5 Parallel track at county/state/neighbor.
Correlation is not causation. Say so. The value is which document to request.

GATE (every signal; incomplete = cannot leave the desk)
1 Contestation? accusations/wrongdoing/reputational harm → counter-narrative mandatory.
2 Counter-narrative: direct response, official channel, other side's language, prior coverage. Prefer 3 query variants. Document empty results.
3 Benign explanation test — write the most persuasive innocent account. If it holds, HOLD or DISCARD.
4 Self-check: am I reaching? would I accept this if it pointed the other way? small-town coincidence as conspiracy? confidence from evidence or from how good the story would be?
5 Privacy/legal: strip private-individual profiling; paid-deception without documents → downgrade to a question; never name a private citizen as inauthentic.

SCORING
Strength 3-5 anecdote/no baseline; 6-9 documented anomaly partial anchor; 10-12 independent convergence; 13-15 absence + documented linkage + temporal proximity, innocents tested and not fitting.
Confidence always ≤ 0.5.
HANDOFF only: DISCARD | HOLD FOR PATTERN | MONITOR | FOR VERIFICATION
Never PUBLISH. Never contact anyone. If evidence is thin, return ZERO signals and say so in editor_summary.
Inventory honesty: if you lack speaker-ID transcripts, packets, or filings, list that in inventory_gaps and do not invent meetings, votes, or dollar figures.

Return ONLY JSON:
{
  "window": "date range or unknown",
  "inventory_gaps": ["string"],
  "editor_summary": "4-8 sentences. Questions, not charges.",
  "promises": [{"who":"","what":"","when_due":"","source_cite":"","status":"open|returned|unclear"}],
  "signals": [{
    "name": "",
    "posture": "Dog That Didn't Bark|Whisper|Fiscal Fray|Chorus|Web",
    "type": "",
    "strength": 3,
    "confidence": 0.3,
    "observation": "",
    "pattern": "",
    "linkage_map": "",
    "alternatives": "",
    "counter_narrative": "COMPLETED|NOT REQUIRED|INCOMPLETE — notes",
    "what_would_kill": "",
    "pathway": "",
    "privacy_review": "none | aggregate only",
    "handoff": "DISCARD|HOLD FOR PATTERN|MONITOR|FOR VERIFICATION"
  }]
}
0-8 signals. Prefer fewer.`;
var HANDOFFS = /* @__PURE__ */ new Set([
	"DISCARD",
	"HOLD FOR PATTERN",
	"MONITOR",
	"FOR VERIFICATION"
]);
async function ensureDarkSchema() {
	const sql = await getSql();
	await sql.query(`
    create table if not exists dark_runs (
      id serial primary key,
      user_id text not null,
      started_at timestamptz not null default now(),
      finished_at timestamptz,
      summary text,
      error text
    )
  `);
	await sql.query(`create index if not exists dark_runs_user_idx on dark_runs (user_id, started_at desc)`);
	await sql.query(`
    create table if not exists dark_signals (
      id serial primary key,
      user_id text not null,
      run_id integer references dark_runs(id) on delete set null,
      name text not null,
      posture text not null,
      signal_type text not null,
      strength integer not null default 3,
      confidence numeric not null default 0.3,
      observation text not null default '',
      pattern text not null default '',
      linkage_map text not null default '',
      alternatives text not null default '',
      counter_narrative text not null default '',
      what_would_kill text not null default '',
      pathway text not null default '',
      privacy_review text not null default '',
      handoff text not null default 'HOLD FOR PATTERN',
      created_at timestamptz not null default now()
    )
  `);
	await sql.query(`create index if not exists dark_signals_user_idx on dark_signals (user_id, created_at desc)`);
	await sql.query(`
    create table if not exists dark_promises (
      id serial primary key,
      user_id text not null,
      who_promised text not null,
      what text not null,
      when_due text,
      source_cite text,
      status text not null default 'open',
      created_at timestamptz not null default now()
    )
  `);
	await sql.query(`create index if not exists dark_promises_user_idx on dark_promises (user_id, created_at desc)`);
}
var listDarkSignals_createServerFn_handler = createServerRpc({
	id: "3e6006df6fac7044e94a5f88a8f5233abf5de4ea74b799291d4022966ae12e34",
	name: "listDarkSignals",
	filename: "src/lib/news/dark.ts"
}, (opts) => listDarkSignals.__executeServer(opts));
var listDarkSignals = createServerFn({ method: "GET" }).middleware([deskMiddleware]).handler(listDarkSignals_createServerFn_handler, async ({ context }) => {
	await ensureDarkSchema();
	return (await getSql())`
      select id, run_id, name, posture, signal_type, strength, confidence,
        observation, pattern, linkage_map, alternatives, counter_narrative,
        what_would_kill, pathway, privacy_review, handoff, created_at
      from dark_signals
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
});
var listDarkRuns_createServerFn_handler = createServerRpc({
	id: "ed0e725a7bea9c56f7276c2ff3f726173c5c7cd552bb421fe2ac2a177c7628d2",
	name: "listDarkRuns",
	filename: "src/lib/news/dark.ts"
}, (opts) => listDarkRuns.__executeServer(opts));
var listDarkRuns = createServerFn({ method: "GET" }).middleware([deskMiddleware]).handler(listDarkRuns_createServerFn_handler, async ({ context }) => {
	await ensureDarkSchema();
	return (await getSql())`
      select id, started_at, finished_at, summary, error
      from dark_runs
      where user_id = ${context.userId}
      order by started_at desc
      limit 12
    `;
});
var listDarkPromises_createServerFn_handler = createServerRpc({
	id: "6f97a86c3c56a496a387a66c953720cf87b355303663b8b6ca5fa46c61ecb62f",
	name: "listDarkPromises",
	filename: "src/lib/news/dark.ts"
}, (opts) => listDarkPromises.__executeServer(opts));
var listDarkPromises = createServerFn({ method: "GET" }).middleware([deskMiddleware]).handler(listDarkPromises_createServerFn_handler, async ({ context }) => {
	await ensureDarkSchema();
	return (await getSql())`
      select id, who_promised, what, when_due, source_cite, status, created_at
      from dark_promises
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
});
var runDarkDesk_createServerFn_handler = createServerRpc({
	id: "9b255f8e2895f56be8f515b012c024fd145d7a71860053e1b3d66294b9bf5d72",
	name: "runDarkDesk",
	filename: "src/lib/news/dark.ts"
}, (opts) => runDarkDesk.__executeServer(opts));
var runDarkDesk = createServerFn({ method: "POST" }).middleware([deskMiddleware]).validator((input) => input).handler(runDarkDesk_createServerFn_handler, async ({ context, data }) => {
	await ensureDarkSchema();
	await assertRate(context.userId, "dark");
	const sql = await getSql();
	const runId = (await sql`
      insert into dark_runs (user_id) values (${context.userId}) returning id
    `)[0].id;
	const sources = await sql`
      select id, url, title, kind, tier, status, last_hash, last_fetched_at, last_error
      from sources where user_id = ${context.userId}
      order by id asc
    `;
	const snaps = await sql`
      select s.title, s.url, snap.excerpt
      from snapshots snap
      join sources s on s.id = snap.source_id
      where snap.user_id = ${context.userId}
      order by snap.id desc
      limit 16
    `;
	const leads = await sql`
      select headline, why, topic, status
      from leads where user_id = ${context.userId}
      order by created_at desc limit 12
    `;
	const articles = await sql`
      select headline, topic, published_at from articles
      where user_id = ${context.userId} and status = 'published'
      order by published_at desc limit 10
    `;
	const memory = await sql`
      select entity, last_angle from beat_memory
      where user_id = ${context.userId} order by updated_at desc limit 16
    `;
	const paste = data.paste.trim().slice(0, 14e3);
	const pack = [
		`CITY: Longmont, Colorado. One-shot Dark Desk. Do not invent meetings, votes, or dollars not in this packet.`,
		`WATCH LIST:\n${sources.map((s) => `${s.tier} ${s.status} ${s.title} ${s.url}`).join("\n") || "(empty)"}`,
		`SCAN SNAPSHOTS:\n${snaps.map((s) => `### ${s.title}\n${s.url}\n${s.excerpt.slice(0, 1800)}`).join("\n\n") || "(none — run a Scan first or paste minutes)"}`,
		`OPEN LEADS:\n${leads.map((l) => `${l.status} ${l.topic}: ${l.headline} — ${l.why}`).join("\n") || "(none)"}`,
		`PUBLISHED:\n${articles.map((a) => `${a.topic}: ${a.headline}`).join("\n") || "(none)"}`,
		`BEAT MEMORY:\n${memory.map((m) => `${m.entity}: ${m.last_angle}`).join("\n") || "(none)"}`,
		paste ? `EDITOR PASTE (treat as alleged text to interrogate, not as proof):\n${paste}` : "EDITOR PASTE: (none)"
	].join("\n\n");
	const ai = await grokChat(DARK_SYSTEM, pack.slice(0, 28e3), 3200);
	if (!ai.ok) {
		await sql`
        update dark_runs set finished_at = now(), error = ${ai.error}
        where id = ${runId} and user_id = ${context.userId}
      `;
		return {
			ok: false,
			error: ai.error
		};
	}
	const parsed = parseJsonBlock(ai.text) ?? {};
	const summary = String(parsed.editor_summary ?? "").slice(0, 2e3);
	const gaps = (parsed.inventory_gaps ?? []).join("; ").slice(0, 800);
	const header = [
		summary,
		gaps ? `Gaps: ${gaps}` : "",
		parsed.window ? `Window: ${parsed.window}` : ""
	].filter(Boolean).join("\n");
	let stored = 0;
	for (const sig of parsed.signals ?? []) {
		const name = String(sig.name ?? "").trim();
		if (!name) continue;
		const strength = Math.min(15, Math.max(3, Number(sig.strength) || 3));
		const confidence = Math.min(.5, Math.max(.1, Number(sig.confidence) || .3));
		let handoff = String(sig.handoff ?? "HOLD FOR PATTERN").toUpperCase();
		if (!HANDOFFS.has(handoff)) handoff = "HOLD FOR PATTERN";
		await sql`
        insert into dark_signals (
          user_id, run_id, name, posture, signal_type, strength, confidence,
          observation, pattern, linkage_map, alternatives, counter_narrative,
          what_would_kill, pathway, privacy_review, handoff
        ) values (
          ${context.userId}, ${runId}, ${name.slice(0, 200)},
          ${String(sig.posture ?? "").slice(0, 80)},
          ${String(sig.type ?? "").slice(0, 80)},
          ${strength}, ${confidence},
          ${String(sig.observation ?? "").slice(0, 4e3)},
          ${String(sig.pattern ?? "").slice(0, 4e3)},
          ${String(sig.linkage_map ?? "").slice(0, 4e3)},
          ${String(sig.alternatives ?? "").slice(0, 4e3)},
          ${String(sig.counter_narrative ?? "").slice(0, 4e3)},
          ${String(sig.what_would_kill ?? "").slice(0, 2e3)},
          ${String(sig.pathway ?? "").slice(0, 2e3)},
          ${String(sig.privacy_review ?? "").slice(0, 500)},
          ${handoff}
        )
      `;
		stored += 1;
	}
	for (const p of parsed.promises ?? []) {
		const who = String(p.who ?? "").trim();
		const what = String(p.what ?? "").trim();
		if (!who || !what) continue;
		await sql`
        insert into dark_promises (user_id, who_promised, what, when_due, source_cite, status)
        values (
          ${context.userId}, ${who.slice(0, 200)}, ${what.slice(0, 800)},
          ${String(p.when_due ?? "").slice(0, 120) || null},
          ${String(p.source_cite ?? "").slice(0, 400) || null},
          ${String(p.status ?? "open").slice(0, 40)}
        )
      `;
	}
	await sql`
      update dark_runs
      set finished_at = now(), summary = ${header.slice(0, 2500)}
      where id = ${runId} and user_id = ${context.userId}
    `;
	await audit(context.userId, "dark", `run ${runId} signals ${stored}`);
	return {
		ok: true,
		runId,
		stored,
		summary: header
	};
});
var sendDarkSignalToQueue_createServerFn_handler = createServerRpc({
	id: "3adf87a84026d2554afed3147bc3a92b809dbf9b978c275fabba358da73f0c5d",
	name: "sendDarkSignalToQueue",
	filename: "src/lib/news/dark.ts"
}, (opts) => sendDarkSignalToQueue.__executeServer(opts));
var sendDarkSignalToQueue = createServerFn({ method: "POST" }).middleware([deskMiddleware]).validator((id) => id).handler(sendDarkSignalToQueue_createServerFn_handler, async ({ context, data: id }) => {
	await ensureDarkSchema();
	const sql = await getSql();
	const sig = (await sql`
      select id, run_id, name, posture, signal_type, strength, confidence,
        observation, pattern, linkage_map, alternatives, counter_narrative,
        what_would_kill, pathway, privacy_review, handoff, created_at
      from dark_signals where id = ${id} and user_id = ${context.userId} limit 1
    `)[0];
	if (!sig) return {
		ok: false,
		error: "Signal not found"
	};
	const why = [
		"DARK DESK — not a story. Question only. Confidence capped. Requires Tier A grounding before any draft.",
		`Posture: ${sig.posture}. Type: ${sig.signal_type}. Strength ${sig.strength} / confidence ${sig.confidence}.`,
		sig.observation,
		`Pathway: ${sig.pathway}`,
		`Alternatives: ${sig.alternatives}`
	].filter(Boolean).join("\n\n").slice(0, 4e3);
	await sql`
      insert into leads (user_id, headline, why, topic, status, source_urls, evidence, newsworthiness)
      values (
        ${context.userId},
        ${`[Dark] ${sig.name}`.slice(0, 240)},
        ${why},
        'council',
        'held',
        '[]',
        ${sig.observation.slice(0, 4e3)},
        ${Math.min(20, sig.strength)}
      )
    `;
	await audit(context.userId, "dark-handoff", String(id));
	return { ok: true };
});
//#endregion
export { listDarkPromises_createServerFn_handler, listDarkRuns_createServerFn_handler, listDarkSignals_createServerFn_handler, runDarkDesk_createServerFn_handler, sendDarkSignalToQueue_createServerFn_handler };
