import { t as PAPER } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as PaperShell } from "./paper-chrome-Bj8-Jjsl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-BIVMDC_6.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl font-semibold",
		children: "About this paper"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 max-w-2xl space-y-4 text-lg leading-7 text-ink-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				PAPER.name,
				" is a civic newspaper for ",
				PAPER.location,
				". It watches the public record — council, planning, utilities, schools — and prints what an editor is willing to sign."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Grok works the desk: fetching sources, filing leads, drafting recaps under wire-service rules. A human editor-in-chief still has to publish. There is no fully automated path to the masthead." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We are not the Longmont Times-Call, not the city, and not a replacement for either. We cover the meetings and packets most people never sit through, and we always point back to the primary source when we have one." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This edition runs as a hosted experiment. Drafts and source lists live on the desk behind a sign-in. The public archive is the paper you are reading." })
		]
	})] });
}
//#endregion
export { About as component };
