import { i as formatDate, t as PAPER } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useCurrentUserState, i as UserButton, n as SignedIn, r as SignedOut } from "./gates-B_IGPI9u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/paper-chrome-Bj8-Jjsl.js
var import_jsx_runtime = require_jsx_runtime();
function Masthead({ compact = false }) {
	const today = formatDate(/* @__PURE__ */ new Date());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "border-b border-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 border-b border-rule px-1 py-2 text-[11px] tracking-[0.14em] text-muted uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: PAPER.kicker }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: today
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSlot, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: compact ? "py-4 text-center" : "py-8 text-center sm:py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl font-semibold tracking-tight text-ink sm:text-6xl",
						children: PAPER.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm tracking-[0.18em] text-muted uppercase",
						children: PAPER.location
					})]
				}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-3 max-w-md font-display text-base italic text-ink-2",
					children: PAPER.tagline
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-wrap items-center justify-center gap-x-5 gap-y-2 border-y-2 border-ink py-2.5 text-[12px] font-medium tracking-[0.12em] uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-rust",
						children: "The paper"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/about",
						className: "hover:text-rust",
						children: "About"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/how-we-report",
						className: "hover:text-rust",
						children: "How we report"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/corrections",
						className: "hover:text-rust",
						children: "Corrections"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/feed",
						className: "hover:text-rust",
						children: "RSS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk",
						className: "text-rust hover:text-rust-2",
						children: "Editor desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/TownReporter.zip",
						download: "TownReporter.zip",
						className: "bg-ink px-3 py-1 text-paper hover:bg-ink-2",
						children: "Source zip"
					})
				]
			})
		]
	});
}
function AuthSlot() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-16 animate-pulse bg-paper-2" });
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex items-center gap-2 normal-case tracking-normal",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}) })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/login",
		className: "hover:text-rust",
		children: "Sign in"
	}) });
}
function PaperShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-paper text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-4 py-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Masthead, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-8",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-8 border-t border-ink pt-4 pb-10 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						PAPER.name,
						" · ",
						PAPER.location,
						". Free to reprint with credit and a link back. Verify details against the official record."
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/TownReporter.zip",
								download: "TownReporter.zip",
								className: "text-rust hover:text-rust-2",
								children: "Download source (zip)"
							}),
							" — ",
							"the code, not the live desk. ~550 KB."
						]
					})]
				})
			]
		})
	});
}
function TopicChip({ topic, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		search: { topic },
		className: "border px-3 py-1 text-[11px] tracking-[0.14em] uppercase " + (active ? "border-ink bg-ink text-paper" : "border-rule text-ink-2 hover:border-ink"),
		children: topic
	});
}
//#endregion
export { TopicChip as n, PaperShell as t };
