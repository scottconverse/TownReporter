import { o as __toESM } from "../_runtime.mjs";
import { t as PAPER } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, o as require_react, r as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link, b as useRouter, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { B as union, F as number, I as object, N as literal, z as string } from "../_libs/@better-auth/core+[...].mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
import { r as getSql } from "./db-BdnjwljA.mjs";
import { n as auth } from "./server-D1C_za_8.mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/public-DQqQcLz3.js
var listPublishedArticles = createServerFn({ method: "GET" }).handler(createSsrRpc("bf1b86607827896e82263b26867d05e1fa0129d1ad9b15fec19b1af69cecdf6e"));
var getPublishedArticle = createServerFn({ method: "GET" }).validator((slug) => slug).handler(createSsrRpc("7fd0d893e556b31897fdd44e6a3723a05ccb5c030caa87333339048cf240876a"));
var listPublishedByTopic = createServerFn({ method: "GET" }).validator((topic) => topic).handler(createSsrRpc("babb7cb9c4dcdf79ab03f223de9e03f878eb0675085365d76b3590705b09a76e"));
var searchPublished = createServerFn({ method: "GET" }).validator((q) => q.trim().slice(0, 80)).handler(createSsrRpc("88a303f278e5f9adbd1c000cb7f47aa1648cfc72f4df2f66935d2d2063b09584"));
var listPublicCorrections = createServerFn({ method: "GET" }).handler(createSsrRpc("0fcc8492304f9b5fa80bc98d7a2efc1dd137d3e368fe2cf69852f6a4de3d0a44"));
var subscribeNewsletter = createServerFn({ method: "POST" }).validator((email) => email.trim().toLowerCase()).handler(createSsrRpc("f3458156169f228d7be94baa0c8b85503435e48cfe22384e59f3596718d7878a"));
var confirmNewsletter = createServerFn({ method: "GET" }).validator((token) => token.trim()).handler(createSsrRpc("92caba9457f6fb910c7c5881eb90e75c93dc620b103a39afe8de0242c5c5ca28"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-BKRELfXp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-paper px-6 text-center text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-rust",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-2 text-sm text-rust hover:text-rust-2",
				children: "Back to the paper"
			})
		]
	});
}
function AppNotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-paper px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] tracking-[0.16em] text-rust uppercase",
					children: "TownReporter"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-semibold",
					children: "No page here"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-ink-2",
					children: "That address is not in this edition. The paper is on the front page. The desk is behind sign-in."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex min-h-11 items-center bg-ink px-4 text-sm text-paper hover:bg-ink-2",
						children: "Open the paper"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk",
						className: "inline-flex min-h-11 items-center border border-ink px-4 text-sm hover:bg-paper-2",
						children: "Editor desk"
					})]
				})
			]
		})
	});
}
function AppPending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-paper px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: "Opening…"
		})
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-CrEISsLs.css";
var Route$17 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: `${PAPER.name} — ${PAPER.location}` },
			{
				name: "description",
				content: "A civic newspaper for Longmont, Colorado. Human-edited. Grok-reported from the public record."
			},
			{
				name: "theme-color",
				content: "#F6F1E7"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap"
			}
		]
	}),
	component: Root
});
function Root() {
	const [client] = (0, import_react.useState)(() => new QueryClient({ defaultOptions: { queries: { refetchOnWindowFocus: false } } }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
				client,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$14 = () => import("./routes-CR8a4mHE.mjs");
var Route$16 = createFileRoute("/")({
	validateSearch: (s) => ({
		topic: typeof s.topic === "string" ? s.topic : void 0,
		q: typeof s.q === "string" ? s.q : void 0
	}),
	loader: () => listPublishedArticles(),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./about-BIVMDC_6.mjs");
var Route$15 = createFileRoute("/about")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./corrections-CI62sbyA.mjs");
var Route$14 = createFileRoute("/corrections")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
function Opening() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-desk px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: "Opening the desk…"
		})
	});
}
var $$splitComponentImporter$11 = () => import("./desk-BTxaIvuR.mjs");
var Route$13 = createFileRoute("/desk")({
	component: lazyRouteComponent($$splitComponentImporter$11, "component"),
	pendingComponent: Opening
});
var Route$12 = createFileRoute("/feed")({ server: { handlers: { GET: async () => {
	const items = (await (await getSql())`
          select slug, headline, dek, published_at
          from articles
          where status = 'published'
          order by published_at desc
          limit 40
        `).map((r) => {
		const link = `/articles/${encodeURIComponent(r.slug)}`;
		return `<item>
  <title><![CDATA[${r.headline}]]></title>
  <link>${link}</link>
  <guid>${link}</guid>
  <pubDate>${new Date(r.published_at).toUTCString()}</pubDate>
  <description><![CDATA[${r.dek}]]></description>
</item>`;
	}).join("\n");
	const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
<channel>
  <title>${PAPER.name} — ${PAPER.location}</title>
  <description>${PAPER.tagline}</description>
  <language>en-us</language>
  ${items}
</channel>
</rss>`;
	return new Response(xml, { headers: {
		"content-type": "application/rss+xml; charset=utf-8",
		"cache-control": "public, max-age=300"
	} });
} } } });
var $$splitComponentImporter$10 = () => import("./how-we-report-DDbdVL7L.mjs");
var Route$11 = createFileRoute("/how-we-report")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./login-Du7OUor7.mjs");
var Route$10 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./articles._slug-R68KBXhN.mjs");
var Route$9 = createFileRoute("/articles/$slug")({
	loader: ({ params }) => getPublishedArticle({ data: params.slug }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./desk.index-8K44GHsI.mjs");
var Route$8 = createFileRoute("/desk/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./desk.dark-BbGJFwT0.mjs");
function DarkPending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-ink px-6 text-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: "Opening Dark desk…"
		})
	});
}
var Route$7 = createFileRoute("/desk/dark")({
	component: lazyRouteComponent($$splitComponentImporter$6, "component"),
	pendingComponent: DarkPending
});
var $$splitComponentImporter$5 = () => import("./desk.memory-CZ7hcYhA.mjs");
var Route$6 = createFileRoute("/desk/memory")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./desk.queue-V_769tJZ.mjs");
var Route$5 = createFileRoute("/desk/queue")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./desk.scan-ByHO6AD3.mjs");
var Route$4 = createFileRoute("/desk/scan")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./desk.sources-BzSLDU8q.mjs");
var Route$3 = createFileRoute("/desk/sources")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./newsletter.confirm-BCCpdhHW.mjs");
var Route$2 = createFileRoute("/newsletter/confirm")({
	validateSearch: (s) => ({ token: typeof s.token === "string" ? s.token : "" }),
	loaderDeps: ({ search }) => ({ token: search.token }),
	loader: async ({ deps }) => {
		if (!deps.token) return { ok: false };
		return confirmNewsletter({ data: deps.token });
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var Route$1 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var $$splitComponentImporter = () => import("./desk.story._leadId-C5m16syS.mjs");
var Route = createFileRoute("/desk/story/$leadId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$16.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$17
});
var AboutRoute = Route$15.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$17
});
var CorrectionsRoute = Route$14.update({
	id: "/corrections",
	path: "/corrections",
	getParentRoute: () => Route$17
});
var DeskRoute = Route$13.update({
	id: "/desk",
	path: "/desk",
	getParentRoute: () => Route$17
});
var FeedRoute = Route$12.update({
	id: "/feed",
	path: "/feed",
	getParentRoute: () => Route$17
});
var HowWeReportRoute = Route$11.update({
	id: "/how-we-report",
	path: "/how-we-report",
	getParentRoute: () => Route$17
});
var LoginRoute = Route$10.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$17
});
var ArticlesSlugRoute = Route$9.update({
	id: "/articles/$slug",
	path: "/articles/$slug",
	getParentRoute: () => Route$17
});
var DeskIndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => DeskRoute
});
var DeskDarkRoute = Route$7.update({
	id: "/dark",
	path: "/dark",
	getParentRoute: () => DeskRoute
});
var DeskMemoryRoute = Route$6.update({
	id: "/memory",
	path: "/memory",
	getParentRoute: () => DeskRoute
});
var DeskQueueRoute = Route$5.update({
	id: "/queue",
	path: "/queue",
	getParentRoute: () => DeskRoute
});
var DeskScanRoute = Route$4.update({
	id: "/scan",
	path: "/scan",
	getParentRoute: () => DeskRoute
});
var DeskSourcesRoute = Route$3.update({
	id: "/sources",
	path: "/sources",
	getParentRoute: () => DeskRoute
});
var NewsletterConfirmRoute = Route$2.update({
	id: "/newsletter/confirm",
	path: "/newsletter/confirm",
	getParentRoute: () => Route$17
});
var ApiAuthSplatRoute = Route$1.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$17
});
var DeskRouteChildren = {
	DeskDarkRoute,
	DeskMemoryRoute,
	DeskQueueRoute,
	DeskScanRoute,
	DeskSourcesRoute,
	DeskIndexRoute,
	DeskStoryLeadIdRoute: Route.update({
		id: "/story/$leadId",
		path: "/story/$leadId",
		getParentRoute: () => DeskRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	CorrectionsRoute,
	DeskRoute: DeskRoute._addFileChildren(DeskRouteChildren),
	FeedRoute,
	HowWeReportRoute,
	LoginRoute,
	ArticlesSlugRoute,
	NewsletterConfirmRoute,
	ApiAuthSplatRoute
};
var routeTree = Route$17._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultNotFoundComponent: AppNotFound,
		defaultPendingComponent: AppPending,
		defaultPendingMs: 0
	});
}
//#endregion
export { Opening as a, listPublicCorrections as c, searchPublished as d, subscribeNewsletter as f, Route$9 as i, listPublishedArticles as l, Route as n, Route$16 as o, Route$2 as r, getPublishedArticle as s, router_exports as t, listPublishedByTopic as u };
