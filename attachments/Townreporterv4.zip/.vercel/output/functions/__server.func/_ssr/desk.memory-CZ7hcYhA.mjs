import { o as __toESM } from "../_runtime.mjs";
import { a as formatShortDate } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { a as areaClass, n as Field, o as inputClass, r as InkButton, t as DeskShell } from "./desk-chrome-Cj0G1VLJ.mjs";
import { s as listMemory, t as addCorrection } from "./desk--8gnbvNC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk.memory-CZ7hcYhA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MemoryPage() {
	const qc = useQueryClient();
	const memory = useQuery({
		queryKey: ["memory"],
		queryFn: () => listMemory()
	});
	const [slug, setSlug] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const corr = useMutation({
		mutationFn: () => addCorrection({ data: {
			articleSlug: slug || void 0,
			body
		} }),
		onSuccess: (res) => {
			if (res.ok) {
				setBody("");
				qc.invalidateQueries({ queryKey: ["corrections"] });
			}
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DeskShell, {
		title: "Memory & corrections",
		kicker: "The record",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-ink-2",
				children: "Beat memory is what Grok is told we already covered. Corrections are public."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Post a correction"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 max-w-xl space-y-3",
					onSubmit: (e) => {
						e.preventDefault();
						corr.mutate();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Article slug (optional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: slug,
								onChange: (e) => setSlug(e.target.value),
								placeholder: "welcome-to-townreporter"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Correction",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: areaClass + " min-h-28",
								value: body,
								onChange: (e) => setBody(e.target.value),
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
							type: "submit",
							disabled: corr.isPending,
							children: "Publish correction"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Beat memory"
				}), (memory.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "Empty until you publish."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-rule border border-rule bg-paper",
					children: (memory.data ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: m.entity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ink-2",
								children: m.last_angle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-muted",
								children: formatShortDate(m.updated_at)
							})
						]
					}, m.id))
				})]
			})
		]
	});
}
//#endregion
export { MemoryPage as component };
