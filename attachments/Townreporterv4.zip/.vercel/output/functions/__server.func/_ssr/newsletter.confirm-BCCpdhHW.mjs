import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PaperShell } from "./paper-chrome-Bj8-Jjsl.mjs";
import { r as Route$2 } from "./router-BKRELfXp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/newsletter.confirm-BCCpdhHW.js
var import_jsx_runtime = require_jsx_runtime();
function ConfirmPage() {
	const res = Route$2.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "Newsletter"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-xl text-ink-2",
			children: res.ok ? "You’re confirmed. We’ll send new editions to that address." : "That confirmation link is invalid or already used."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-6 inline-block text-rust",
			children: "Back to the paper"
		})
	] });
}
//#endregion
export { ConfirmPage as component };
