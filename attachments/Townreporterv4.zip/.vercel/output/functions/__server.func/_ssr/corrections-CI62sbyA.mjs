import { a as formatShortDate } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as PaperShell } from "./paper-chrome-Bj8-Jjsl.mjs";
import { c as listPublicCorrections } from "./router-BKRELfXp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/corrections-CI62sbyA.js
var import_jsx_runtime = require_jsx_runtime();
function Corrections() {
	const { data: items = [] } = useQuery({
		queryKey: ["corrections"],
		queryFn: () => listPublicCorrections()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl font-semibold",
			children: "Corrections"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-2xl text-lg text-ink-2",
			children: "If we got it wrong, it lives here in the open — not buried in a rewrite nobody sees."
		}),
		items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 text-muted",
			children: "No corrections have been posted yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-8 max-w-2xl space-y-6",
			children: items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-t border-rule pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] tracking-[0.14em] text-muted uppercase",
					children: [formatShortDate(c.created_at), c.headline ? ` · ${c.headline}` : ""]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-ink-2",
					children: c.body
				})]
			}, c.id))
		})
	] });
}
//#endregion
export { Corrections as component };
