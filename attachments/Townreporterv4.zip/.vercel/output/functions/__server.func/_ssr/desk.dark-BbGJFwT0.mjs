import { o as __toESM } from "../_runtime.mjs";
import { a as formatShortDate, i as formatDate } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
import { t as deskMiddleware } from "./desk-auth-Bu4R-hGI.mjs";
import { a as areaClass, r as InkButton, t as DeskShell } from "./desk-chrome-Cj0G1VLJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk.dark-BbGJFwT0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var listDarkSignals = createServerFn({ method: "GET" }).middleware([deskMiddleware]).handler(createSsrRpc("3e6006df6fac7044e94a5f88a8f5233abf5de4ea74b799291d4022966ae12e34"));
var listDarkRuns = createServerFn({ method: "GET" }).middleware([deskMiddleware]).handler(createSsrRpc("ed0e725a7bea9c56f7276c2ff3f726173c5c7cd552bb421fe2ac2a177c7628d2"));
var listDarkPromises = createServerFn({ method: "GET" }).middleware([deskMiddleware]).handler(createSsrRpc("6f97a86c3c56a496a387a66c953720cf87b355303663b8b6ca5fa46c61ecb62f"));
var runDarkDesk = createServerFn({ method: "POST" }).middleware([deskMiddleware]).validator((input) => input).handler(createSsrRpc("9b255f8e2895f56be8f515b012c024fd145d7a71860053e1b3d66294b9bf5d72"));
var sendDarkSignalToQueue = createServerFn({ method: "POST" }).middleware([deskMiddleware]).validator((id) => id).handler(createSsrRpc("3adf87a84026d2554afed3147bc3a92b809dbf9b978c275fabba358da73f0c5d"));
function DarkPage() {
	const qc = useQueryClient();
	const [paste, setPaste] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)(null);
	const signals = useQuery({
		queryKey: ["dark-signals"],
		queryFn: () => listDarkSignals()
	});
	const runs = useQuery({
		queryKey: ["dark-runs"],
		queryFn: () => listDarkRuns()
	});
	const promises = useQuery({
		queryKey: ["dark-promises"],
		queryFn: () => listDarkPromises()
	});
	const run = useMutation({
		mutationFn: () => runDarkDesk({ data: { paste } }),
		onSuccess: (res) => {
			if (!res.ok) {
				setNotice(res.error);
				return;
			}
			setNotice(null);
			qc.invalidateQueries({ queryKey: ["dark-signals"] });
			qc.invalidateQueries({ queryKey: ["dark-runs"] });
			qc.invalidateQueries({ queryKey: ["dark-promises"] });
		},
		onError: (err) => {
			setNotice(err instanceof Error ? err.message : "Dark desk failed");
		}
	});
	const toQueue = useMutation({
		mutationFn: (id) => sendDarkSignalToQueue({ data: id }),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["leads"] });
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DeskShell, {
		night: true,
		title: "Dark desk",
		kicker: "Lane 3 — questions only",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-w-2xl border border-ink-2 bg-ink-2 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "One Grok pass over scan snapshots, the paper, beat memory, and whatever you paste. Output is never copy. Confidence is capped at 0.5. Coordination is not deception. Private people stay aggregate. Nothing here prints." })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-6 block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] tracking-[0.14em] text-paper-2 uppercase",
					children: "Paste minutes, comments, a packet — optional"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: areaClass + " min-h-36",
					value: paste,
					onChange: (e) => setPaste(e.target.value),
					placeholder: "Transcript, public comment, a staff report excerpt…"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
					tone: "invert",
					disabled: run.isPending,
					onClick: () => run.mutate(),
					children: run.isPending ? "Running Dark Desk…" : "Run Dark Desk"
				}), run.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-paper-2",
					children: "One Grok call. Stay on this page."
				})]
			}),
			run.data?.ok && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 border border-paper-2 bg-ink-2 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						run.data.stored,
						" signal",
						run.data.stored === 1 ? "" : "s",
						" filed"
					]
				}), run.data.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 whitespace-pre-wrap text-paper-2",
					children: run.data.summary
				})]
			}),
			(signals.error || runs.error) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-[#e8b4a8]",
				children: ["Dark desk tables are warming up. Try Run again.", signals.error instanceof Error ? ` ${signals.error.message}` : ""]
			}),
			(notice || run.data && !run.data.ok) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-[#e8b4a8]",
				children: notice || (run.data && !run.data.ok ? run.data.error : "")
			}),
			(promises.data ?? []).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Promise ledger"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-ink-2 border border-ink-2",
					children: (promises.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium",
							children: [
								p.who_promised,
								" — ",
								p.what
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-paper-2",
							children: [
								p.status,
								p.when_due ? ` · due ${p.when_due}` : "",
								p.source_cite ? ` · ${p.source_cite}` : ""
							]
						})]
					}, p.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Signals"
					}),
					(signals.data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-paper-2",
						children: "None yet. Run the desk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-4",
						children: (signals.data ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border border-ink-2 bg-ink-2 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] tracking-[0.14em] text-rust uppercase",
									children: [
										s.posture,
										" · ",
										s.signal_type,
										" · strength ",
										s.strength,
										" · confidence ",
										Number(s.confidence).toFixed(2),
										" · ",
										s.handoff
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 font-display text-xl",
									children: s.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "Observation",
									text: s.observation
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "Pattern",
									text: s.pattern
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "Linkage",
									text: s.linkage_map
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "Alternatives",
									text: s.alternatives
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "Counter-narrative",
									text: s.counter_narrative
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "What would kill this",
									text: s.what_would_kill
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "Pathway",
									text: s.pathway
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
									label: "Privacy",
									text: s.privacy_review
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: [s.handoff === "FOR VERIFICATION" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
										tone: "invert",
										disabled: toQueue.isPending,
										onClick: () => toQueue.mutate(s.id),
										children: "Send to queue as a question"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "self-center text-sm text-paper-2",
										children: formatShortDate(s.created_at)
									})]
								})
							]
						}, s.id))
					})
				]
			}),
			(runs.data ?? []).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Previous runs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-ink-2 border border-ink-2",
					children: (runs.data ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-paper-2",
								children: formatDate(r.started_at)
							}),
							r.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-danger",
								children: r.error
							}),
							r.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 whitespace-pre-wrap text-paper-2",
								children: r.summary
							})
						]
					}, r.id))
				})]
			}),
			toQueue.isSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-paper-2",
				children: [
					"Held in the queue as a question.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk/queue",
						className: "text-rust",
						children: "Open the queue"
					})
				]
			})
		]
	});
}
function Block({ label, text }) {
	if (!text.trim()) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] tracking-[0.14em] text-paper-2 uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 whitespace-pre-wrap text-paper-2",
			children: text
		})]
	});
}
//#endregion
export { DarkPage as component };
