//#region node_modules/.nitro/vite/services/ssr/assets/paper-CGH1EBka.js
var PAPER = {
	name: "TownReporter",
	city: "Longmont",
	state: "Colorado",
	location: "Longmont, Colorado",
	tagline: "Civic news, human-edited.",
	kicker: "Vol. 1  ·  Longmont edition"
};
var TOPICS = [
	"council",
	"budget",
	"housing",
	"utilities",
	"schools",
	"planning",
	"infrastructure",
	"elections",
	"about"
];
var SEED_SOURCES = [
	{
		url: "https://www.longmontcolorado.gov/",
		title: "City of Longmont",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://www.longmontcolorado.gov/government/city-council",
		title: "Longmont City Council",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://www.longmontcolorado.gov/government/agendas-minutes-and-videos",
		title: "Agendas, minutes, and videos",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://www.longmontcolorado.gov/government/departments/planning-and-development-services",
		title: "Planning and Development",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://www.nextlight.net/",
		title: "NextLight",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://www.svvsd.org/",
		title: "St. Vrain Valley Schools",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://bouldercounty.gov/",
		title: "Boulder County",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://www.longmontcolorado.gov/community/library",
		title: "Longmont Public Library",
		kind: "official",
		tier: "A"
	},
	{
		url: "https://www.youtube.com/@CityofLongmont",
		title: "City of Longmont on YouTube",
		kind: "youtube",
		tier: "A"
	}
];
function slugify(input) {
	return input.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 72) || "item";
}
function parseUrlList(raw) {
	if (!raw) return [];
	try {
		const v = JSON.parse(raw);
		return Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
	} catch {
		return [];
	}
}
function formatDate(iso) {
	if (!iso) return "";
	const d = typeof iso === "string" ? new Date(iso) : iso;
	if (Number.isNaN(d.getTime())) return "";
	return d.toLocaleDateString("en-US", {
		weekday: "long",
		month: "long",
		day: "numeric",
		year: "numeric"
	});
}
function formatShortDate(iso) {
	if (!iso) return "";
	const d = typeof iso === "string" ? new Date(iso) : iso;
	if (Number.isNaN(d.getTime())) return "";
	return d.toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
//#endregion
export { formatShortDate as a, formatDate as i, SEED_SOURCES as n, parseUrlList as o, TOPICS as r, slugify as s, PAPER as t };
