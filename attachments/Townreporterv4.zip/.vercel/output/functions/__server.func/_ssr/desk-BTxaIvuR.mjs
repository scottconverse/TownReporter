import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { p as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useCurrentUserState, t as RedirectToSignIn } from "./gates-B_IGPI9u.mjs";
import { a as Opening } from "./router-BKRELfXp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-BTxaIvuR.js
var import_jsx_runtime = require_jsx_runtime();
function DeskGate() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-desk text-desk-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
//#endregion
export { DeskGate as component };
