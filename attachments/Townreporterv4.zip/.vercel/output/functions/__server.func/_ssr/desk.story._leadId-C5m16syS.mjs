import { o as __toESM } from "../_runtime.mjs";
import { o as parseUrlList } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-BKRELfXp.mjs";
import { n as Field, r as InkButton, t as DeskShell } from "./desk-chrome-Cj0G1VLJ.mjs";
import { a as getLead, f as saveDraft, i as draftLead, u as publishLead } from "./desk--8gnbvNC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk.story._leadId-C5m16syS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StoryPage() {
	const { leadId } = Route.useParams();
	const id = Number(leadId);
	const nav = useNavigate();
	const qc = useQueryClient();
	const { data, isPending } = useQuery({
		queryKey: ["lead", id],
		queryFn: () => getLead({ data: id })
	});
	const [headline, setHeadline] = (0, import_react.useState)("");
	const [dek, setDek] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [topic, setTopic] = (0, import_react.useState)("council");
	const [msg, setMsg] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!data?.draft) return;
		setHeadline(data.draft.headline);
		setDek(data.draft.dek);
		setBody(data.draft.body);
		setTopic(data.draft.topic);
	}, [data?.draft]);
	const draft = useMutation({
		mutationFn: () => draftLead({ data: id }),
		onSuccess: async (res) => {
			if (!res.ok) {
				setMsg(res.error);
				return;
			}
			setMsg("");
			await qc.invalidateQueries({ queryKey: ["lead", id] });
			await qc.invalidateQueries({ queryKey: ["leads"] });
		}
	});
	const save = useMutation({
		mutationFn: () => saveDraft({ data: {
			leadId: id,
			headline,
			dek,
			body,
			topic
		} }),
		onSuccess: () => setMsg("Saved.")
	});
	const publish = useMutation({
		mutationFn: async () => {
			await saveDraft({ data: {
				leadId: id,
				headline,
				dek,
				body,
				topic
			} });
			return publishLead({ data: id });
		},
		onSuccess: async (res) => {
			if (!res.ok) {
				setMsg(res.error);
				return;
			}
			await qc.invalidateQueries({ queryKey: ["leads"] });
			await qc.invalidateQueries({ queryKey: ["paper"] });
			await nav({
				to: "/articles/$slug",
				params: { slug: res.slug }
			});
		}
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskShell, {
		title: "Story",
		kicker: "Workbench",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading lead…"
		})
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskShell, {
		title: "Missing",
		kicker: "Workbench",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "That lead is not on this desk." })
	});
	const sources = parseUrlList(data.lead.source_urls);
	const dark = data.lead.headline.startsWith("[Dark]") || data.lead.why.includes("DARK DESK — not a story");
	const locked = dark || data.lead.status === "held" || data.lead.status === "killed";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DeskShell, {
		title: data.lead.headline,
		kicker: dark ? "Dark question — not copy" : "Workbench",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-ink-2",
				children: data.lead.why
			}),
			dark && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl border border-ink bg-paper-2 p-4 text-sm",
				children: "This came from Dark desk. It is a question, not a draft. It cannot print. If the record confirms it, file a new lead from a Tier A source and draft from that."
			}),
			data.lead.evidence && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "mt-4 max-w-2xl border-l-2 border-rust pl-4 text-sm text-ink-2",
				children: data.lead.evidence
			}),
			sources.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 text-sm",
				children: sources.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: u,
					className: "break-all text-rust",
					target: "_blank",
					rel: "noreferrer",
					children: u
				}) }, u))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: [
					!locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
						disabled: draft.isPending,
						onClick: () => draft.mutate(),
						children: draft.isPending ? "Drafting with Grok…" : data.draft ? "Redraft" : "Draft with Grok"
					}),
					!locked && data.draft && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
						tone: "ghost",
						disabled: save.isPending,
						onClick: () => save.mutate(),
						children: "Save edits"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
						disabled: publish.isPending || !headline || !body,
						onClick: () => publish.mutate(),
						children: publish.isPending ? "Publishing…" : "Publish to the paper"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk/queue",
						className: "self-center text-sm text-muted hover:text-ink",
						children: "Back to queue"
					})
				]
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-rust",
				children: msg
			}),
			data.draft?.integrity_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 max-w-2xl border border-rule bg-paper-2 p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tracking-[0.12em] text-muted uppercase",
					children: "Verify · "
				}), data.draft.integrity_notes]
			}),
			!locked && data.draft && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 max-w-3xl space-y-4",
				onSubmit: (e) => e.preventDefault(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Headline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "min-h-11 w-full border border-rule bg-paper px-3 text-sm text-ink outline-none focus:border-ink",
							value: headline,
							onChange: (e) => setHeadline(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Dek",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "min-h-11 w-full border border-rule bg-paper px-3 text-sm text-ink outline-none focus:border-ink",
							value: dek,
							onChange: (e) => setDek(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Topic",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "min-h-11 w-full border border-rule bg-paper px-3 text-sm text-ink outline-none focus:border-ink",
							value: topic,
							onChange: (e) => setTopic(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Body",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full border border-rule bg-paper px-3 py-2 text-sm leading-6 text-ink outline-none focus:border-ink min-h-80",
							value: body,
							onChange: (e) => setBody(e.target.value)
						})
					})
				]
			})
		]
	});
}
//#endregion
export { StoryPage as component };
