import { o as __toESM } from "../_runtime.mjs";
import { a as formatShortDate, r as TOPICS, t as PAPER } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TopicChip, t as PaperShell } from "./paper-chrome-Bj8-Jjsl.mjs";
import { d as searchPublished, f as subscribeNewsletter, l as listPublishedArticles, o as Route$16, u as listPublishedByTopic } from "./router-BKRELfXp.mjs";
import { t as StoryBody } from "./story-body-Dxd6dHm4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CR8a4mHE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { topic, q } = Route$16.useSearch();
	const navigate = Route$16.useNavigate();
	const [query, setQuery] = (0, import_react.useState)(q ?? "");
	const [email, setEmail] = (0, import_react.useState)("");
	const [subMsg, setSubMsg] = (0, import_react.useState)("");
	const initial = Route$16.useLoaderData();
	const { data: articles = initial, isPending } = useQuery({
		queryKey: [
			"paper",
			topic,
			q
		],
		queryFn: () => {
			if (q) return searchPublished({ data: q });
			if (topic) return listPublishedByTopic({ data: topic });
			return listPublishedArticles();
		},
		initialData: !topic && !q ? initial : void 0
	});
	const featured = articles[0];
	const rest = articles.slice(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 border-2 border-ink bg-paper-2 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl font-semibold",
					children: "Get the code"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-ink-2",
					children: "This chat cannot attach files. Click the black button."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/TownReporter.zip",
					download: "TownReporter.zip",
					className: "mt-3 inline-flex min-h-11 items-center bg-ink px-5 text-sm text-paper hover:bg-ink-2",
					children: "Download TownReporter.zip"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "border px-3 py-1 text-[11px] tracking-[0.14em] uppercase " + (!topic && !q ? "border-ink bg-ink text-paper" : "border-rule text-ink-2 hover:border-ink"),
					children: "all"
				}), TOPICS.filter((t) => t !== "about").map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopicChip, {
					topic: t,
					active: topic === t
				}, t))]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex min-h-11 gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					navigate({ search: {
						q: query || void 0,
						topic: void 0
					} });
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Search the archive",
					className: "min-h-11 min-w-0 flex-1 border border-rule bg-paper px-3 text-sm outline-none focus:border-ink sm:w-56 sm:flex-none"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "min-h-11 border border-ink px-4 text-sm hover:bg-paper-2",
					children: "Search"
				})]
			})]
		}),
		isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading the edition…"
		}),
		!isPending && !featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "border border-rule bg-paper-2 px-4 py-8 text-center text-ink-2",
			children: "No stories in this slice yet. The editor is still working the desk."
		}),
		featured && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "border-b border-ink pb-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] tracking-[0.16em] text-rust uppercase",
					children: [
						featured.topic,
						" · ",
						formatShortDate(featured.published_at)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl font-semibold leading-tight sm:text-5xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/articles/$slug",
						params: { slug: featured.slug },
						children: featured.headline
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-3xl text-lg italic text-ink-2",
					children: featured.dek
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryBody, { body: featured.body.split("\n\n").slice(0, 2).join("\n\n") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/articles/$slug",
						params: { slug: featured.slug },
						className: "mt-4 inline-block text-sm text-rust hover:text-rust-2",
						children: "Continue reading"
					})]
				})
			]
		}),
		rest.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid gap-8 sm:grid-cols-2",
			children: rest.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "border-t border-rule pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] tracking-[0.16em] text-muted uppercase",
						children: [
							a.topic,
							" · ",
							formatShortDate(a.published_at)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 font-display text-2xl font-semibold leading-snug",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/articles/$slug",
							params: { slug: a.slug },
							children: a.headline
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-ink-2",
						children: a.dek
					})
				]
			}, a.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-14 border-t-2 border-ink pt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "In your inbox"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-ink-2",
					children: "New articles when they publish. No spam. We store the address to send the paper; we do not sell it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 flex max-w-md flex-col gap-2 sm:flex-row",
					onSubmit: async (e) => {
						e.preventDefault();
						const res = await subscribeNewsletter({ data: email });
						if (!res.ok) setSubMsg(res.error);
						else if (res.confirmPath) setSubMsg(`Confirm: ${res.confirmPath} (preview — production would email this).`);
						else setSubMsg("You’re already on the list.");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "email",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value),
						placeholder: "you@example.com",
						className: "min-h-11 flex-1 border border-rule bg-paper px-3 text-sm outline-none focus:border-ink"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 bg-ink px-4 text-sm text-paper hover:bg-ink-2",
						children: "Subscribe"
					})]
				}),
				subMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: subMsg
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-sm text-muted",
					children: [PAPER.name, " complements the local paper. We cover the meetings and packets most people never sit through."]
				})
			]
		})
	] });
}
//#endregion
export { Home as component };
