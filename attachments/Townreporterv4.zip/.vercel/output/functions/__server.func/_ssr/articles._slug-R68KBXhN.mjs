import { i as formatDate, o as parseUrlList } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PaperShell } from "./paper-chrome-Bj8-Jjsl.mjs";
import { i as Route$9, l as listPublishedArticles, s as getPublishedArticle } from "./router-BKRELfXp.mjs";
import { t as StoryBody } from "./story-body-Dxd6dHm4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/articles._slug-R68KBXhN.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlePage() {
	const { slug } = Route$9.useParams();
	const loaded = Route$9.useLoaderData();
	const { data: article, isPending } = useQuery({
		queryKey: ["article", slug],
		queryFn: () => getPublishedArticle({ data: slug }),
		initialData: loaded ?? void 0
	});
	const { data: related = [] } = useQuery({
		queryKey: ["paper"],
		queryFn: () => listPublishedArticles()
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Loading…"
	}) });
	if (!article) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "That story is not in the archive." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "mt-4 inline-block text-rust",
		children: "Back to the paper"
	})] });
	const sources = parseUrlList(article.source_urls);
	const more = related.filter((a) => a.slug !== slug).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-[11px] tracking-[0.16em] text-rust uppercase",
			children: [
				article.topic,
				" · ",
				formatDate(article.published_at)
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 max-w-3xl font-display text-4xl font-semibold leading-tight sm:text-5xl",
			children: article.headline
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-2xl text-xl italic text-ink-2",
			children: article.dek
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 max-w-2xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryBody, { body: article.body })
		}),
		sources.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10 max-w-2xl border-t border-rule pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] tracking-[0.16em] text-muted uppercase",
					children: "Sources"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-1 text-sm",
					children: sources.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: u,
						className: "break-all text-rust hover:text-rust-2",
						target: "_blank",
						rel: "noreferrer",
						children: u
					}) }, u))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Trust is verifiable. Check the official record before you act on a figure or a vote."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-8 max-w-2xl text-sm text-muted",
			children: [
				"Free to reprint in whole or part with credit to ",
				article.headline ? "TownReporter" : "TownReporter",
				" ",
				"and a link back. Do not imply endorsement."
			]
		}),
		more.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-12 border-t-2 border-ink pt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold",
				children: "Also in the paper"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-3",
				children: more.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/articles/$slug",
					params: { slug: a.slug },
					className: "font-display text-xl hover:text-rust",
					children: a.headline
				}) }, a.id))
			})]
		})
	] });
}
//#endregion
export { ArticlePage as component };
