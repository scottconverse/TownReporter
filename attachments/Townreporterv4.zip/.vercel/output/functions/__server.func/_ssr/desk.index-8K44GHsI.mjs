import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as SourceZipButton, t as DeskShell } from "./desk-chrome-Cj0G1VLJ.mjs";
import { c as listScans, l as listSources, o as listLeads } from "./desk--8gnbvNC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk.index-8K44GHsI.js
var import_jsx_runtime = require_jsx_runtime();
function DeskHome() {
	const sources = useQuery({
		queryKey: ["sources"],
		queryFn: () => listSources()
	});
	const leads = useQuery({
		queryKey: ["leads"],
		queryFn: () => listLeads()
	});
	const scans = useQuery({
		queryKey: ["scans"],
		queryFn: () => listScans()
	});
	const accepted = (sources.data ?? []).filter((s) => s.status === "accepted").length;
	const proposed = (sources.data ?? []).filter((s) => s.status === "proposed").length;
	const openLeads = (leads.data ?? []).filter((l) => l.status === "new" || l.status === "drafted").length;
	const last = scans.data?.[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DeskShell, {
		title: "The desk",
		kicker: "Editor-in-chief",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-ink-2",
				children: "You are the editor. Grok fetches Longmont’s public sources, files leads, and drafts recaps. Nothing prints until you say so. Scans and drafts spend your Grok quota — they only run when you click."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 border-2 border-ink bg-paper p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Take the code"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-ink-2",
						children: "Chat cannot attach files. This is the source zip (~550 KB)."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceZipButton, {
						className: "mt-3 inline-flex min-h-11 items-center bg-ink px-5 text-sm text-paper hover:bg-ink-2",
						children: "Download TownReporter.zip"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Sources on watch",
						value: accepted
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Proposed sources",
						value: proposed
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Open leads",
						value: openLeads
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Scans run",
						value: scans.data?.length ?? 0
					})
				]
			}),
			last?.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 border border-rule bg-paper p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] tracking-[0.14em] text-muted uppercase",
					children: "Last scan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-ink-2",
					children: last.summary
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk/scan",
						className: "inline-flex min-h-11 items-center bg-ink px-4 text-sm text-paper hover:bg-ink-2",
						children: "Run a scan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk/queue",
						className: "inline-flex min-h-11 items-center border border-ink px-4 text-sm hover:bg-paper-2",
						children: "Open the queue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk/dark",
						className: "inline-flex min-h-11 items-center border border-ink bg-ink px-4 text-sm text-paper hover:bg-ink-2",
						children: "Dark desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk/sources",
						className: "inline-flex min-h-11 items-center border border-ink px-4 text-sm hover:bg-paper-2",
						children: "Review sources"
					})
				]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-rule bg-paper p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[11px] tracking-[0.12em] text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-3xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { DeskHome as component };
