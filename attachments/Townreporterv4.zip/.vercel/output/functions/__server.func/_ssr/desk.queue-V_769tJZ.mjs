import { a as formatShortDate } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as InkButton, t as DeskShell } from "./desk-chrome-Cj0G1VLJ.mjs";
import { o as listLeads, p as setLeadStatus } from "./desk--8gnbvNC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk.queue-V_769tJZ.js
var import_jsx_runtime = require_jsx_runtime();
function QueuePage() {
	const qc = useQueryClient();
	const { data: leads = [], isPending } = useQuery({
		queryKey: ["leads"],
		queryFn: () => listLeads()
	});
	const setStatus = useMutation({
		mutationFn: (input) => setLeadStatus({ data: input }),
		onSuccess: () => qc.invalidateQueries({ queryKey: ["leads"] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DeskShell, {
		title: "Queue",
		kicker: "Leads",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-ink-2",
				children: "What Grok thinks is news. Draft, hold, or kill. Published items stay here as a record."
			}),
			isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "Loading leads…"
			}),
			leads.length === 0 && !isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-muted",
				children: "Queue is empty. Run a scan to file leads."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-4",
				children: leads.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border border-rule bg-paper p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-baseline justify-between gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] tracking-[0.14em] text-muted uppercase",
								children: [
									l.topic,
									" · ",
									l.status,
									" · ",
									formatShortDate(l.created_at),
									l.newsworthiness != null ? ` · ${l.newsworthiness}/20` : ""
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-2xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/desk/story/$leadId",
								params: { leadId: String(l.id) },
								className: "hover:text-rust",
								children: l.headline
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-ink-2",
							children: l.why
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/desk/story/$leadId",
									params: { leadId: String(l.id) },
									className: "inline-flex min-h-11 items-center bg-ink px-4 text-sm text-paper hover:bg-ink-2",
									children: "Open"
								}),
								l.status !== "held" && l.status !== "published" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
									tone: "ghost",
									onClick: () => setStatus.mutate({
										id: l.id,
										status: "held"
									}),
									children: "Hold"
								}),
								l.status !== "killed" && l.status !== "published" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InkButton, {
									tone: "danger",
									onClick: () => setStatus.mutate({
										id: l.id,
										status: "killed"
									}),
									children: "Kill"
								})
							]
						})
					]
				}, l.id))
			})
		]
	});
}
//#endregion
export { QueuePage as component };
