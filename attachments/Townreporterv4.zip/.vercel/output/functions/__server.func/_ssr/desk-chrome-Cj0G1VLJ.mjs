import { o as __toESM } from "../_runtime.mjs";
import { t as PAPER } from "./paper-CGH1EBka.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useCurrentUserState, i as UserButton } from "./gates-B_IGPI9u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-chrome-Cj0G1VLJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HREF = "/TownReporter.zip";
async function saveSourceZip() {
	try {
		const res = await fetch(HREF);
		if (!res.ok) throw new Error("zip missing");
		const blob = await res.blob();
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "TownReporter.zip";
		a.rel = "noopener";
		document.body.appendChild(a);
		a.click();
		a.remove();
		setTimeout(() => URL.revokeObjectURL(url), 2e3);
		return "saved";
	} catch {
		return window.open(HREF, "_blank", "noopener,noreferrer") ? "opened" : "failed";
	}
}
function SourceZipButton({ children, className }) {
	const [msg, setMsg] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex flex-col items-start gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className,
			onClick: () => {
				saveSourceZip().then((r) => {
					if (r === "failed") setMsg("Blocked here. Open the preview in a new tab, then go to /TownReporter.zip");
					else if (r === "opened") setMsg("Opened in a new tab — save from there.");
					else setMsg("If a save dialog didn’t appear, open the preview in a new tab and visit /TownReporter.zip");
				});
			},
			children
		}), msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "max-w-xs text-xs text-ink-2",
			children: msg
		})]
	});
}
var LINKS = [
	{
		to: "/desk",
		label: "Overview"
	},
	{
		to: "/desk/sources",
		label: "Sources"
	},
	{
		to: "/desk/scan",
		label: "Scan"
	},
	{
		to: "/desk/queue",
		label: "Queue"
	},
	{
		to: "/desk/dark",
		label: "Dark desk"
	},
	{
		to: "/desk/memory",
		label: "Memory"
	}
];
function DeskShell({ children, title, kicker, night = false }) {
	const { user, isPending } = useCurrentUserState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: night ? "min-h-dvh bg-ink text-paper" : "min-h-dvh bg-desk text-desk-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: night ? "border-b border-ink-2 bg-ink" : "border-b border-ink bg-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "font-display text-lg font-semibold",
					children: PAPER.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `text-[11px] tracking-[0.16em] uppercase ${night ? "text-paper-2" : "text-muted"}`,
					children: night ? "Dark desk — not for print" : "Editor-in-chief desk"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourceZipButton, {
							className: night ? "bg-paper px-3 py-2 text-sm text-ink hover:bg-paper-2" : "bg-ink px-3 py-2 text-sm text-paper hover:bg-ink-2",
							children: "Source zip"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: night ? "text-paper-2 hover:text-paper" : "text-muted hover:text-ink",
							children: "View paper"
						}),
						isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-8 animate-pulse rounded-full bg-paper-2" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}) : null
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mx-auto flex max-w-6xl flex-wrap gap-1 px-4 pb-2 sm:px-6",
				children: LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: l.to,
					className: night ? "px-3 py-2 text-sm text-paper-2 hover:text-rust" : "px-3 py-2 text-sm text-ink-2 hover:text-rust",
					activeProps: { className: "px-3 py-2 text-sm text-rust" },
					children: l.label
				}, l.to))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 py-8 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] tracking-[0.16em] text-rust uppercase",
					children: kicker ?? "Newsroom"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-semibold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children
				})
			]
		})]
	});
}
function InkButton({ children, onClick, disabled, tone = "solid", type = "button" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		disabled,
		className: "inline-flex min-h-11 items-center justify-center px-4 text-sm font-medium disabled:opacity-50 " + (tone === "solid" ? "bg-ink text-paper hover:bg-ink-2" : tone === "danger" ? "border border-danger text-danger hover:bg-paper-2" : tone === "invert" ? "bg-paper text-ink hover:bg-paper-2" : "border border-ink text-ink hover:bg-paper-2"),
		children
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] tracking-[0.14em] text-muted uppercase",
			children: label
		}), children]
	});
}
var inputClass = "min-h-11 w-full border border-rule bg-paper px-3 text-sm text-ink outline-none focus:border-ink";
var areaClass = "w-full border border-rule bg-paper px-3 py-2 text-sm leading-6 text-ink outline-none focus:border-ink";
//#endregion
export { areaClass as a, SourceZipButton as i, Field as n, inputClass as o, InkButton as r, DeskShell as t };
