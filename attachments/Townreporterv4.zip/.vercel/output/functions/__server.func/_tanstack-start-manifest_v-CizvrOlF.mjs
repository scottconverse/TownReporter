//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CizvrOlF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/corrections",
			"/desk",
			"/feed",
			"/how-we-report",
			"/login",
			"/articles/$slug",
			"/newsletter/confirm",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-Dy2wdveh.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/createServerFn-Dvy0C4CA.js",
			"/assets/paper-CjYNpX55.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/matchContext-BOlpzIYq.js",
			"/assets/lazyRouteComponent-BoIB_NOt.js",
			"/assets/useStore-p0DOkFup.js",
			"/assets/QueryClientProvider-wtYiuOpi.js",
			"/assets/public-BeTmpLhO.js",
			"/assets/preload-helper-Czpn1I53.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dy2wdveh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B_7cZlFQ.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/paper-chrome-DzCyt5kH.js",
			"/assets/story-body-DxqDHxxX.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-xYiCXcgK.js", "/assets/paper-chrome-DzCyt5kH.js"]
	},
	"/corrections": {
		filePath: "/workspace/src/routes/corrections.tsx",
		children: void 0,
		preloads: [
			"/assets/corrections-hCIDIQyt.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/paper-chrome-DzCyt5kH.js"
		]
	},
	"/desk": {
		filePath: "/workspace/src/routes/desk.tsx",
		children: [
			"/desk/dark",
			"/desk/memory",
			"/desk/queue",
			"/desk/scan",
			"/desk/sources",
			"/desk/",
			"/desk/story/$leadId"
		],
		preloads: ["/assets/desk-B3l-ZIiM.js", "/assets/gates-C_MxAbqO.js"]
	},
	"/how-we-report": {
		filePath: "/workspace/src/routes/how-we-report.tsx",
		children: void 0,
		preloads: ["/assets/how-we-report-D0Jh0B5U.js", "/assets/paper-chrome-DzCyt5kH.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DRbuThly.js", "/assets/client-DRhaju3Z.js"]
	},
	"/articles/$slug": {
		filePath: "/workspace/src/routes/articles.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/articles._slug-7BQtFQOX.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/paper-chrome-DzCyt5kH.js",
			"/assets/story-body-DxqDHxxX.js"
		]
	},
	"/desk/dark": {
		filePath: "/workspace/src/routes/desk.dark.tsx",
		children: void 0,
		preloads: [
			"/assets/desk.dark-CWc3zERI.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/useMutation-BxeNaVm5.js",
			"/assets/desk-auth-SYkHqwER.js"
		]
	},
	"/desk/memory": {
		filePath: "/workspace/src/routes/desk.memory.tsx",
		children: void 0,
		preloads: [
			"/assets/desk.memory-RAN6nnCZ.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/useMutation-BxeNaVm5.js",
			"/assets/desk-auth-SYkHqwER.js",
			"/assets/desk-C2i3zrGc.js"
		]
	},
	"/desk/queue": {
		filePath: "/workspace/src/routes/desk.queue.tsx",
		children: void 0,
		preloads: [
			"/assets/desk.queue-Ckz2tpee.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/useMutation-BxeNaVm5.js",
			"/assets/desk-auth-SYkHqwER.js",
			"/assets/desk-C2i3zrGc.js"
		]
	},
	"/desk/scan": {
		filePath: "/workspace/src/routes/desk.scan.tsx",
		children: void 0,
		preloads: [
			"/assets/desk.scan-CXLeqsh3.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/useMutation-BxeNaVm5.js",
			"/assets/desk-auth-SYkHqwER.js",
			"/assets/desk-C2i3zrGc.js"
		]
	},
	"/desk/sources": {
		filePath: "/workspace/src/routes/desk.sources.tsx",
		children: void 0,
		preloads: [
			"/assets/desk.sources-DTRmM7fc.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/useMutation-BxeNaVm5.js",
			"/assets/desk-auth-SYkHqwER.js",
			"/assets/desk-C2i3zrGc.js"
		]
	},
	"/newsletter/confirm": {
		filePath: "/workspace/src/routes/newsletter.confirm.tsx",
		children: void 0,
		preloads: ["/assets/newsletter.confirm-DRnHEamf.js", "/assets/paper-chrome-DzCyt5kH.js"]
	},
	"/desk/": {
		filePath: "/workspace/src/routes/desk.index.tsx",
		children: void 0,
		preloads: [
			"/assets/desk.index-C84VeXEU.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/desk-auth-SYkHqwER.js",
			"/assets/desk-C2i3zrGc.js"
		]
	},
	"/desk/story/$leadId": {
		filePath: "/workspace/src/routes/desk.story.$leadId.tsx",
		children: void 0,
		preloads: [
			"/assets/desk.story._leadId-D_BGI80H.js",
			"/assets/useNavigate-DMcov2di.js",
			"/assets/useQuery-BPaus0AG.js",
			"/assets/useMutation-BxeNaVm5.js",
			"/assets/desk-auth-SYkHqwER.js",
			"/assets/desk-C2i3zrGc.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
