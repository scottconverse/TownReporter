const now = "Aug 26, 2026";
const DATA = {
leads: [
 {id:1, score:17, topic:"water", headline:"Council advances $47.9M water treatment expansion on 5-2 vote", why:"Largest capital outlay this cycle; the fund transfer is $6.2M above what the 2026 budget book shows.", status:"drafted", created:"Aug 26", age:"2h", from:"scan", urls:["https://www.longmontcolorado.gov/agendas/2026-09-02-packet.pdf"],
  draft:{headline:"Council advances $47.9M water plant expansion on split vote", dek:"The transfer funding it is $6.2M larger than the adopted budget shows — staff calls it a timing difference.", topic:"water", form:"recap", body:"The Longmont City Council voted 5-2 Tuesday to advance a $47.9 million expansion of the Nelson-Flanders Water Treatment Plant, moving the project into final design a year ahead of the schedule in the adopted capital plan.\n\nThe ordinance funds the work through a transfer from the Water Construction Fund that is $6.2 million larger than the figure printed in the 2026 budget book. Asked about the gap, utilities staff described it as a timing difference between the budget adoption and updated cost estimates received in June.\n\nCouncilmembers Hidalgo-Fahring and Yarbrough voted no, citing the size of the transfer and a pending rate study.\n\nThe item returns for second reading September 16."},
  found:[{t:"The June cost estimate memo is not in the public packet; it is referenced but not attached.", u:"longmontcolorado.gov"},{t:"Water Construction Fund balance dropped 22% since the 2026 budget was adopted."}],
  unanswered:["Why was the June estimate memo left out of the packet?","Does the pending rate study assume this transfer?"],
  verify:"Vote count confirmed against the clerk's minutes. Fund figures are from the packet, not yet reconciled with the finance portal."},
 {id:2, score:15, topic:"money", headline:"Costco sales-tax rebate deal quietly amended — cap raised to $32M", why:"Second amendment filed with the clerk raises the rebate cap 28% with no council presentation on record.", status:"new", created:"Aug 26", age:"3h", from:"dark", urls:["https://www.longmontcolorado.gov/clerk/contracts/costco-eda-amend-2.pdf"], found:[], unanswered:[]},
 {id:8, score:11, topic:"development", headline:"Neighbors' traffic study missing from Bohn Farm staff report", why:"Scanner re-filed the omission when the Sep 3 hearing packet posted.", status:"new", created:"Aug 26", age:"4h", from:"scan", urls:["https://www.longmontcolorado.gov/planning/bohn-farm-staff-report.pdf"], found:[], unanswered:[], dup:{pid:93, date:"Aug 19", note:"Bohn Farm rezoning heads to planning board with staff blessing"}},
 {id:3, score:13, topic:"schools", headline:"SVVSD moves $12M from bond contingency to Erie K-8 overrun", why:"Board consent item shifts a third of remaining 2022 bond contingency; Longmont projects still unbuilt.", status:"new", created:"Aug 25", age:"1d", from:"scan", urls:["https://www.svvsd.org/board/packets/2026-08-24.pdf"], found:[], unanswered:[]},
 {id:4, score:12, topic:"development", headline:"Sugar mill site cleanup memo contradicts developer timeline", why:"State health dept memo says remediation runs through 2028; developer told planning board it wraps in 2027.", status:"drafted", created:"Aug 24", age:"2d", from:"editor", urls:["https://cdphe.colorado.gov/longmont-sugar-mill"],
  draft:{headline:"State memo puts sugar mill cleanup a year behind developer's timeline", dek:"CDPHE's remediation schedule runs through 2028; the planning board was told 2027.", topic:"development", form:"news", body:"A Colorado Department of Public Health and Environment memo dated August 11 schedules groundwater remediation at the former Great Western sugar mill site through the third quarter of 2028 — a full year past the timeline the site's developer presented to Longmont's planning board in July.\n\nThe discrepancy matters because the metro district financing plan assumes vertical construction begins in 2027."},
  found:[{t:"Metro district service plan assumes 2027 construction start."}], unanswered:["Has the planning board seen the CDPHE memo?"], verify:"Memo obtained from CDPHE records portal; developer statement is from the July 15 board recording at 1:42:10."},
 {id:5, score:9, topic:"utilities", headline:"NextLight rate study postponed a third time", why:"Study promised for Q1, then Q2, now 'late 2026'. Pattern, not yet a story.", status:"held", created:"Aug 21", age:"5d", from:"scan", urls:["https://www.nextlight.net/news"], found:[], unanswered:[]},
 {id:6, score:6, topic:"parks", headline:"Union Reservoir algae advisory lifted", why:"Routine; brief at most.", status:"new", created:"Aug 26", age:"5h", from:"scan", urls:["https://www.longmontcolorado.gov/parks"], found:[], unanswered:[]},
 {id:7, score:8, topic:"airport", headline:"Vance Brand noise complaints doubled in July", why:"Raw totals only; no explanation yet.", status:"killed", created:"Aug 19", age:"7d", from:"scan", urls:[], found:[], unanswered:[]}
],
published: [
 {id:91, slug:"blank-check-clause", headline:"City manager's blank-check clause survives contract review", dek:"The renegotiated contract keeps a discretionary spending authority the auditor flagged in 2024.", topic:"money", date:"Aug 24, 2026", leadScore:16,
  body:"Longmont's renegotiated city manager contract, approved on the consent agenda August 18, retains a clause allowing discretionary spending of up to $250,000 per incident without council notification \u2014 language the city's outside auditor flagged as \u201cunusually broad\u201d in its 2024 management letter.\n\nThe clause dates to the 2021 contract. The 2023 renewal retained it, and the current renegotiation \u2014 which raised base salary 9% \u2014 left it untouched. No councilmember pulled the item for discussion.\n\nAsked whether the authority has been used, the city clerk's office said records responsive to that question would require a formal request. TownReporter has filed one.",
  sources:["longmontcolorado.gov/clerk/contracts/city-manager-2026.pdf","2024 management letter, p. 11"],
  corrections:[{date:"Aug 25, 2026", body:"An earlier version said the clause was added in 2023. It dates to the 2021 contract; the 2023 renewal retained it."}]},
 {id:92, slug:"arpa-deadline", headline:"Longmont's $3.1M in unspent ARPA funds must be obligated by December", dek:"Miss the federal deadline and the money goes back.", topic:"money", date:"Aug 22, 2026", leadScore:14,
  body:"Longmont has $3.1 million in American Rescue Plan Act funds that must be obligated by December 31 or returned to the U.S. Treasury, according to the city's Q2 grant compliance report.\n\nThe unobligated balance sits across three projects: the Chrisman Drive stormwater tie-in, a broadband equity study, and workforce housing pre-development. Staff told the finance board on August 12 that all three would be under contract \u201cby late fall\u201d \u2014 the same phrase used in the Q1 report.\n\nThe December deadline is federal and cannot be extended.",
  sources:["longmontcolorado.gov/finance/arpa-q2-2026.pdf"], corrections:[]},
 {id:93, slug:"bohn-farm-rezoning", headline:"Bohn Farm rezoning heads to planning board with staff blessing", dek:"Neighbors' traffic study was left out of the staff report.", topic:"development", date:"Aug 19, 2026", leadScore:12,
  body:"City planning staff are recommending approval of the Bohn Farm neighborhood rezoning ahead of the September 3 planning board hearing \u2014 but the staff report omits a traffic study the neighborhood association commissioned and submitted during the comment period.\n\nThe association's study, prepared by a licensed traffic engineer, projects peak-hour volumes 40% above the developer's estimate. Staff confirmed receipt of the study but said third-party submissions are \u201csummarized, not attached.\u201d The summary runs one sentence.\n\nThe hearing is September 3 at 6 p.m.",
  sources:["longmontcolorado.gov/planning/bohn-farm-staff-report.pdf","Neighborhood association traffic study, July 2026"], corrections:[]}
],
memory: [
 {e:"Costco EDA agreement", angle:"Rebate cap raised to $32M in unannounced second amendment", d:"Aug 26"},
 {e:"City manager contract", angle:"Blank-check clause retained through two renewals", d:"Aug 24"},
 {e:"SVVSD 2022 bond", angle:"Contingency drawdowns favoring Erie projects", d:"Aug 24"},
 {e:"Sugar mill site", angle:"Cleanup timeline vs. metro district financing assumptions", d:"Aug 24"},
 {e:"NextLight", angle:"Rate study slipping; no rate action since 2023", d:"Aug 21"}
],
sources: [
 {id:11, title:"City Council packets", url:"longmontcolorado.gov/city-council/packets", tier:"A", kind:"official", status:"accepted", fetched:"Aug 26"},
 {id:12, title:"Agendas & minutes portal", url:"longmontcolorado.gov/agendas", tier:"A", kind:"official", status:"accepted", fetched:"Aug 26"},
 {id:13, title:"City clerk contracts portal", url:"longmontcolorado.gov/clerk/contracts", tier:"A", kind:"official", status:"accepted", fetched:"Aug 26"},
 {id:14, title:"SVVSD board docs", url:"svvsd.org/board", tier:"A", kind:"official", status:"accepted", fetched:"Aug 25", error:"Timed out on last two scans"},
 {id:15, title:"Boulder County commissioners", url:"bouldercounty.gov/commissioners", tier:"A", kind:"official", status:"accepted", fetched:"Aug 26"},
 {id:16, title:"NextLight news", url:"nextlight.net/news", tier:"A", kind:"official", status:"accepted", fetched:"Aug 26"},
 {id:17, title:"Planning & development activity", url:"longmontcolorado.gov/planning", tier:"A", kind:"official", status:"accepted", fetched:"Aug 26"},
 {id:18, title:"Times-Call", url:"timescall.com", tier:"B", kind:"journalism", status:"accepted", fetched:"Aug 26"},
 {id:19, title:"Longmont Leader", url:"longmontleader.com", tier:"B", kind:"journalism", status:"accepted", fetched:"Aug 26"},
 {id:20, title:"Longmont Observer archive", url:"archive.org/longmont-observer", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 20"},
 {id:21, title:"Longmont DDA board packets", url:"longmontdda.org/board", tier:"A", kind:"official", status:"proposed", note:"Turned up in the Aug 26 scan — DDA called a special meeting"},
 {id:22, title:"CDOT US-287 project page", url:"codot.gov/projects/us287", tier:"A", kind:"official", status:"proposed", note:"Referenced in the transportation extension file"},
 {id:23, title:"r/Longmont", url:"reddit.com/r/longmont", tier:"C", kind:"signal", status:"rejected"},
 {id:24, title:"City of Longmont — Facebook", url:"facebook.com/longmontcolorado", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 21", error:"Facebook refused the request (400). It usually does.", errKind:"flaky"},
 {id:25, title:"Longmont Police — Facebook", url:"facebook.com/longmontpolice", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 19", error:"Facebook refused the request (400). It usually does.", errKind:"flaky"},
 {id:26, title:"SVVSD — Facebook", url:"facebook.com/svvsd", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 22", error:"Rate-limited (429). Cleared on its own last time.", errKind:"flaky"},
 {id:27, title:"@longmontgov — X", url:"x.com/longmontgov", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 14", error:"X refused the request (403). It usually does.", errKind:"flaky"},
 {id:28, title:"Nextdoor — Longmont", url:"nextdoor.com/city/longmont-co", tier:"C", kind:"signal", status:"accepted", fetched:"—", error:"Needs a login the scanner doesn't have.", errKind:"flaky"},
 {id:29, title:"Longmont Chamber events", url:"longmontchamber.org/events", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 25", error:"Timed out once. Usually fine.", errKind:"flaky"},
 {id:30, title:"Visit Longmont calendar", url:"visitlongmont.org/events", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 20", error:"Name lookup failed (DNS). Third scan in a row.", errKind:"flaky"},
 {id:35, title:"Longmont Leader — Facebook", url:"facebook.com/longmontleader", tier:"C", kind:"signal", status:"accepted", fetched:"Aug 23", error:"Rate-limited (429).", errKind:"flaky"}
],
scans: [
 {id:31, date:"Aug 26, 6:12 AM", fetched:41, leads:3, proposed:1, summary:"Council packet for Sep 2 posted early — water fund transfer larger than budgeted. DDA added a special meeting for Thursday. SVVSD consent agenda moves bond contingency."},
 {id:32, date:"Aug 25, 6:04 AM", fetched:40, leads:1, proposed:0, summary:"Quiet day. SVVSD packet posted; one consent item worth a look. Two sources timed out."},
 {id:34, date:"Aug 24, 6:03 AM", fetched:41, leads:0, proposed:0, summary:"Nothing crossed the filing bar. Thirty-nine pages matched their last capture; two changed only in datestamps and boilerplate."},
 {id:33, date:"Aug 23, 7:18 AM", fetched:41, leads:2, proposed:1, summary:"Clerk portal shows two new contract amendments filed Friday afternoon, including Costco EDA amendment 2."}
],
worth: [
 {id:"w1", kind:"Missing record", title:"July special-meeting minutes are gone from the clerk portal", why:"Minutes for the July 22 special session were captured on Aug 2. The link now returns a generic page.", happened:"The clerk portal's July index was rebuilt sometime after Aug 20; the special-session entry did not come back.", q:"Were the minutes moved, renamed, or pulled?", src:"Clerk portal — City of Longmont"},
 {id:"w2", kind:"Overdue", title:"Airport master plan update is six weeks past its promised posting", why:"Staff told council on July 8 the draft would post 'within 30 days'. Nothing has appeared.", happened:"The airport page was last touched July 3. The consultant's invoice for the draft was paid in June.", q:"Is the draft being held, or is it late?", src:"Airport page — City of Longmont"},
 {id:"w3", kind:"From the scanner", title:"New LLC 'Front Range Civic Partners' appears in three RFP awards", why:"Formed in March, no web presence, and it has won three small-dollar city awards since May.", happened:"A third award (traffic data services, $48K) was posted to the procurement page this week.", q:"Who is behind the LLC and how are the awards staying under the bid threshold?", src:"Procurement page — City of Longmont"},
 {id:"w4", kind:"Page changed", title:"Meeting", why:"A special meeting posted with the minimum 72 hours of notice usually means a deadline.", happened:"The DDA calendar gained a one-item special meeting for Thursday: a downtown parking garage land swap.", q:"Why 72 hours' notice for a land swap?", src:"DDA calendar — longmontdda.org"}
],
investigations: [
 {id:101, title:"Transportation Extension document", status:"paused", stopKind:"error", records:34, stillOpen:19, round:3, budget:5, touched:"Aug 26",
  started:"You opened this from Dark Desk because \u201cTransportation Extension document\u201d looked worth a closer look.",
  stopReason:"A search or page load timed out. What was already found is still here.",
  noticed:["@cityoflongmont looks different than the last time Dark Desk captured it. That may just be a new video, not a vanished record."],
  know:[],
  artifacts:[
   {id:1, kind:"PDF", org:"City of Longmont", title:"Transportation extension IGA — second amendment", captured:"Aug 26", url:"longmontcolorado.gov/clerk/contracts/trans-ext-amend-2.pdf", excerpt:"This Second Amendment to the Intergovernmental Agreement extends the term through December 31, 2028 and revises Exhibit B (cost share). Section 4 is amended to read: the City's contribution shall not exceed $4,150,000, replacing the prior figure of $2,900,000\u2026"},
   {id:2, kind:"Web page", org:"City of Longmont", title:"Transportation projects index", captured:"Aug 26", url:"longmontcolorado.gov/transportation/projects", excerpt:"Current projects: Coffman corridor, US-287 signal upgrades, Quail Road extension. Note: the extension project page referenced in the 2025 index no longer appears in this list\u2026"},
   {id:3, kind:"PDF", org:"City of Longmont", title:"Council communication, Feb 2025 — original IGA", captured:"Aug 26", url:"longmontcolorado.gov/agendas/2025-02-11-item-8b.pdf", excerpt:"Staff recommends approval of an IGA with CDOT for the transportation extension, city share $2.9M funded from the Street Fund. Fiscal impact: within existing appropriation\u2026"},
   {id:4, kind:"Web page", org:"CDOT", title:"US-287 corridor project page", captured:"Aug 26", url:"codot.gov/projects/us287", excerpt:"Project timeline updated June 2026. Local agency match amounts under revision pending executed amendments\u2026"},
   {id:5, kind:"Video page", org:"City of Longmont", title:"@cityoflongmont — council meeting channel", captured:"Aug 25", url:"youtube.com/@cityoflongmont", excerpt:"Channel index. Most recent upload: Aug 24 study session. The Feb 2025 meeting recording referenced in the file is still listed\u2026"},
   {id:6, kind:"PDF", org:"City of Longmont", title:"Street Fund quarterly report, Q2 2026", captured:"Aug 26", url:"longmontcolorado.gov/finance/street-fund-q2.pdf", excerpt:"Committed but unspent: $4.15M shown against 'IGA obligations' — up from $2.9M in Q1. No amendment is cited in the notes\u2026"}
  ],
  frontier:[
   {id:"f1", label:"Index — Referenced in evidence", why:"The 2025 projects index that listed the extension page"},
   {id:"f2", label:"R. Maldonado — signer on both amendments", why:"Same signature block on the IGA and the Costco amendment"},
   {id:"f3", label:"Exhibit B (cost share) — revised attachment", why:"Referenced by amendment 2, not captured yet"},
   {id:"f4", label:"Feb 2025 council recording, 1:12:00", why:"Where the $2.9M cap was presented"},
   {id:"f5", label:"CDOT local-agency agreement register", why:"Should show the executed amendment"},
   {id:"f6", label:"Exhibit B appraisal referenced at ¶3", why:"Named, not attached"},
   {id:"f7", label:"CDOT region 4 award list, FY26", why:"Would show the state's side of the match"},
   {id:"f8", label:"Street Fund Q1 report", why:"To confirm the $2.9M starting figure"},
   {id:"f9", label:"Clerk contract log, week of Aug 18", why:"When amendment 2 was filed"},
   {id:"f10", label:"Quail Road extension page", why:"Mentioned in the new projects index"},
   {id:"f11", label:"'Timing difference' — staff phrasing search", why:"Same phrase as the water fund answer"},
   {id:"f12", label:"Council study session notes, Jun 2026", why:"Where updated estimates were received"}
  ],
  trail:["longmont transportation extension IGA amendment","street fund committed obligations 2026","CDOT US-287 local agency match Longmont"],
  deadEnds:[{h:"The extension page was deleted to hide the amendment", why:"The page moved in a site redesign; an archived copy matches the live copy."}]},
 {id:102, title:"Front Range Civic Partners LLC", status:"open", stopKind:"round", records:12, stillOpen:4, round:2, budget:5, touched:"Aug 25",
  started:"Started from the scanner card about three RFP awards to a new LLC.",
  stopReason:null,
  noticed:["All three awards sit just under the $50K formal-bid threshold.","Registered agent address is a coworking space on Main St."],
  know:["The LLC was formed March 9, 2026.","Awards: wayfinding signage $46K (May), survey services $44K (Jun), traffic data $48K (Aug)."],
  artifacts:[
   {id:1, kind:"Web page", org:"Colorado SOS", title:"Business entity record — Front Range Civic Partners LLC", captured:"Aug 25", url:"sos.state.co.us/biz/frcp", excerpt:"Formed 2026-03-09. Registered agent: 320 Main St Suite 100, Longmont. Periodic report not yet due\u2026"},
   {id:2, kind:"Web page", org:"City of Longmont", title:"Procurement awards, 2026", captured:"Aug 25", url:"longmontcolorado.gov/procurement/awards", excerpt:"Wayfinding signage package — Front Range Civic Partners, $46,200. Survey services on-call — $44,800. Traffic data services — $48,100\u2026"}
  ],
  frontier:[
   {id:"f1", label:"Suite 100 tenant list — who else registers there", why:"Shared agent address"},
   {id:"f2", label:"Award selection memos — sole source or quotes?", why:"Under-threshold awards still require quotes"},
   {id:"f3", label:"LLC organizer name on formation filing", why:"Not shown on the summary record"},
   {id:"f4", label:"City vendor registration file", why:"Would show W-9 signer"}
  ],
  trail:["front range civic partners llc colorado","longmont procurement awards 2026 under 50000"], deadEnds:[]},
 {id:103, title:"Vance Brand hangar lease rumor", status:"aside", records:8, stillOpen:0, round:4, budget:5, touched:"Aug 18",
  started:"Started from a tip that a hangar lease was assigned without airport board review.",
  stopReason:"You set this aside. Pull it back onto the desk anytime.",
  noticed:[], know:["The assignment followed policy; board review is not required for assignments under 5 years."],
  artifacts:[{id:1, kind:"PDF", org:"City of Longmont", title:"Hangar lease assignment policy", captured:"Aug 17", url:"longmontcolorado.gov/airport/lease-policy.pdf", excerpt:"Assignments of five years or fewer may be approved administratively\u2026"}],
  frontier:[], trail:["vance brand hangar lease assignment"], deadEnds:[{h:"Lease assigned without required review", why:"Policy allows administrative approval; the paperwork checks out."}]}
],
runs: [
 {d:"Aug 26, 5:41 AM", text:"Transportation extension file: opened 9 pages, saved 6 records, added 5 things to follow, then a page load timed out. Everything found is on the file."},
 {d:"Aug 25, 9:12 PM", text:"Front Range Civic Partners: ran 4 searches, opened 6 pages. Confirmed formation date and all three award amounts."}
]};
window.DATA = DATA;
window.TOPICS = ["council","money","water","schools","development","utilities","parks","airport","safety"];
